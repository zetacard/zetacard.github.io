# Deploy ZetaCard to https://zetacard.github.io

## Before publishing

1. Keep a copy of the original Base44 ZIP outside this repository.
2. Review `.env.example` and obtain your own Supabase Project URL and publishable/anon key.
3. Never commit `.env`, `.env.local`, a Supabase `service_role` key, database password, Resend key, or any other server secret.

## Add the project to the existing repository

Upload the **contents** of this project folder to the root of the existing `zetacard/zetacard.github.io` repository on the `main` branch. Do not upload the outer `ZetaCard` folder as an extra nested directory. If the repository already contains important files, download/backup them before replacing anything and merge rather than overwrite.

## Configure GitHub repository variables

In the repository, open **Settings → Secrets and variables → Actions → Variables** and add:

- `VITE_SUPABASE_URL` = your Supabase Project URL
- `VITE_SUPABASE_ANON_KEY` = your Supabase publishable key (or legacy anon public key)

These are browser-visible public configuration values. Do not put a Supabase service-role key here.

## Enable GitHub Pages

Open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**. Commit/push to `main`; the workflow in `.github/workflows/deploy.yml` builds and deploys the site.

## Supabase URL configuration

In Supabase Authentication URL Configuration, set the Site URL to:

`https://zetacard.github.io`

Add the required redirect URLs, including:

- `https://zetacard.github.io/**`
- `http://localhost:5173/**` (for local development)

Also configure Google OAuth callback/provider settings if Google login is enabled.

## Important limitations

- GitHub Pages hosts only the static frontend. Supabase remains responsible for database, authentication, storage, and Edge Functions.
- The app's Supabase migrations and Edge Functions must be deployed and tested separately; this workflow does not modify your Supabase project.
- A successful Pages deployment does not prove login, bookings, email, or every feature works. Test those against a staging Supabase project before production use.

# BASE44_DEPENDENCY_AUDIT.md

Scope: every file shipped in `ZetaCard_Complete_Ownership_Package.zip`, scanned for
runtime dependence on Base44. This audit was produced by reading the actual package
tree, not from memory. Re-run it yourself with the commands at the bottom.

## Result

**Zero runtime dependencies on Base44.** The application authenticates, stores data,
stores files and executes server logic entirely on Supabase plus one static host.

## 1. Package dependencies

`package.json` `dependencies` contains **no** `@base44/sdk`, no `@base44/vite-plugin`
and no other Base44 package. Verified programmatically:

```
grep -n "base44" package.json          -> no match in dependencies/devDependencies
```

| Old dependency | Replacement in this package |
|---|---|
| `@base44/sdk` (client) | `@supabase/supabase-js` used directly in `src/api/zetaClient.js` |
| `@base44/vite-plugin` | plain `@vitejs/plugin-react` |
| `base44.functions.invoke(...)` | `supabase.functions.invoke(...)` (Supabase Edge Functions) |

## 2. Code surface

| Concern | Base44 call (old) | Implementation now |
|---|---|---|
| Authentication | `base44.auth.*` | `src/api/zetaClient.js` → `supabase.auth.*` (signUp, signInWithPassword, signOut, resetPasswordForEmail, updateUser, onAuthStateChange) |
| Database | `base44.entities.X.*` | `zetaClient.from('X')` — typed entity helpers over PostgREST (filter/get/create/update/delete/count) |
| File uploads | `base44.integrations.Core.UploadPrivateFile` | `supabase.storage.from('card-media')` |
| File URLs | Base44 CDN | `supabase.storage...getPublicUrl()` |
| Server logic | `base44/functions/*/entry.ts` | `supabase/functions/*/index.ts` (Deno, portable) |
| Hosting | Base44 hosting | any static host (`dist/`) |

`src/api/base44Client.js` is **not** a network client. It is a local compatibility
module that re-exports the Supabase client under the historical name `base44`, so the
~50 existing call sites kept working during the swap. It contains no vendor URL, no
app id and no vendor token. Execute `node scripts/rename-client.mjs` to rename the
identifier to `zeta` everywhere and delete the compatibility module entirely.

## 3. Every remaining literal occurrence of the string "base44"

| Location | Nature | Action required |
|---|---|---|
| `src/components/ui/image-helpers.js:2` | `"media.base44.com": "/images/public/"` — a hostname map | None to run the app. It only appends resize parameters to images whose URL already lives on the old CDN, so legacy card photos keep rendering. Any other host (including your Supabase Storage URLs) passes through untouched. |
| `src/components/ui/image.jsx:15` | doc comment | Cosmetic |
| `MIGRATION_VERIFICATION.md`, `OWNERSHIP_TRANSFER_REPORT.md`, this file | documentation | Expected |

Images that are still hosted on `media.base44.com` are the only content-level tie:
they render today, but the host is outside your control. Re-upload them to your
`card-media` bucket and update `portrait_url` / `cover_url` when convenient. The
storage migration script in `supabase/` covers this. Nothing else in the app needs
changing for that.

## 4. Environment variables

No `VITE_BASE44_*` variable is read anywhere. The app reads only:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_APP_BASE_URL`

## 5. What still needs a third party (all optional, documented)

| Service | Needed for | Without it |
|---|---|---|
| Supabase | everything | app cannot run — this is the intended backend |
| Resend | booking/enquiry emails | emails return `status: "skipped"`; bookings still save |
| AI provider | copilot | copilot returns a clear "not configured" error; editor unaffected |
| Static host | publishing | `npm run build` output can be served anywhere |

## 6. Verify it yourself

```bash
cd ZetaCard
grep -rn "@base44" src supabase package.json        # expect: no output
grep -rn "base44" src | grep -v "media.base44.com"  # expect: no output
npm ls @base44/sdk                                  # expect: (empty)
npm run build                                       # expect: exit 0
``
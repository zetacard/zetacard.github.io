# ZetaCard — Portable Edition (React + Supabase)

This is the complete, independently deployable ZetaCard application. It runs on your own
Supabase project and any static host. No Base44 subscription, runtime or SDK is required.

- **Frontend:** React 18 + Vite + Tailwind, 27 pages, 80 components — the working UI, unchanged.
- **Backend:** 8 Supabase Edge Functions (Deno) replacing the hosted functions.
- **Database:** PostgreSQL with Row Level Security, 6 tables, 17 indexes, 17 policies.
- **Auth:** Supabase Auth (email + password, email code verification, Google OAuth, password reset).
- **Storage:** Supabase Storage bucket `card-media` for card imagery.

## Quick start

```bash
npm install
cp .env.example .env.local       # fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm run dev                      # http://localhost:5173
```

Deploy the database and functions (one time):

```bash
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase db push             # applies supabase/migrations/*.sql
npx supabase functions deploy    # deploys all 8 edge functions
```

Then build and host:

```bash
npm run build                    # static output in dist/
```

Full instructions: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) ·
Environment variables: [ENVIRONMENT_SETUP.md](ENVIRONMENT_SETUP.md)

## Project layout

```
ZetaCard/
├── src/                      # React frontend (pages, components, hooks, ui)
│   └── api/
│       ├── zetaClient.js     # the ONLY backend module (auth, entities, functions, storage)
│       └── base44Client.js   # 5-line re-export kept for the historical import path
├── supabase/
│   ├── migrations/           # 0001 schema · 0002 RLS · 0003 storage
│   ├── functions/            # 8 edge functions + _shared helpers
│   └── config.toml           # local stack configuration
├── scripts/                  # verification + optional rename helpers
├── index.html · vite.config.js · tailwind.config.js · postcss.config.js
├── .env.example · .gitignore · package.json
└── docs (this folder): FEATURE_INVENTORY, DATABASE_MIGRATION_REPORT,
    OWNERSHIP_TRANSFER_REPORT, DEPLOYMENT_GUIDE, ENVIRONMENT_SETUP,
    SECURITY_AUDIT, MIGRATION_VERIFICATION
```

## How the data layer works

`src/api/zetaClient.js` is the single integration point. It wraps the Supabase client in the
same shape the UI already uses, so every page and component works untouched:

| UI call | What it does |
| --- | --- |
| `base44.entities.Card.filter({…})` | PostgREST `select` with translated filters (`$in`, `$gte`, `$or`, `$regex`, …) |
| `base44.entities.Card.count(…)` | `count: exact, head: true` |
| `base44.auth.me()` | `auth.getUser()` + the `app_users` profile row |
| `base44.functions.invoke('submitBooking', …)` | `supabase.functions.invoke` |
| `base44.integrations.Core.UploadPublicFile({ file })` | upload to the `card-media` bucket |

The identifier is still spelled `base44` in the UI files because the app was migrated without
touching them. `node scripts/rename-client.mjs` switches everything to `zeta` / `@/api/zetaClient`
if you prefer the clean name.

## Migration status at a glance

| Area | Status |
| --- | --- |
| Database schema, indexes, RLS, bucket | **PASS** — created in your Supabase project and verified |
| Frontend source (pages, components, design) | **PASS** — preserved, one data-layer swap |
| Edge functions (8) | **PASS** — ported, deployed with `supabase functions deploy` |
| Transactional email | **PARTIAL** — needs a Resend key and a verified sending domain |
| AI copilot | **PARTIAL** — needs an `AI_API_KEY` function secret |
| Google sign-in | **PARTIAL** — needs the Google provider enabled in Supabase |
| Existing user accounts | **BLOCKED** — password hashes are not exportable; users re-register or use reset |
| Business records | **N/A** — the source app holds 0 business records (verified) |

Details and evidence: [MIGRATION_VERIFICATION.md](MIGRATION_VERIFICATION.md)

## Licence / ownership

You own this source. It contains no vendor SDK, no service keys and no telemetry.
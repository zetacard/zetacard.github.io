# ENVIRONMENT SETUP

## Frontend (build-time, public)

| Variable | Required | Where to find it | Notes |
| --- | --- | --- | --- |
| `VITE_SUPABASE_URL` | yes | Supabase → Project Settings → API → Project URL | e.g. `https://abcdefgh.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | yes | Supabase → Project Settings → API → `anon` `public` | Safe to ship; RLS protects the data |
| `VITE_APP_BASE_URL` | optional | your domain | Used for links inside the app |

Create `.env.local` (git-ignored):

```
VITE_SUPABASE_URL=https://YOUR_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_ANON_KEY
VITE_APP_BASE_URL=http://localhost:5173
```

Anything prefixed `VITE_` is compiled into the browser bundle. **Never** put a service-role key,
database password or provider secret there.

## Edge functions (runtime secrets)

Set with `npx supabase secrets set NAME=value` (or in the dashboard under Edge Functions → Secrets).

| Secret | Required | Used by | Notes |
| --- | --- | --- | --- |
| `SUPABASE_URL` | auto | all | Injected by Supabase |
| `SUPABASE_ANON_KEY` | auto | `updateBookingStatus`, `deleteMyData`, `aiCopilot` | Injected by Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | auto | all | Injected by Supabase — never copy it into the app |
| `RESEND_API_KEY` | for email | `submitBooking`, `updateBookingStatus` | Create at resend.com; verify a sending domain |
| `EMAIL_FROM` | for email | same | e.g. `ZetaCard <hello@yourdomain.com>`; must be a verified domain |
| `AI_API_KEY` | for the copilot | `aiCopilot` | Any OpenAI-compatible key |
| `AI_MODEL` | optional | `aiCopilot` | Default `gpt-4o-mini` |
| `AI_BASE_URL` | optional | `aiCopilot` | Default `https://api.openai.com/v1` |

Without `RESEND_API_KEY` the app still works: bookings and status changes save normally, emails are
reported as `skipped`, and nothing pretends to have been sent.

Without `AI_API_KEY` the copilot returns a clear "not configured" message instead of failing silently.

## Local full stack (optional)

```bash
npx supabase start          # Postgres + Auth + Storage + Studio on your machine
npx supabase db reset       # applies supabase/migrations/*.sql
npx supabase functions serve
```

`supabase start` prints local keys; use that URL and anon key in `.env.local`. The local auth config
in `supabase/config.toml` has confirmations enabled so the OTP screen behaves like production.

## Where each secret must never appear

- Service-role key: only `Deno.env` inside `supabase/functions/**`.
- Database password: nowhere in this repository.
- Anon key: frontend is fine (it is designed to be public, and RLS is the real boundary).
# TROUBLESHOOTING.md

Real problems you will hit, why they happen, and the exact fix. Commands assume you
are inside the extracted `ZetaCard/` folder on Linux Mint.

---

## 1. The ZIP download returned 404

There were two possible causes and they are fixed differently.

**a) You opened `/downloads/...` on the app's own domain.** That path only exists in
the Base44-hosted copy of the app, and only after that copy is re-published — the URL
you tried was never a real file server. Use the storage link you were given in chat
(or the file attached there). If that link ever expires, ask for it to be regenerated:
the source itself is never lost, it is the `ZetaCard/` folder of your project.

**b) The browser saved an HTML error page instead of a ZIP.** Check the file:
```bash
file ~/Downloads/ZetaCard_Complete_Ownership_Package.zip
# want: Zip archive data
unzip -t ~/Downloads/ZetaCard_Complete_Ownership_Package.zip | tail -2
# want: No errors detected in compressed data
```

---

## 2. `npm install` fails

- Node must be 20 or newer: `node -v`. Install via nvm if not.
- If you see `ERR_OSSL_EVP_UNSUPPORTED` on older Node, upgrade Node; do not patch it.
- Corporate network / proxies: `npm config set registry https://registry.npmjs.org/`.

---

## 3. App starts but every screen is blank and login does nothing

The browser bundle has no Supabase credentials. Create `.env.local` in the project
root:

```
VITE_SUPABASE_URL=https://YOUR-REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR-ANON-KEY
VITE_APP_BASE_URL=http://localhost:5173
```

Both values live in Supabase → Project Settings → API. Restart `npm run dev` after
editing — Vite only reads env at start. If the URL contains a trailing slash, remove it.

**Never** put the `service_role` key in a `VITE_` variable. It is bundled into the
browser and would hand anyone full database access.

---

## 4. Sign-up fails or `Email not confirmed`

- Default Supabase projects require email confirmation. Either click the link in the
  email, or for local testing turn it off: Authentication → Providers → Email →
  disable "Confirm email".
- Your own site must be allowed to redirect: Authentication → URL Configuration → add
  `http://localhost:5173` and your production URL to Site URL / Redirect URLs, or
  password-reset links bounce to the wrong domain.

---

## 5. Login works, then you are logged out on refresh

Session persistence needs `localStorage` to be available and the same origin as the
configured Site URL. Do not serve the built app from a different host than the one
listed in Supabase URL Configuration. Private/incognito windows discard the session on
close — that is expected.

---

## 6. Dashboard shows nothing / RLS error `42501`

```
new row violates row-level security policy
```

This means the query ran as an authenticated user who does not own the row. It is the
system working. Check:

- You are signed in as the account that created the card (rows are owned by
  `user_id`, populated from `auth.uid()`).
- The table has the ownership policies applied: `supabase db push` if you skipped it.
- You did **not** publish cards while signed into a different project.

Never "fix" this by disabling RLS.

---

## 7. Edge functions return 401 or 500

- `401`: the function was called without a valid JWT. Public actions
  (`submitEnquiry`, `submitContact`, `trackEvent`, `cardSlots`) are deployed with
  `--no-verify-jwt`; admin actions (`updateBookingStatus`, `deleteMyData`, `aiCopilot`)
  require a real session token.
- `500` mentioning `SUPABASE_URL`/`SERVICE_ROLE`: set the function secrets:
  ```bash
  supabase secrets set RESEND_API_KEY=... EMAIL_FROM="ZetaCard <hello@yourdomain>"
  supabase functions deploy
  ```
  The service-role key is injected automatically by Supabase; you never set it.

---

## 8. Emails are not sent (`email_status: "skipped"`)

Expected without credentials. Set `RESEND_API_KEY`, verify your sending domain in
Resend, and set `EMAIL_FROM` to an address on that domain. Then:

```bash
supabase secrets set RESEND_API_KEY=re_xxx EMAIL_FROM="ZetaCard <hello@yourdomain>"
supabase functions deploy sendBookingEmail
```

A booking still saves when email fails. The dashboard shows the delivery status per
booking, so nothing is silently lost.

---

## 9. AI copilot says "not configured"

Set the provider key server-side only:

```bash
supabase secrets set AI_API_KEY=sk-... AI_MODEL=gpt-4o-mini
supabase functions deploy aiCopilot
```

The key never reaches the browser. Without it the editor still works; only the copilot
panel is disabled.

---

## 10. Uploads fail with `new row violates row-level security` or `403`

The `card-media` bucket must exist with the storage policies applied
(`supabase/migrations/0003_storage.sql`). If the bucket is missing:

```bash
supabase db push
# or: supabase storage create card-media --public
```

Uploads are written under `<user-id>/...`; the policy allows a user to write only into
their own folder.

---

## 11. Images do not appear on the public card

- The bucket must be **public** for `getPublicUrl()` links to resolve.
- If the card still points at an old `media.base44.com` URL, re-upload the image and
  save the new URL — the old CDN is not yours and may stop serving at any time.

---

## 12. `supabase db push` says the migration is already applied

That is correct when you migrated before. To rebuild from scratch on a new project:

```bash
supabase db reset          # local, destructive
# or, on a hosted project, apply 0001 → 0002 → 0003 in order in the SQL editor
```

Never re-run `0001` on a project that already has the tables unless you mean to reset.

---

## 13. `vite build` succeeds but the deployed site 404s on refresh

Your host is not rewriting unknown paths to `index.html`. Add the SPA rewrite:
Netlify `_redirects` → `/* /index.html 200`; Vercel `rewrites`; Nginx
`try_files $uri /index.html;`.

---

## 14. Existing users cannot log in with their old password

Passwords are stored as bcrypt hashes by the old provider and are not exportable — by
anyone. Give each user one of these:

1. Password reset: Supabase → Authentication → Users → "Send recovery"; or use the
   app's own "Forgot password" flow once email is configured.
2. Ask them to register again with the same email after you invite them
   (Authentication → Users → Invite) — this preserves their history because records
   are keyed by user id, not email.

Then re-link their old cards to the new account id (the report
`DATABASE_MIGRATION_REPORT.md` explains the mapping).

---

## 15. Need to start over completely

```bash
supabase db reset           # local rebuild from migrations
rm -rf node_modules dist && npm ci
```

Nothing in this project depends on Base44, so a full local reset is always possible.
# FEATURE INVENTORY

Every feature found in the source application, where it lives, and what it depends on after
migration. Nothing was removed or simplified.

## 1. Public marketing site (9 pages)

| Page | File | Notes |
| --- | --- | --- |
| Home | `src/pages/Home.jsx` | Hero, categories, templates, pricing, testimonials |
| Features | `src/pages/Features.jsx` | Capability grid |
| Categories | `src/pages/Categories.jsx` | 8 card categories |
| Templates | `src/pages/Templates.jsx` | Template gallery |
| How it works | `src/pages/HowItWorks.jsx` | Process steps |
| About | `src/pages/About.jsx` | Company page |
| Help | `src/pages/Help.jsx` | FAQ accordion |
| Contact | `src/pages/Contact.jsx` | Calls `submitEnquiry` with `kind: "platform"` |
| Privacy / Terms | `src/pages/Privacy.jsx`, `src/pages/Terms.jsx` | Legal pages |

Shared shell: `src/components/site/SiteLayout.jsx`, `SiteHeader.jsx`, `SiteFooter.jsx`, `Brand.jsx`.

## 2. Authentication

| Capability | Implementation | Backend dependency |
| --- | --- | --- |
| Register (email + password) | `src/pages/Register.jsx` | Supabase Auth `signUp` |
| 6-digit email verification | same page, `verifyOtp` | Supabase Auth `verifyOtp` (template must include `{{ .Token }}`) |
| Resend verification code | same page | `auth.resend` |
| Login | `src/pages/Login.jsx` | `signInWithPassword` |
| Google sign-in | Login + Register | Supabase Auth OAuth provider |
| Forgot password | `src/pages/ForgotPassword.jsx` | `resetPasswordForEmail` |
| Reset password | `src/pages/ResetPassword.jsx` | `updateUser` after the recovery link |
| Session handling | `src/lib/AuthContext.jsx` | Supabase session (localStorage, auto-refresh) |
| Route protection | `src/components/ProtectedRoute.jsx` | Session check |

## 3. Dashboard (10 screens)

| Screen | File | Reads / writes |
| --- | --- | --- |
| Overview | `dashboard/Overview.jsx` | counts of cards, bookings, enquiries, events |
| My cards | `dashboard/MyCards.jsx` | `cards` list, duplicate, archive, delete |
| Card editor | `dashboard/CardEditor.jsx` | `cards` create/update, autosave, slug, publish |
| Share & NFC hub | `dashboard/CardShare.jsx` | card link, QR, print sheet, NFC guidance |
| Bookings | `dashboard/Bookings.jsx` | `bookings` list + `updateBookingStatus` |
| Enquiries | `dashboard/Enquiries.jsx` | `enquiries` list, status, notes |
| Contacts | `dashboard/Contacts.jsx` | `contacts` list, tags, notes, vCard, CSV |
| Analytics | `dashboard/Analytics.jsx` | `card_events` aggregated by day and type |
| Settings | `dashboard/Settings.jsx` | `app_users` profile, `deleteMyData` |
| Shell | `dashboard/DashboardLayout.jsx` | navigation, responsive sidebar |

## 4. Card authoring

- 8 categories (visiting, wedding, menu, identity, product, catalog, event, property) and 20 templates
  (`src/lib/templates.js`, `src/components/card/*`).
- Live canvas preview (`CardCanvas`, `ScaledCanvas`, `cardBlocks`), 4 typographic styles, accent colour.
- Image uploads for portrait and cover (`components/dashboard/ImageUploader.jsx`) → Supabase Storage.
- Repeatable rows: items, details, socials (`ListEditor.jsx`).
- Publishing with slug, draft/published/archived states, `PublishPanel.jsx`.
- Quality score + suggestions (`CompletenessPanel.jsx`, `src/lib/completeness.js`).
- AI copilot (`AiCopilot.jsx` → `aiCopilot` function): returns a draft, applied by the owner only.

## 5. Public card page (`src/pages/PublicCard.jsx`)

- Renders a published card by slug at `/c/:slug`, branded 404 for missing/unpublished.
- Contact taps (phone, email, website, socials) each tracked as `card_events`.
- QR code, native share, copy-link (`components/public/ShareActions.jsx`, `QrCodeMini`).
- Booking flow (`BookingForm.jsx` → `cardSlots`, `submitBooking`).
- Enquiry form (`EnquiryForm.jsx` → `submitEnquiry`).
- Contact exchange (`ContactExchange.jsx` → `submitContact`).
- Print/PDF export and vCard download (`src/lib/exports.js`).

## 6. Backend functions (migrated 1:1)

| Function | Purpose | Auth | Depends on |
| --- | --- | --- | --- |
| `submitBooking` | validate slot, create booking, email owner | public | cards, bookings, app_users, email |
| `submitEnquiry` | validate + store an enquiry | public | cards, enquiries |
| `submitContact` | store/refresh a contact exchange + event | public | cards, contacts, card_events |
| `trackEvent` | record a view/share/QR/tap event | public | cards, card_events |
| `cardSlots` | return available slots for the next N days | public | cards, bookings |
| `updateBookingStatus` | guarded status transitions + visitor email | signed in | bookings, email |
| `deleteMyData` | erase the caller's cards and derived rows | signed in | all tables |
| `aiCopilot` | natural-language card draft | signed in | LLM provider |

Shared helpers: `supabase/functions/_shared/{cors,supabase,email}.ts` (single source, imported by all
functions — no copies).

## 7. Data entities (5 business + 1 profile)

`Card`, `Booking`, `Enquiry`, `Contact`, `CardEvent` map to `cards`, `bookings`, `enquiries`,
`contacts`, `card_events`. The platform `User` entity became `app_users` (profile + role, one row per
Supabase auth user).

## 8. Integrations and infrastructure

| Original | Replacement | State |
| --- | --- | --- |
| Base44 database SDK | Supabase PostgREST via `zetaClient.js` | migrated |
| Base44 auth + OTP | Supabase Auth | migrated (OAuth/email need provider config) |
| Base44 file storage | Supabase Storage `card-media` | migrated |
| Base44 backend functions | Supabase Edge Functions | migrated |
| Base44 `SendEmail` | Resend HTTP API (`_shared/email.ts`) | needs API key |
| `InvokeLLM` (copilot) | OpenAI-compatible chat completions | needs API key |
| Base44 scheduled tasks / workflows | none existed in the app | n/a |

## 9. Deliberately not present

There were no workflows, scheduled jobs, agents, webhooks or payment integrations in the source
application, so there was nothing to migrate in those areas. The QR generator is client-side
(`qrcode`), and NFC uses the device's native browser/NFC writer — neither depends on a server.
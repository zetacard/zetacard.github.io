# SECURITY AUDIT

Scope: the portable ZetaCard project in this package, plus the Supabase objects created for it.

## 1. Secrets

- `VITE_*` variables are the only values exposed to the browser: the project URL and the
  publishable (anon) key. Both are designed to be public.
- The service-role key is used **only** inside `supabase/functions/*` through
  `Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")`. Supabase injects it at runtime; it never appears in
  the repository, in `.env.example`, or in any frontend file.
- No `.env`, key file, token or password is included in this package. `.gitignore` excludes every
  `.env*` variant except `.env.example`.
- Third-party credentials (`RESEND_API_KEY`, `AI_API_KEY`) are documented as function secrets only.

Verified by search: no occurrence of a key literal, `service_role` string in `src/`, or private
value anywhere in the frontend bundle.

## 2. Authentication

- Supabase Auth owns credentials, sessions and tokens. The application never stores passwords.
- Sessions live in Supabase's own storage with auto-refresh; sign-out clears them server-side as
  well as locally.
- Protected routes are gated by `ProtectedRoute`; the dashboard and its children are unreachable
  without a session.
- Password reset uses a single-use recovery token; the app never reveals whether an address exists
  (the form always reports success).
- Email verification is enforced by Supabase (6-digit code, `verifyOtp`).
- Recommendation: enable **leaked password protection** and a minimum length in
  Authentication → Providers → Email.

## 3. Authorisation (database-enforced)

Row Level Security is the security boundary, not the UI:

- Audience: a logged-out visitor can read only `status = 'published'` cards.
- Ownership: `created_by_id` / `owner_id` must equal `auth.uid()` for every read and write of
  cards, bookings, enquiries, contacts and events.
- Personal data (`contacts`) is never readable by another user or by anonymous visitors.
- Visitor-submitted rows (bookings, enquiries, contacts, events) have **no INSERT policy**. They can
  only be written by edge functions holding the service role, after validation.
- Role escalation is blocked by `zetacard_guard_app_user_role`: a user cannot change their own
  `role`, and `role` is never trusted from the client.

Evidence (executed against the live project):

| Attempt | Result |
| --- | --- |
| Anonymous `INSERT` into `cards` | rejected — `42501 new row violates row-level security policy` |
| Anonymous `SELECT` of `contacts` | empty set |
| Anonymous `SELECT` of unpublished cards | empty set |
| Service-role insert/update/delete | allowed (server-side only) |

## 4. Server-side validation

Every edge function re-validates its own input; the browser is never trusted:

- `submitBooking`: field length clamps, email/date/time regex, card must be published with booking
  enabled, slot must exist in the availability window, date not in the past and within 60 days,
  same-day cut-off in the card's timezone, and a clash check on `(card_id, date, time)`.
- `submitContact`: name ≥ 2 chars, valid email, explicit consent required, card published with
  exchange enabled, max 3 submissions per address per hour, one record per person per card.
- `submitEnquiry`: message ≥ 10 chars, valid email, card published with enquiries enabled,
  duplicate guard of 2 minutes.
- `trackEvent`: event type must be on the allowlist; card must exist and be published.
- `updateBookingStatus`: requires a session, ownership check, and a strict transition table
  (pending→confirmed/cancelled, confirmed→completed/cancelled).
- `deleteMyData`: requires a session and the literal confirmation string `DELETE`; scoped to the
  caller's own rows.
- `aiCopilot`: requires a session, caps every field and row count, refuses invented contact data,
  and returns a draft only — it never writes to the database.

## 5. Storage

- Bucket `card-media` is public **read** (card images appear on public card pages), with upload,
  update and delete restricted to `authenticated` users inside their own `<uid>/…` folder.
- File names are sanitised and prefixed with the owner's user id, so one user cannot overwrite
  another's media.

## 6. Email and abuse

- Transactional email is sent server-side only, from a fixed template. Recipients are never taken
  from request input in a way that could turn the app into an open relay: booking mail goes to the
  card owner (looked up in the database) or to the stored `visitor_email` of an existing booking.
- No email content is interpolated from unvalidated HTML.
- Public write endpoints are throttled (see §4) and always validate the target card first.

## 7. Client-side observations

- No `dangerouslySetInnerHTML` with user content. React escapes all rendered record fields.
- External links rendered from card data use `rel="noreferrer"`/`noopener` in the sharing
  components.
- The AI copilot's output is filtered against a schema and an allowlist (`template_id`, 6-hex accent)
  before it can reach the editor.

## 8. Known gaps to close before high-volume launch

1. Set `RESEND_API_KEY` and a verified sending domain, otherwise booking emails report `skipped` and
   the app states so honestly.
2. Add rate limiting at the edge (Supabase does not throttle public functions by default) — e.g.
   Cloudflare or a per-IP counter table.
3. Enable Supabase Auth email rate limits and CAPTCHA if the public form traffic grows.
4. Rotate the service-role key if it has ever been pasted into a chat or a repository.
5. Review `app_users` roles: the first admin must be promoted deliberately
   (`update public.app_users set role = 'admin' where email = 'you@example.com';`).
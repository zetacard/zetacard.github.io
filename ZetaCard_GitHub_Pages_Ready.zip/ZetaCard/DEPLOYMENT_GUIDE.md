# DEPLOYMENT GUIDE

Three things get deployed: the database (migrations), the edge functions, and the static frontend.
Any order works, but this order avoids a half-working app.

## 0. Prerequisites

- Node 18+ and npm
- A Supabase project (already provisioned for you during this migration: `zetacard`,
  ref `sojuhiuydumpouknkmat`)
- The Supabase CLI: `npm install -g supabase` (or use `npx supabase`)

## 1. Database

The migrations are already applied to your project. To apply them to a fresh project, or to another
environment:

```bash
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase db push
```

Or paste `supabase/migrations/0001_schema.sql`, `0002_rls.sql`, `0003_storage.sql` into the Supabase
SQL editor in that order. Both routes are idempotent.

Verify:

```bash
SUPABASE_URL=https://YOUR_REF.supabase.co \
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key \
node scripts/verify-migration.mjs
```

Expect: 6 tables reachable, insert/update/delete on `cards` passing, bucket `card-media` present.

## 2. Authentication settings

In Supabase → Authentication → URL configuration:

- **Site URL:** your production URL (e.g. `https://zetacard.yourdomain.com`)
- **Redirect URLs:** `https://zetacard.yourdomain.com/**` and `http://localhost:5173/**`

In Authentication → Providers → Email, keep **Confirm email** ON, and set the "Confirm signup"
template to include the 6-digit code so the app's OTP screen works:

```html
<p>Your ZetaCard verification code is <strong>{{ .Token }}</strong></p>
```

Optional: enable Google (client id + secret) if you want the "Continue with Google" button live.

To make yourself an administrator:

```sql
update public.app_users set role = 'admin' where email = 'you@example.com';
```

## 3. Edge functions

```bash
npx supabase functions deploy
```

Set the secrets once (server-side only, never in `.env.local`):

```bash
npx supabase secrets set \
  RESEND_API_KEY=re_your_key \
  EMAIL_FROM="ZetaCard <hello@yourdomain.com>" \
  AI_API_KEY=your_llm_key \
  AI_MODEL=gpt-4o-mini
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` are injected by Supabase
automatically — do not set them yourself.

JWT settings per function are declared in `supabase/config.toml` (public visitor functions accept
anonymous calls; owner functions require a session).

## 4. Frontend

```bash
npm install
cp .env.example .env.local     # add VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY
npm run build                  # -> dist/
```

Host `dist/` anywhere static:

- **Vercel:** import the repo, framework "Vite", add the two `VITE_` env vars, deploy.
- **Netlify:** build `npm run build`, publish `dist`, add the env vars.
- **Cloudflare Pages:** build `npm run build`, output `dist`.
- **Any SPA host:** single-page routing needs a rewrite of unknown paths to `index.html`.
  Netlify: `/*  /index.html  200`. Vercel: `{"rewrites":[{"source":"/(.*)","destination":"/index.html"}]}`.

Because the public card route is `/c/:slug`, that rewrite rule is required.

## 5. Smoke test after deploying

1. Open `/` — marketing site loads.
2. Register a new account → 6-digit code arrives → verify → lands in `/dashboard`.
3. Create a card, upload a cover image, publish it.
4. Open `/c/<slug>` in a private window → card renders; the view appears in Analytics.
5. Submit a booking from the public card → it appears under Bookings; confirm it → the visitor email
   is attempted and the result is shown honestly in the email column.
6. Settings → delete-account flow with the `DELETE` confirmation removes the data.

## 6. Moving hosting later

The frontend is a static bundle and the backend lives entirely in Supabase, so switching hosts means
re-uploading `dist/` and updating two URLs (Supabase Site URL and `VITE_APP_BASE_URL`). No code
change required.
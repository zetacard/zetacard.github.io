import React, { useMemo } from "react";
import { Check, AlertCircle, Circle } from "lucide-react";
import { analyzeCard } from "@/lib/completeness";

const DOT = {
  high: "bg-destructive",
  medium: "bg-amber-500",
  low: "bg-muted-foreground/40"
};

export default function CompletenessPanel({ card, onFocus }) {
  const { score, issues } = useMemo(() => analyzeCard(card), [card]);
  const shown = issues.slice(0, 4);

  return (
    <section className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-baseline justify-between">
        <h2 className="text-[12.5px] font-medium">Card quality</h2>
        <span className="text-[12.5px] font-medium tabular-nums">{score}%</span>
      </div>
      <div className="mt-2 h-1.5 rounded-full bg-secondary overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${score >= 85 ? "bg-primary" : score >= 55 ? "bg-amber-500" : "bg-destructive"}`}
          style={{ width: `${score}%` }}
        />
      </div>

      {shown.length === 0 ? (
        <p className="mt-3 flex items-start gap-2 text-[11.5px] leading-relaxed text-muted-foreground">
          <Check className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
          Everything essential is in place. A clear card is easier to trust — publish it when you are ready.
        </p>
      ) : (
        <>
          <ul className="mt-3 space-y-1.5">
            {shown.map((issue) => {
              const clickable = Boolean(issue.field && onFocus);
              return (
                <li key={issue.id}>
                  <button
                    type="button"
                    disabled={!clickable}
                    onClick={() => clickable && onFocus(issue.field)}
                    className={`flex w-full items-start gap-2 rounded-lg px-1.5 py-1 text-left text-[11.5px] leading-snug ${
                      clickable ? "hover:bg-secondary" : "cursor-default"
                    }`}
                    title={issue.hint || ""}
                  >
                    <span className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${DOT[issue.level]}`} />
                    <span className={clickable ? "text-foreground/80" : "text-muted-foreground"}>{issue.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
          {issues.length > shown.length && (
            <p className="mt-2 px-1.5 text-[11px] text-muted-foreground">+{issues.length - shown.length} smaller suggestion{issues.length - shown.length > 1 ? "s" : ""}</p>
          )}
          <p className="mt-3 flex items-start gap-1.5 px-1.5 text-[10.5px] leading-relaxed text-muted-foreground">
            <AlertCircle className="w-3 h-3 mt-0.5 shrink-0" />
            A completeness score reflects card content only — not results.
          </p>
        </>
      )}
    </section>
  );
}
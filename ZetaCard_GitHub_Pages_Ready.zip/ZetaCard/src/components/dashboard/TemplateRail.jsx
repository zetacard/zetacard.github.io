import React from "react";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import { templatesFor } from "@/lib/templates";

export default function TemplateRail({ card, onSelect }) {
  const templates = templatesFor(card.category);

  return (
    <div className="w-full max-w-full min-w-0 -mx-1 px-1 overflow-x-auto no-scrollbar">
      <div className="flex gap-3 pb-2">
        {templates.map((template) => {
          const active = template.id === card.template_id;
          return (
            <button
              key={template.id}
              type="button"
              onClick={() => onSelect(template.id)}
              className={`shrink-0 w-[132px] text-left rounded-xl overflow-hidden border-2 transition-all ${
                active ? "border-primary shadow-[0_0_0_3px_hsl(var(--primary)/0.12)]" : "border-transparent hover:border-border"
              }`}
              aria-pressed={active}
              title={template.name}
            >
              <div className="rounded-lg overflow-hidden border border-border bg-secondary">
                <ScaledCanvas card={{ ...card, template_id: template.id }} radius={0} />
              </div>
              <div className={`mt-1.5 px-0.5 text-[10.5px] truncate ${active ? "text-primary font-medium" : "text-muted-foreground"}`}>
                {template.name}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
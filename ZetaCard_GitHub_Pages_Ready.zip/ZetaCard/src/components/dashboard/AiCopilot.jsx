import React, { useState } from "react";
import { Sparkles, Loader2, AlertCircle, Check, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { templatesFor } from "@/lib/templates";

const CHIPS = [
  "Make this card more professional",
  "Suggest a better design",
  "Rewrite my description",
  "What is missing?"
];

const FIELD_LABELS = {
  headline: "Name",
  subheadline: "Role or tagline",
  organization: "Business name",
  about: "Description",
  phone: "Phone",
  email: "Email",
  website: "Website",
  address: "Address",
  items: "Items",
  details: "Details",
  socials: "Social links",
  template_id: "Design",
  accent: "Accent colour"
};

const CARD_FIELDS = [
  "category", "template_id", "headline", "subheadline", "organization", "about",
  "phone", "email", "website", "address", "items", "details", "socials"
];

function snapshot(card) {
  return CARD_FIELDS.reduce((acc, key) => {
    acc[key] = card[key];
    return acc;
  }, {});
}

export default function AiCopilot({ card, onApply }) {
  const [prompt, setPrompt] = useState("");
  const [status, setStatus] = useState("idle");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [applied, setApplied] = useState(false);

  const run = async () => {
    const instruction = prompt.trim();
    if (instruction.length < 3 || status === "running") return;
    setError("");
    setApplied(false);
    setStatus("running");
    try {
      const response = await base44.functions.invoke("aiCopilot", {
        instruction,
        card: snapshot(card),
        allowed_templates: templatesFor(card.category).map((template) => template.id)
      });
      if (response.data?.error) {
        setError(response.data.error);
        setStatus("idle");
        return;
      }
      setResult(response.data);
      setStatus("done");
    } catch (err) {
      setError(err?.response?.data?.error || "The copilot is unavailable right now. You can keep editing manually.");
      setStatus("idle");
    }
  };

  const entries = result ? Object.entries(result.changes || {}) : [];

  const apply = () => {
    onApply(result.changes);
    setApplied(true);
    setResult(null);
    setStatus("idle");
    setPrompt("");
  };

  return (
    <section className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-primary" />
        <h2 className="text-[12.5px] font-medium">AI copilot</h2>
      </div>
      <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
        Describe a change. You review the draft before anything is applied.
      </p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {CHIPS.map((chip) => (
          <button
            key={chip}
            type="button"
            onClick={() => setPrompt(chip)}
            className="rounded-full border border-border px-2.5 py-1 text-[10.5px] text-muted-foreground hover:border-foreground/30 hover:text-foreground transition-colors"
          >
            {chip}
          </button>
        ))}
      </div>

      <Textarea
        value={prompt}
        onChange={(event) => setPrompt(event.target.value)}
        rows={2}
        maxLength={500}
        placeholder="e.g. Rewrite my description for an architecture studio, keep it short."
        className="mt-2.5 text-[12.5px]"
      />

      <Button
        type="button"
        onClick={run}
        disabled={status === "running" || prompt.trim().length < 3}
        className="mt-2 h-9 w-full rounded-lg text-[12px]"
      >
        {status === "running" ? (
          <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Drafting</>
        ) : (
          <><Sparkles className="w-3.5 h-3.5 mr-1.5" /> Draft changes</>
        )}
      </Button>

      {error && (
        <div className="mt-2 flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-2.5 py-2 text-[11px] text-destructive">
          <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {error}
        </div>
      )}

      {applied && !result && (
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-primary">
          <Check className="w-3.5 h-3.5" /> Applied — save or publish when you are ready.
        </p>
      )}

      {result && (
        <div className="mt-3 rounded-xl border border-border bg-secondary/40 p-3">
          <div className="flex items-start justify-between gap-2">
            <p className="text-[11.5px] leading-relaxed text-foreground/80">{result.summary}</p>
            <button
              type="button"
              onClick={() => { setResult(null); setStatus("idle"); }}
              className="text-muted-foreground hover:text-foreground"
              aria-label="Dismiss suggestion"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {entries.length === 0 ? (
            <p className="mt-2 text-[11px] text-muted-foreground">No changes suggested for this request.</p>
          ) : (
            <ul className="mt-2 space-y-1.5">
              {entries.map(([key, value]) => (
                <li key={key} className="text-[11px]">
                  <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{FIELD_LABELS[key] || key}</div>
                  <div className="mt-0.5 leading-snug text-foreground/85">
                    {Array.isArray(value)
                      ? `${value.length} row${value.length === 1 ? "" : "s"}: ${value.map((row) => row.name || row.label || "").filter(Boolean).join(", ")}`
                      : value}
                  </div>
                </li>
              ))}
            </ul>
          )}

          {entries.length > 0 && (
            <div className="mt-3 flex gap-2">
              <Button type="button" size="sm" className="h-8 rounded-lg text-[11.5px]" onClick={apply}>
                Apply changes
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="h-8 rounded-lg text-[11.5px]"
                onClick={() => { setResult(null); setStatus("idle"); }}
              >
                Discard
              </Button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
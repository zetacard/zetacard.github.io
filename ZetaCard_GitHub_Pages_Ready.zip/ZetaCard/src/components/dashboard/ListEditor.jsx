import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ListEditor({ label, hint, items = [], fields, onChange, addLabel = "Add item", max = 12 }) {
  const list = Array.isArray(items) ? items : [];

  const update = (index, key, value) => {
    onChange(list.map((item, i) => (i === index ? { ...item, [key]: value } : item)));
  };

  const add = () => {
    const blank = {};
    fields.forEach((f) => {
      blank[f.key] = "";
    });
    onChange([...list, blank]);
  };

  const remove = (index) => onChange(list.filter((_, i) => i !== index));

  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <div className="text-[12.5px] font-medium">{label}</div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-[11.5px]"
          onClick={add}
          disabled={list.length >= max}
        >
          <Plus className="w-3 h-3 mr-1" /> {addLabel}
        </Button>
      </div>
      {hint && <p className="text-[11px] text-muted-foreground mb-2">{hint}</p>}
      <div className="space-y-2">
        {list.length === 0 && (
          <div className="rounded-lg border border-dashed border-border px-3 py-2.5 text-[11.5px] text-muted-foreground">
            Nothing added yet.
          </div>
        )}
        {list.map((item, index) => (
          <div key={index} className="rounded-xl border border-border bg-secondary/40 p-2.5">
            <div className="flex gap-2 items-start">
              <div className={`grid gap-2 flex-1 ${fields.length > 2 ? "sm:grid-cols-2" : "grid-cols-2"}`}>
                {fields.map((field) => (
                  <Input
                    key={field.key}
                    value={item[field.key] || ""}
                    onChange={(e) => update(index, field.key, e.target.value)}
                    placeholder={field.placeholder}
                    aria-label={field.placeholder}
                    className={`h-9 text-[12.5px] ${field.wide ? "sm:col-span-2" : ""}`}
                  />
                ))}
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-9 w-8 px-0 text-muted-foreground hover:text-destructive shrink-0"
                onClick={() => remove(index)}
                aria-label="Remove row"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
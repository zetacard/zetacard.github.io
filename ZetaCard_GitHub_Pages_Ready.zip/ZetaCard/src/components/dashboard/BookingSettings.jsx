import React from "react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { CATEGORIES } from "@/lib/templates";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const ZONES = [
  "Asia/Kolkata",
  "Asia/Dubai",
  "Asia/Singapore",
  "Europe/London",
  "Europe/Berlin",
  "America/New_York",
  "America/Los_Angeles",
  "Australia/Sydney",
  "UTC"
];

export default function BookingSettings({ card, onChange }) {
  const category = CATEGORIES.find((c) => c.id === card.category);
  const availability = card.availability || {};
  const days = Array.isArray(availability.days) ? availability.days : [1, 2, 3, 4, 5];

  const setAvailability = (patch) => {
    onChange("availability", {
      days,
      start: "09:00",
      end: "17:00",
      slot_minutes: 30,
      timezone: "Asia/Kolkata",
      ...availability,
      ...patch
    });
  };

  const toggleDay = (day) => {
    const next = days.includes(day) ? days.filter((d) => d !== day) : [...days, day].sort();
    setAvailability({ days: next });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <Label htmlFor="enquiries" className="text-[12.5px] font-medium">Accept enquiries</Label>
          <p className="text-[11.5px] text-muted-foreground mt-0.5">
            Adds a message form to your public card. Messages land in your inbox.
          </p>
        </div>
        <Switch
          id="enquiries"
          checked={card.enquiry_enabled !== false}
          onCheckedChange={(v) => onChange("enquiry_enabled", v)}
        />
      </div>

      {category?.supports?.booking && (
        <>
          <div className="h-px bg-border" />
          <div className="flex items-start justify-between gap-4">
            <div>
              <Label htmlFor="booking" className="text-[12.5px] font-medium">Accept bookings</Label>
              <p className="text-[11.5px] text-muted-foreground mt-0.5">
                Visitors pick a real slot. Requests arrive as pending until you confirm.
              </p>
            </div>
            <Switch
              id="booking"
              checked={!!card.booking_enabled}
              onCheckedChange={(v) => onChange("booking_enabled", v)}
            />
          </div>

          {card.booking_enabled && (
            <div className="space-y-4 rounded-xl border border-border bg-secondary/40 p-4">
              <div>
                <div className="text-[12px] font-medium mb-2">Open days</div>
                <div className="flex flex-wrap gap-1.5">
                  {DAYS.map((label, index) => (
                    <button
                      key={label}
                      type="button"
                      onClick={() => toggleDay(index)}
                      className={`px-2.5 py-1.5 rounded-lg text-[11.5px] border transition-colors ${
                        days.includes(index)
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                {days.length === 0 && (
                  <p className="mt-2 text-[11px] text-destructive">Select at least one day, or nobody can book.</p>
                )}
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label className="text-[11px] text-muted-foreground">From</Label>
                  <Input
                    type="time"
                    value={availability.start || "09:00"}
                    onChange={(e) => setAvailability({ start: e.target.value })}
                    className="h-9 text-[12.5px] mt-1"
                  />
                </div>
                <div>
                  <Label className="text-[11px] text-muted-foreground">To</Label>
                  <Input
                    type="time"
                    value={availability.end || "17:00"}
                    onChange={(e) => setAvailability({ end: e.target.value })}
                    className="h-9 text-[12.5px] mt-1"
                  />
                </div>
                <div>
                  <Label className="text-[11px] text-muted-foreground">Slot</Label>
                  <select
                    value={availability.slot_minutes || 30}
                    onChange={(e) => setAvailability({ slot_minutes: Number(e.target.value) })}
                    className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-[12.5px]"
                  >
                    {[15, 20, 30, 45, 60].map((m) => <option key={m} value={m}>{m} min</option>)}
                  </select>
                </div>
              </div>

              <div>
                <Label className="text-[11px] text-muted-foreground">Time zone</Label>
                <select
                  value={availability.timezone || "Asia/Kolkata"}
                  onChange={(e) => setAvailability({ timezone: e.target.value })}
                  className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-[12.5px]"
                >
                  {ZONES.map((zone) => <option key={zone} value={zone}>{zone}</option>)}
                </select>
                <p className="mt-1.5 text-[11px] text-muted-foreground">
                  Slots are shown to visitors in this time zone.
                </p>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
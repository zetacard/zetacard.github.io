import React, { useRef, useState } from "react";
import { Upload, Loader2, X, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";

export default function ImageUploader({ label, hint, value, onChange, aspect = "1 / 1" }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const pick = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!/^image\/(png|jpe?g|webp|gif)$/i.test(file.type)) {
      setError("Choose a PNG, JPG, WEBP or GIF image.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("That image is over 5 MB. Try a smaller one.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      onChange(file_url);
    } catch {
      setError("The upload failed. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <div className="text-[12.5px] font-medium mb-1.5">{label}</div>
      <div className="flex items-start gap-3">
        <div
          className="w-20 rounded-xl border border-border bg-secondary overflow-hidden flex items-center justify-center shrink-0"
          style={{ aspectRatio: aspect }}
        >
          {value ? (
            <img src={value} alt="" className="w-full h-full object-cover" />
          ) : (
            <Upload className="w-4 h-4 text-muted-foreground" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" size="sm" className="h-8 rounded-lg text-[11.5px]" onClick={() => inputRef.current?.click()} disabled={busy}>
              {busy ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Uploading</> : value ? "Replace" : "Upload image"}
            </Button>
            {value && (
              <Button type="button" variant="ghost" size="sm" className="h-8 rounded-lg text-[11.5px] text-muted-foreground" onClick={() => onChange("")}>
                <X className="w-3.5 h-3.5 mr-1" /> Remove
              </Button>
            )}
          </div>
          {hint && <p className="mt-1.5 text-[11px] text-muted-foreground">{hint}</p>}
          {error && (
            <p className="mt-1.5 text-[11px] text-destructive flex items-start gap-1">
              <AlertCircle className="w-3 h-3 mt-0.5 shrink-0" /> {error}
            </p>
          )}
        </div>
      </div>
      <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={pick} className="hidden" />
    </div>
  );
}
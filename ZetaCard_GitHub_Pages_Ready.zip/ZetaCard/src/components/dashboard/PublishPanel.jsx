import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Copy, Download, ExternalLink, QrCode, Globe, EyeOff, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import QrCodeBlock, { downloadQr } from "@/components/card/QrCode";
import { publicCardUrl, slugify } from "@/lib/cardUtils";

export default function PublishPanel({ card, onSlugChange, onPublish, onUnpublish, busy, requiredMissing }) {
  const [copied, setCopied] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const published = card.status === "published" && card.slug;
  const url = published ? publicCardUrl(card.slug) : "";

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center gap-2">
        <Globe className="w-4 h-4 text-primary" />
        <div className="text-[13px] font-medium">Publishing</div>
      </div>

      {published ? (
        <div className="mt-4 space-y-3">
          <div className="rounded-lg border border-border bg-secondary/50 px-3 py-2 flex items-center gap-2">
            <span className="text-[11.5px] text-muted-foreground truncate flex-1">/c/{card.slug}</span>
            <button type="button" onClick={copy} className="text-muted-foreground hover:text-foreground" aria-label="Copy link">
              {copied ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild size="sm" variant="outline" className="h-9 rounded-lg text-[12px]">
              <Link to={`/c/${card.slug}`} target="_blank">View public card <ExternalLink className="w-3 h-3 ml-1.5" /></Link>
            </Button>
            <Button type="button" size="sm" variant="outline" className="h-9 rounded-lg text-[12px]" onClick={() => setQrOpen((v) => !v)}>
              <QrCode className="w-3.5 h-3.5 mr-1.5" /> QR code
            </Button>
          </div>
          {qrOpen && (
            <div className="rounded-xl border border-border p-4 flex flex-col items-center gap-3">
              <QrCodeBlock value={url} size={150} />
              <Button
                type="button"
                size="sm"
                variant="secondary"
                className="h-8 rounded-lg text-[11.5px]"
                onClick={() => downloadQr(url, `${slugify(card.card_name || "zetacard")}-qr.png`)}
              >
                <Download className="w-3.5 h-3.5 mr-1.5" /> Download QR
              </Button>
            </div>
          )}
          <Button type="button" variant="ghost" size="sm" className="h-8 px-2 text-[11.5px] text-muted-foreground" onClick={onUnpublish} disabled={busy}>
            <EyeOff className="w-3.5 h-3.5 mr-1.5" /> Unpublish
          </Button>
        </div>
      ) : (
        <div className="mt-4 space-y-3">
          <div>
            <label htmlFor="slug" className="text-[11.5px] text-muted-foreground">Card address</label>
            <div className="mt-1 flex items-center rounded-lg border border-border overflow-hidden">
              <span className="px-2.5 text-[11.5px] text-muted-foreground bg-secondary/60 h-9 flex items-center">/c/</span>
              <input
                id="slug"
                value={card.slug || ""}
                onChange={(e) => onSlugChange(e.target.value)}
                placeholder="your-name"
                className="flex-1 h-9 px-2 text-[12.5px] bg-transparent outline-none"
              />
            </div>
            <p className="mt-1.5 text-[11px] text-muted-foreground">
              Left blank, we create one from your name when you publish.
            </p>
          </div>
          {requiredMissing.length > 0 && (
            <p className="text-[11.5px] text-destructive">
              Add {requiredMissing.join(", ").toLowerCase()} before publishing.
            </p>
          )}
          <Button type="button" className="w-full h-10 rounded-lg text-[12.5px]" onClick={onPublish} disabled={busy}>
            {busy ? "Publishing…" : "Publish card"}
          </Button>
          <p className="text-[11px] text-muted-foreground">
            Publishing makes the card readable by anyone with its link. You can unpublish at any time.
          </p>
        </div>
      )}
    </div>
  );
}
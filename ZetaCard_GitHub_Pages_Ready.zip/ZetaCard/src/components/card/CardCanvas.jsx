import React, { forwardRef } from "react";
import { getCategory } from "@/lib/templates";
import { resolveLook } from "@/lib/cardUtils";
import {
  About,
  CardName,
  CardRole,
  ContactLines,
  Cover,
  DetailGrid,
  Eyebrow,
  ItemList,
  Org,
  Portrait,
  QRStub,
  Rule,
  SocialLine,
  WhenBlock,
  initials
} from "@/components/card/cardBlocks";

function Mono({ card, theme, u, size = 11 }) {
  return (
    <div
      style={{
        width: size * u,
        height: size * u,
        borderRadius: "50%",
        border: `1.5px solid ${theme.accent}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: theme.accent,
        fontFamily: "'Sora', sans-serif",
        fontSize: size * 0.32 * u,
        letterSpacing: "0.08em",
        flexShrink: 0
      }}
    >
      {initials(card.headline || card.organization)}
    </div>
  );
}

function body(card, theme, font, u) {
  if (card.items?.length) {
    return (
      <div style={{ maxHeight: 34 * u, overflow: "hidden" }}>
        <ItemList card={card} theme={theme} font={font} u={u} compact />
      </div>
    );
  }
  return <About card={card} theme={theme} font={font} u={u} lines={4} />;
}

const LAYOUTS = {
  monogram: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 8 * u, gap: 1.6 * u }}>
      <div style={{ position: "absolute", inset: 4 * u, border: `1px solid ${theme.ink}22` }} />
      <Mono card={card} theme={theme} u={u} size={10} />
      <Org card={card} theme={theme} font={font} u={u} style={{ letterSpacing: "0.24em", textTransform: "uppercase", fontSize: 1.4 * u, color: theme.muted, fontWeight: 500 }} />
      <CardName card={card} theme={theme} font={font} u={u} size={4.6} align="center" />
      <CardRole card={card} theme={theme} font={font} u={u} align="center" style={{ opacity: 0.7 }} />
      <div style={{ width: 8 * u, height: 1, background: theme.accent, opacity: 0.8 }} />
      <ContactLines card={card} theme={theme} font={font} u={u} style={{ justifyItems: "center", textAlign: "center" }} />
      <SocialLine card={card} theme={theme} font={font} u={u} style={{ justifyContent: "center" }} />
    </div>
  ),

  "split-edge": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex" }}>
      <div style={{ width: "36%", background: theme.ink, color: theme.bg, padding: 5 * u, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
        <div style={{ fontFamily: "'Sora', sans-serif", fontSize: 4.6 * u, letterSpacing: "0.06em" }}>{initials(card.headline || card.organization)}</div>
        <div style={{ writingMode: "vertical-rl", transform: "rotate(180deg)", fontFamily: font.body, fontSize: 1.35 * u, letterSpacing: "0.24em", textTransform: "uppercase", opacity: 0.75 }}>
          {card.organization || "Digital card"}
        </div>
        <QRStub theme={{ ...theme, accent: theme.bg, muted: theme.bg }} u={u * 0.8} label="Scan" />
      </div>
      <div style={{ flex: 1, padding: `${7 * u}px ${7 * u}px`, display: "flex", flexDirection: "column", gap: 1.4 * u }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization || getCategory(card.category).short}</Eyebrow>
        <CardName card={card} theme={theme} font={font} u={u} size={4.4} />
        <CardRole card={card} theme={theme} font={font} u={u} />
        <Rule theme={theme} u={u} style={{ marginTop: 0.8 * u, marginBottom: 0.8 * u }} />
        <div style={{ flex: 1 }}>{body(card, theme, font, u)}</div>
        <ContactLines card={card} theme={theme} font={font} u={u} />
      </div>
    </div>
  ),

  editorial: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", padding: 7 * u, display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", borderBottom: `1px solid ${theme.ink}22`, paddingBottom: 1.4 * u }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization || "ZetaCard"}</Eyebrow>
        <Eyebrow theme={theme} font={font} u={u}>{new Date().getFullYear()}</Eyebrow>
      </div>
      <div style={{ marginTop: 3 * u }}>
        <CardName card={card} theme={theme} font={font} u={u} size={6.4} />
        <CardRole card={card} theme={theme} font={font} u={u} style={{ marginTop: 1.2 * u, fontStyle: "italic" }} />
      </div>
      <div style={{ flex: 1, display: "flex", gap: 5 * u, marginTop: 3 * u, minHeight: 0 }}>
        <div style={{ flex: 1.1, minWidth: 0 }}>{body(card, theme, font, u)}</div>
        <div style={{ width: 1, background: `${theme.ink}22` }} />
        <div style={{ flex: 0.9, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <WhenBlock card={card} theme={theme} font={font} u={u} />
          <DetailGrid card={card} theme={theme} font={font} u={u} columns={1} />
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.45 * u }} />
        </div>
      </div>
      <SocialLine card={card} theme={theme} font={font} u={u} style={{ marginTop: 1.6 * u }} />
    </div>
  ),

  "banner-top": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ background: theme.ink, color: theme.bg, padding: `${5 * u}px ${6 * u}px`, display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 3 * u }}>
        <div>
          <div style={{ fontFamily: font.body, fontSize: 1.35 * u, letterSpacing: "0.24em", textTransform: "uppercase", opacity: 0.62, marginBottom: 1 * u }}>
            {card.organization || getCategory(card.category).short}
          </div>
          <div style={{ fontFamily: font.heading, fontSize: 4.4 * u, lineHeight: 1.02, letterSpacing: font.tracking }}>
            {card.headline || card.card_name}
          </div>
          <div style={{ fontFamily: font.body, fontSize: 1.8 * u, opacity: 0.75, marginTop: 0.8 * u }}>{card.subheadline}</div>
        </div>
        <div style={{ width: 9 * u, height: 9 * u, borderRadius: 1.2 * u, background: theme.accent, display: "flex", alignItems: "center", justifyContent: "center", color: theme.bg, fontFamily: "'Sora', sans-serif", fontSize: 3 * u }}>
          {initials(card.headline)}
        </div>
      </div>
      <div style={{ flex: 1, padding: `${4 * u}px ${6 * u}px`, display: "flex", gap: 4 * u, minHeight: 0 }}>
        <div style={{ flex: 1.2, minWidth: 0 }}>{body(card, theme, font, u)}</div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 1.2 * u }}>
          <WhenBlock card={card} theme={theme} font={font} u={u} />
          <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ marginTop: "auto", gap: 0.4 * u }} />
        </div>
      </div>
      <div style={{ height: 1.4 * u, background: theme.accent }} />
    </div>
  ),

  diagonal: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", position: "relative" }}>
      <div style={{ position: "absolute", inset: 0, background: theme.accent, opacity: 0.14, clipPath: "polygon(0 0, 62% 0, 38% 100%, 0 100%)" }} />
      <div style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: "4px", background: theme.accent }} />
      <div style={{ position: "relative", height: "100%", padding: 6.5 * u, display: "flex", flexDirection: "column" }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization || getCategory(card.category).short}</Eyebrow>
        <div style={{ marginTop: 4 * u, maxWidth: "64%" }}>
          <CardName card={card} theme={theme} font={font} u={u} size={4.8} />
          <CardRole card={card} theme={theme} font={font} u={u} style={{ marginTop: 1 * u }} />
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ display: "grid", gridTemplateColumns: "1.15fr 1fr", gap: 4 * u, alignItems: "end" }}>
          <div>{body(card, theme, font, u)}</div>
          <div style={{ display: "grid", gap: 1.4 * u }}>
            <WhenBlock card={card} theme={theme} font={font} u={u} />
            <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
            <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.4 * u }} />
          </div>
        </div>
      </div>
    </div>
  ),

  grid: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", padding: 5 * u, gap: 2 * u }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <Eyebrow theme={theme} font={font} u={u}>{card.organization || "Index"}</Eyebrow>
          <CardName card={card} theme={theme} font={font} u={u} size={3.9} style={{ marginTop: 0.8 * u }} />
        </div>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 1.3 * u, color: theme.accent }}>{card.category.toUpperCase()}</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderTop: `1px solid ${theme.ink}22`, borderLeft: `1px solid ${theme.ink}22`, flex: 1, minHeight: 0 }}>
        {[
          ["Role", card.subheadline],
          ["Phone", card.phone],
          ["Email", card.email],
          ["Web", card.website?.replace(/^https?:\/\//, "")],
          ["Address", card.address],
          ["Focus", (card.details || [])[0]?.value || card.venue]
        ].map(([label, value], i) => (
          <div key={i} style={{ padding: 1.8 * u, borderRight: `1px solid ${theme.ink}22`, borderBottom: `1px solid ${theme.ink}22`, minWidth: 0 }}>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 1.15 * u, letterSpacing: "0.14em", textTransform: "uppercase", color: theme.muted, marginBottom: 0.5 * u }}>
              {label}
            </div>
            <div style={{ fontFamily: font.body, fontSize: 1.55 * u, color: theme.ink, overflow: "hidden", textOverflow: "ellipsis", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>
              {value || "—"}
            </div>
          </div>
        ))}
      </div>
      {card.items?.length ? (
        <div style={{ maxHeight: 26 * u, overflow: "hidden" }}>
          <ItemList card={card} theme={theme} font={font} u={u} compact />
        </div>
      ) : null}
    </div>
  ),

  "stack-minimal": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", padding: 8 * u, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ width: 1.6 * u, height: 1.6 * u, borderRadius: "50%", background: theme.accent }} />
        <Eyebrow theme={theme} font={font} u={u}>{card.organization}</Eyebrow>
      </div>
      <div style={{ display: "grid", gap: 1.6 * u }}>
        <CardName card={card} theme={theme} font={font} u={u} size={4.2} />
        <CardRole card={card} theme={theme} font={font} u={u} style={{ opacity: 0.55 }} />
        <div style={{ marginTop: 2 * u, maxWidth: "78%" }}>{body(card, theme, font, u)}</div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 3 * u }}>
        <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.5 * u }} />
        <SocialLine card={card} theme={theme} font={font} u={u} />
      </div>
    </div>
  ),

  "photo-circle": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", position: "relative", display: "flex", flexDirection: "column" }}>
      <div style={{ height: "42%", background: theme.soft, position: "relative" }}>
        <Cover card={card} theme={theme} u={u} height={99} style={{ height: "100%" }} />
      </div>
      <div style={{ flex: 1, padding: `${7 * u}px ${7 * u}px ${5 * u}px`, position: "relative" }}>
        <div style={{ position: "absolute", top: -7.5 * u, left: 7 * u }}>
          <Portrait card={card} theme={theme} u={u} size={15} />
        </div>
        <div style={{ marginTop: 8 * u, display: "flex", flexDirection: "column", gap: 1.2 * u, height: "calc(100% - 8rem)" }}>
          <CardName card={card} theme={theme} font={font} u={u} size={3.9} />
          <CardRole card={card} theme={theme} font={font} u={u} />
          <Org card={card} theme={theme} font={font} u={u} style={{ color: theme.accent, fontSize: 1.5 * u }} />
          <Rule theme={theme} u={u} style={{ margin: "0.6rem 0" }} />
          <div style={{ flex: 1, minHeight: 0 }}>{body(card, theme, font, u)}</div>
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.35 * u }} />
        </div>
      </div>
    </div>
  ),

  "frame-double": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", padding: 4 * u, background: theme.soft }}>
      <div style={{ height: "100%", border: `1.5px solid ${theme.ink}`, padding: 1.6 * u }}>
        <div style={{ height: "100%", border: `1px solid ${theme.accent}`, padding: 5 * u, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", gap: 1.3 * u }}>
          <Eyebrow theme={theme} font={font} u={u}>{card.organization || "With compliments"}</Eyebrow>
          <CardName card={card} theme={theme} font={font} u={u} size={4.3} align="center" />
          <CardRole card={card} theme={theme} font={font} u={u} align="center" style={{ opacity: 0.7 }} />
          <div style={{ width: 5 * u, height: 1, background: theme.accent, margin: "0.8rem 0" }} />
          <div style={{ maxWidth: "88%" }}>{body(card, theme, font, u)}</div>
          <WhenBlock card={card} theme={theme} font={font} u={u} align="center" />
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ justifyItems: "center", textAlign: "center", gap: 0.3 * u }} />
        </div>
      </div>
    </div>
  ),

  "ribbon-side": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex" }}>
      <div style={{ flex: 1, padding: `${7 * u}px ${6 * u}px`, display: "flex", flexDirection: "column", gap: 1.2 * u }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization}</Eyebrow>
        <CardName card={card} theme={theme} font={font} u={u} size={4.2} />
        <CardRole card={card} theme={theme} font={font} u={u} />
        <div style={{ flex: 1, marginTop: 1.4 * u, minHeight: 0 }}>{body(card, theme, font, u)}</div>
        <WhenBlock card={card} theme={theme} font={font} u={u} />
        <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
        <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.4 * u }} />
      </div>
      <div style={{ width: 9 * u, background: theme.ink, color: theme.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ writingMode: "vertical-rl", fontFamily: font.body, fontSize: 1.4 * u, letterSpacing: "0.4em", textTransform: "uppercase" }}>
          {card.headline || card.organization || "ZetaCard"}
        </div>
      </div>
      <div style={{ width: 1.4 * u, background: theme.accent }} />
    </div>
  ),

  duotone: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ height: "34%", background: theme.ink, color: theme.bg, padding: 5 * u, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontFamily: "'Sora', sans-serif", fontSize: 9 * u, lineHeight: 0.9, letterSpacing: "-0.04em", opacity: 0.95 }}>
          {initials(card.headline || card.organization)}
        </div>
        <div style={{ textAlign: "right", maxWidth: "55%" }}>
          <div style={{ fontFamily: font.heading, fontStyle: font.italic ? "italic" : "normal", fontSize: 3.2 * u, lineHeight: 1.05 }}>{card.headline}</div>
          <div style={{ fontFamily: font.body, fontSize: 1.4 * u, opacity: 0.7, marginTop: 0.5 * u }}>{card.organization}</div>
        </div>
      </div>
      <div style={{ height: 1.6 * u, background: theme.accent }} />
      <div style={{ flex: 1, padding: 5 * u, display: "flex", gap: 4 * u, minHeight: 0 }}>
        <div style={{ flex: 1.1, minWidth: 0 }}>
          <div style={{ fontFamily: font.body, fontSize: 1.7 * u, fontWeight: 600, marginBottom: 1 * u }}>{card.subheadline}</div>
          {body(card, theme, font, u)}
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 1.2 * u }}>
          <WhenBlock card={card} theme={theme} font={font} u={u} />
          <DetailGrid card={card} theme={theme} font={font} u={u} columns={1} />
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ marginTop: "auto", gap: 0.35 * u }} />
        </div>
      </div>
    </div>
  ),

  ticket: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", padding: 4 * u, background: theme.soft }}>
      <div style={{ height: "100%", display: "flex", background: theme.bg, borderRadius: 2.4 * u, overflow: "hidden", border: `1px solid ${theme.ink}18` }}>
        <div style={{ flex: 1, padding: 5 * u, display: "flex", flexDirection: "column", gap: 1.1 * u, minWidth: 0 }}>
          <Eyebrow theme={theme} font={font} u={u}>{card.organization || "Admit one"}</Eyebrow>
          <CardName card={card} theme={theme} font={font} u={u} size={3.7} />
          <CardRole card={card} theme={theme} font={font} u={u} />
          <div style={{ flex: 1, minHeight: 0, marginTop: 0.6 * u }}>{body(card, theme, font, u)}</div>
          <WhenBlock card={card} theme={theme} font={font} u={u} />
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.3 * u }} />
        </div>
        <div style={{ width: 24 * u, borderLeft: `1.5px dashed ${theme.ink}33`, padding: 2.4 * u, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between", background: theme.soft }}>
          <div style={{ writingMode: "vertical-rl", fontFamily: "'JetBrains Mono', monospace", fontSize: 1.1 * u, letterSpacing: "0.28em", textTransform: "uppercase", color: theme.muted }}>
            {card.category}
          </div>
          <div style={{ fontFamily: font.body, fontSize: 1.2 * u, color: theme.accent, textAlign: "center", lineHeight: 1.4 }}>
            {card.details?.[0]?.value || card.venue || "ZetaCard"}
          </div>
        </div>
      </div>
    </div>
  ),

  "corner-arc": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", width: 46 * u, height: 46 * u, borderRadius: "50%", background: theme.accent, opacity: 0.18, top: -22 * u, right: -14 * u }} />
      <div style={{ position: "absolute", width: 24 * u, height: 24 * u, borderRadius: "50%", border: `1px solid ${theme.accent}`, opacity: 0.5, top: 4 * u, right: 6 * u }} />
      <div style={{ position: "relative", height: "100%", padding: 7 * u, display: "flex", flexDirection: "column", gap: 1.2 * u }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization}</Eyebrow>
        <CardName card={card} theme={theme} font={font} u={u} size={4.3} style={{ maxWidth: "70%" }} />
        <CardRole card={card} theme={theme} font={font} u={u} style={{ maxWidth: "62%" }} />
        <div style={{ flex: 1, minHeight: 0, marginTop: 2 * u, maxWidth: "78%" }}>{body(card, theme, font, u)}</div>
        <Rule theme={theme} u={u} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 3 * u }}>
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.3 * u }} />
          <div style={{ display: "grid", gap: 1 * u }}>
            <WhenBlock card={card} theme={theme} font={font} u={u} />
            <DetailGrid card={card} theme={theme} font={font} u={u} columns={1} />
          </div>
        </div>
      </div>
    </div>
  ),

  columns: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", padding: 6 * u, gap: 5 * u }}>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", borderRight: `1px solid ${theme.ink}22`, paddingRight: 4 * u }}>
        <div>
          <Eyebrow theme={theme} font={font} u={u}>{card.organization}</Eyebrow>
          <CardName card={card} theme={theme} font={font} u={u} size={4.1} style={{ marginTop: 1.4 * u }} />
          <CardRole card={card} theme={theme} font={font} u={u} style={{ marginTop: 0.8 * u }} />
        </div>
        <div>
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.5 * u }} />
          <SocialLine card={card} theme={theme} font={font} u={u} style={{ marginTop: 1.4 * u }} />
        </div>
      </div>
      <div style={{ flex: 1.15, display: "flex", flexDirection: "column", gap: 1.6 * u, minWidth: 0 }}>
        <WhenBlock card={card} theme={theme} font={font} u={u} />
        <div style={{ flex: 1, minHeight: 0 }}>{body(card, theme, font, u)}</div>
        <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
      </div>
    </div>
  ),

  "offset-card": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", padding: 7 * u, background: theme.soft, position: "relative" }}>
      <div style={{ position: "absolute", inset: `${9 * u}px ${5 * u}px ${5 * u}px ${9 * u}px`, background: theme.accent, opacity: 0.25, borderRadius: 2 * u }} />
      <div style={{ position: "relative", height: "100%", background: theme.bg, borderRadius: 2 * u, boxShadow: "0 24px 60px -32px rgba(0,0,0,0.45)", padding: 5.5 * u, display: "flex", flexDirection: "column", gap: 1.2 * u }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <CardName card={card} theme={theme} font={font} u={u} size={3.8} />
            <CardRole card={card} theme={theme} font={font} u={u} style={{ marginTop: 0.6 * u }} />
          </div>
          <Portrait card={card} theme={theme} u={u} size={10} shape="square" />
        </div>
        <Rule theme={theme} u={u} style={{ margin: "0.8rem 0" }} />
        <div style={{ flex: 1, minHeight: 0 }}>{body(card, theme, font, u)}</div>
        <WhenBlock card={card} theme={theme} font={font} u={u} />
        <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
        <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.35 * u }} />
      </div>
    </div>
  ),

  "type-heavy": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", padding: 6 * u, display: "flex", flexDirection: "column" }}>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", minHeight: 0 }}>
        <div style={{ fontFamily: font.heading, fontStyle: font.italic ? "italic" : "normal", fontSize: 8.2 * u, lineHeight: 0.92, letterSpacing: "-0.045em", fontWeight: 600 }}>
          {(card.headline || card.card_name || "").split(" ").map((word, i) => (
            <div key={i} style={{ color: i === 1 ? theme.accent : theme.ink }}>{word}</div>
          ))}
        </div>
        <div style={{ fontFamily: font.body, fontSize: 1.85 * u, marginTop: 1.6 * u, opacity: 0.75, maxWidth: "70%" }}>{card.subheadline}</div>
      </div>
      <div style={{ borderTop: `2px solid ${theme.ink}`, paddingTop: 2 * u, display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 3 * u }}>
        <div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 1.2 * u, letterSpacing: "0.16em", textTransform: "uppercase", color: theme.muted, marginBottom: 0.8 * u }}>
            {card.organization || "Contact"}
          </div>
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.25 * u }} />
        </div>
        <div style={{ display: "grid", gap: 1 * u }}>
          <WhenBlock card={card} theme={theme} font={font} u={u} />
          <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
        </div>
      </div>
    </div>
  ),

  "badge-crest": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: 6 * u, background: theme.soft }}>
      <div style={{ width: 15 * u, height: 15 * u, borderRadius: "50%", border: `1.5px solid ${theme.accent}`, display: "flex", alignItems: "center", justifyContent: "center", background: theme.bg }}>
        <div style={{ width: 12 * u, height: 12 * u, borderRadius: "50%", border: `1px solid ${theme.ink}22`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Sora', sans-serif", fontSize: 3.6 * u, color: theme.accent }}>
          {initials(card.headline || card.organization)}
        </div>
      </div>
      <CardName card={card} theme={theme} font={font} u={u} size={3.7} align="center" style={{ marginTop: 1.8 * u }} />
      <CardRole card={card} theme={theme} font={font} u={u} align="center" style={{ opacity: 0.7, marginTop: 0.5 * u }} />
      <Eyebrow theme={theme} font={font} u={u} style={{ marginTop: 1 * u }}>{card.organization}</Eyebrow>
      <div style={{ flex: 1, minHeight: 0, marginTop: 1.8 * u, width: "100%" }}>{body(card, theme, font, u)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 2 * u, width: "100%", borderTop: `1px solid ${theme.ink}22`, paddingTop: 1.6 * u }}>
        <div style={{ fontFamily: font.body, fontSize: 1.35 * u, color: theme.ink, opacity: 0.8 }}>{card.phone}</div>
        <div style={{ fontFamily: font.body, fontSize: 1.35 * u, color: theme.ink, opacity: 0.8 }}>{card.email}</div>
        <div style={{ fontFamily: font.body, fontSize: 1.35 * u, color: theme.ink, opacity: 0.8 }}>{card.website?.replace(/^https?:\/\//, "")}</div>
      </div>
    </div>
  ),

  "half-photo": ({ card, theme, font, u }) => (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ height: "46%", position: "relative" }}>
        <Cover card={card} theme={theme} u={u} height={99} style={{ height: "100%" }} />
        <div style={{ position: "absolute", inset: 0, background: `linear-gradient(180deg, transparent 40%, ${theme.bg} 100%)` }} />
      </div>
      <div style={{ flex: 1, padding: `${0}px ${6 * u}px ${5 * u}`, display: "flex", flexDirection: "column", gap: 1.1 * u, marginTop: -4 * u, position: "relative" }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization}</Eyebrow>
        <CardName card={card} theme={theme} font={font} u={u} size={4} />
        <CardRole card={card} theme={theme} font={font} u={u} />
        <div style={{ flex: 1, minHeight: 0, marginTop: 0.8 * u }}>{body(card, theme, font, u)}</div>
        <WhenBlock card={card} theme={theme} font={font} u={u} />
        <DetailGrid card={card} theme={theme} font={font} u={u} columns={3} />
        <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.3 * u }} />
      </div>
    </div>
  ),

  lines: ({ card, theme, font, u }) => {
    const rows = [
      ["Name", card.headline],
      ["Role", card.subheadline],
      ["Company", card.organization],
      ["Phone", card.phone],
      ["Email", card.email],
      ["Web", card.website?.replace(/^https?:\/\//, "")],
      ["Address", card.address],
      ["Date", card.event_date],
      ["Venue", card.venue]
    ].filter(([, v]) => v);
    return (
      <div style={{ height: "100%", padding: 6 * u, display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", justifyContent: "space-between", borderBottom: `2px solid ${theme.ink}`, paddingBottom: 1.2 * u, marginBottom: 2 * u }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 1.35 * u, letterSpacing: "0.2em", textTransform: "uppercase" }}>{card.category}</div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 1.35 * u, color: theme.accent }}>ZC</div>
        </div>
        <div style={{ display: "grid", gap: 0, flex: 1, minHeight: 0, overflow: "hidden" }}>
          {rows.map(([label, value], i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", gap: 2 * u, padding: `${1 * u}px 0`, borderBottom: `1px solid ${theme.ink}14` }}>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 1.25 * u, letterSpacing: "0.12em", textTransform: "uppercase", color: theme.muted, paddingTop: 0.3 * u }}>{label}</div>
              <div style={{ fontFamily: font.body, fontSize: 1.6 * u, textAlign: "right", maxWidth: "64%", color: theme.ink }}>{value}</div>
            </div>
          ))}
          {card.items?.length ? (
            <div style={{ marginTop: 1.2 * u }}>
              <ItemList card={card} theme={theme} font={font} u={u} compact />
            </div>
          ) : null}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 1.4 * u, fontFamily: "'JetBrains Mono', monospace", fontSize: 1.15 * u, color: theme.muted }}>
          <span>{card.socials?.[0]?.label || "ZetaCard"}</span>
          <span>{new Date().getFullYear()}</span>
        </div>
      </div>
    );
  },

  aurora: ({ card, theme, font, u }) => (
    <div style={{ height: "100%", position: "relative", padding: 5 * u, background: theme.bg }}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: `radial-gradient(55% 45% at 20% 10%, ${theme.accent}55, transparent 60%), radial-gradient(45% 45% at 85% 85%, ${theme.accent}33, transparent 65%)` }} />
      <div style={{ position: "relative", height: "100%", border: `1px solid ${theme.ink}22`, borderRadius: 2.4 * u, background: `${theme.bg}CC`, backdropFilter: "blur(8px)", padding: 5 * u, display: "flex", flexDirection: "column", gap: 1.2 * u }}>
        <Eyebrow theme={theme} font={font} u={u}>{card.organization || "ZetaCard"}</Eyebrow>
        <CardName card={card} theme={theme} font={font} u={u} size={4.4} />
        <CardRole card={card} theme={theme} font={font} u={u} />
        <div style={{ flex: 1, minHeight: 0, marginTop: 1 * u }}>{body(card, theme, font, u)}</div>
        <WhenBlock card={card} theme={theme} font={font} u={u} />
        <DetailGrid card={card} theme={theme} font={font} u={u} columns={2} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 2 * u, borderTop: `1px solid ${theme.ink}22`, paddingTop: 1.2 * u }}>
          <ContactLines card={card} theme={theme} font={font} u={u} style={{ gap: 0.25 * u }} />
          <SocialLine card={card} theme={theme} font={font} u={u} style={{ justifyContent: "flex-end" }} />
        </div>
      </div>
    </div>
  )
};

const CardCanvas = forwardRef(function CardCanvas({ card, scale = 1, className = "" }, ref) {
  const category = getCategory(card?.category);
  const { theme, font, layout } = resolveLook(card);
  const { w, h } = category.canvas;
  const u = w / 100;
  const render = LAYOUTS[layout] || LAYOUTS.monogram;

  return (
    <div
      ref={ref}
      className={className}
      style={{
        width: w,
        height: h,
        background: theme.bg,
        color: theme.ink,
        fontFamily: font.body,
        position: "relative",
        overflow: "hidden",
        transform: `scale(${scale})`,
        transformOrigin: "top left",
        flexShrink: 0
      }}
    >
      {render({ card, theme, font, u })}
    </div>
  );
});

export default CardCanvas;
export { LAYOUTS };
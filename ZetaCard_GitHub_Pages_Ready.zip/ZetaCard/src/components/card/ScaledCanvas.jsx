import React, { useEffect, useRef, useState } from "react";
import CardCanvas from "@/components/card/CardCanvas";
import { getCategory } from "@/lib/templates";

export default function ScaledCanvas({ card, radius = 18, className = "", frameRef }) {
  const wrapRef = useRef(null);
  const [scale, setScale] = useState(0.4);
  const category = getCategory(card?.category);
  const { w, h } = category.canvas;

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => setScale(el.clientWidth / w);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [w]);

  return (
    <div
      ref={wrapRef}
      className={className}
      style={{ width: "100%", aspectRatio: `${w} / ${h}`, overflow: "hidden", borderRadius: radius, position: "relative" }}
    >
      <div style={{ width: w, height: h, position: "absolute", top: 0, left: 0, transform: `scale(${scale})`, transformOrigin: "top left" }}>
        <CardCanvas ref={frameRef} card={card} />
      </div>
    </div>
  );
}
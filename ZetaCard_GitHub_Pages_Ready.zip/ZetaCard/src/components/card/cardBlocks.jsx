import React from "react";
import { Image } from "@/components/ui/image";
import { displayUrl, formatEventDate } from "@/lib/cardUtils";

export function initials(name) {
  return (name || "Z")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
}

export function Eyebrow({ children, theme, font, u, style }) {
  if (!children) return null;
  return (
    <div
      style={{
        fontFamily: font.body,
        fontSize: 1.5 * u,
        letterSpacing: "0.22em",
        textTransform: "uppercase",
        color: theme.muted,
        lineHeight: 1.5,
        ...style
      }}
    >
      {children}
    </div>
  );
}

export function CardName({ card, theme, font, u, size = 5.4, align = "left", style }) {
  return (
    <div
      style={{
        fontFamily: font.heading,
        fontStyle: font.italic ? "italic" : "normal",
        fontWeight: font.italic ? 400 : 600,
        fontSize: size * u,
        lineHeight: 1.02,
        letterSpacing: font.tracking,
        color: theme.ink,
        textAlign: align,
        ...style
      }}
    >
      {card.headline || card.card_name || "Your name"}
    </div>
  );
}

export function CardRole({ card, theme, font, u, align = "left", style }) {
  if (!card.subheadline) return null;
  return (
    <div
      style={{
        fontFamily: font.body,
        fontSize: 1.95 * u,
        color: theme.ink,
        opacity: 0.82,
        textAlign: align,
        lineHeight: 1.35,
        ...style
      }}
    >
      {card.subheadline}
    </div>
  );
}

export function Org({ card, theme, font, u, style }) {
  if (!card.organization) return null;
  return (
    <div
      style={{
        fontFamily: font.body,
        fontSize: 1.85 * u,
        fontWeight: 600,
        letterSpacing: "0.04em",
        color: theme.ink,
        ...style
      }}
    >
      {card.organization}
    </div>
  );
}

export function Rule({ theme, u, style }) {
  return <div style={{ height: 1, background: theme.ink, opacity: 0.18, width: "100%", ...style }} />;
}

export function About({ card, theme, font, u, lines = 3, style }) {
  if (!card.about) return null;
  return (
    <div
      style={{
        fontFamily: font.body,
        fontSize: 1.72 * u,
        lineHeight: 1.55,
        color: theme.ink,
        opacity: 0.76,
        display: "-webkit-box",
        WebkitLineClamp: lines,
        WebkitBoxOrient: "vertical",
        overflow: "hidden",
        ...style
      }}
    >
      {card.about}
    </div>
  );
}

export function ContactLines({ card, theme, font, u, style }) {
  const lines = [card.phone, card.email, card.website && displayUrl(card.website), card.address].filter(Boolean);
  if (!lines.length) return null;
  return (
    <div style={{ display: "grid", gap: 0.7 * u, ...style }}>
      {lines.map((line) => (
        <div
          key={line}
          style={{
            fontFamily: font.body,
            fontSize: 1.62 * u,
            color: theme.ink,
            opacity: 0.78,
            letterSpacing: "0.01em",
            lineHeight: 1.35
          }}
        >
          {line}
        </div>
      ))}
    </div>
  );
}

export function SocialLine({ card, theme, font, u, style }) {
  const list = (card.socials || []).filter((s) => s?.label);
  if (!list.length) return null;
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: 1.4 * u,
        fontFamily: font.body,
        fontSize: 1.5 * u,
        color: theme.accent,
        ...style
      }}
    >
      {list.map((s, i) => (
        <span key={i}>{s.label}</span>
      ))}
    </div>
  );
}

export function ItemList({ card, theme, font, u, compact = false, style }) {
  const items = (card.items || []).filter((i) => i?.name);
  if (!items.length) return null;
  return (
    <div style={{ display: "grid", gap: compact ? 0.9 * u : 1.6 * u, ...style }}>
      {items.slice(0, 7).map((item, i) => (
        <div key={i}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 1.5 * u, alignItems: "baseline" }}>
            <div style={{ fontFamily: font.body, fontSize: 1.85 * u, fontWeight: 600, color: theme.ink }}>
              {item.name}
            </div>
            {item.price ? (
              <div
                style={{
                  fontFamily: font.body,
                  fontSize: 1.75 * u,
                  color: theme.accent,
                  whiteSpace: "nowrap",
                  fontWeight: 600
                }}
              >
                {item.price}
              </div>
            ) : null}
          </div>
          {item.description ? (
            <div
              style={{
                fontFamily: font.body,
                fontSize: 1.5 * u,
                lineHeight: 1.45,
                color: theme.ink,
                opacity: 0.6,
                marginTop: 0.25 * u,
                display: "-webkit-box",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical",
                overflow: "hidden"
              }}
            >
              {item.description}
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}

export function DetailGrid({ card, theme, font, u, columns = 2, style }) {
  const details = (card.details || []).filter((d) => d?.label);
  if (!details.length) return null;
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`, gap: 1.2 * u, ...style }}>
      {details.slice(0, 6).map((d, i) => (
        <div key={i}>
          <div
            style={{
              fontFamily: font.body,
              fontSize: 1.28 * u,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: theme.muted,
              marginBottom: 0.3 * u
            }}
          >
            {d.label}
          </div>
          <div style={{ fontFamily: font.body, fontSize: 1.62 * u, color: theme.ink, lineHeight: 1.35 }}>
            {d.value}
          </div>
        </div>
      ))}
    </div>
  );
}

export function WhenBlock({ card, theme, font, u, align = "left", style }) {
  const text = formatEventDate(card.event_date, card.event_time);
  if (!text && !card.venue) return null;
  return (
    <div style={{ textAlign: align, ...style }}>
      {text ? (
        <div style={{ fontFamily: font.body, fontSize: 1.7 * u, color: theme.ink, fontWeight: 600 }}>{text}</div>
      ) : null}
      {card.venue ? (
        <div style={{ fontFamily: font.body, fontSize: 1.62 * u, color: theme.ink, opacity: 0.72, marginTop: 0.3 * u }}>
          {card.venue}
          {card.address ? ` · ${card.address}` : ""}
        </div>
      ) : null}
    </div>
  );
}

export function Portrait({ card, theme, u, size, shape = "circle", border = true }) {
  const style = {
    width: size * u,
    height: size * u,
    borderRadius: shape === "circle" ? "50%" : 2.4 * u,
    overflow: "hidden",
    background: theme.soft,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    border: border ? `1px solid ${theme.ink}22` : "none"
  };
  if (card.portrait_url) {
    return (
      <div style={style}>
        <Image src={card.portrait_url} alt={card.headline || "Portrait"} className="w-full h-full" fittingType="fill" />
      </div>
    );
  }
  return (
    <div style={{ ...style, fontFamily: "'Sora', sans-serif", color: theme.accent, fontSize: size * 0.42 * u, fontWeight: 600 }}>
      {initials(card.headline)}
    </div>
  );
}

export function Cover({ card, theme, u, height, style }) {
  return (
    <div style={{ height: height * u, background: theme.soft, overflow: "hidden", flexShrink: 0, ...style }}>
      {card.cover_url ? (
        <Image src={card.cover_url} alt={card.headline || "Cover"} className="w-full h-full" fittingType="fill" />
      ) : (
        <div
          style={{
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontFamily: "'Sora', sans-serif",
            fontSize: 3 * u,
            color: theme.accent,
            opacity: 0.55,
            letterSpacing: "0.3em"
          }}
        >
          {initials(card.organization || card.headline)}
        </div>
      )}
    </div>
  );
}

export function QRStub({ theme, u, label = "Scan to open" }) {
  return (
    <div style={{ display: "grid", gap: 0.6 * u, justifyItems: "center" }}>
      <div
        style={{
          width: 9 * u,
          height: 9 * u,
          border: `1.5px dashed ${theme.accent}`,
          borderRadius: 0.8 * u,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: theme.accent,
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 1.2 * u
        }}
      >
        QR
      </div>
      <div
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 1.05 * u,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: theme.muted
        }}
      >
        {label}
      </div>
    </div>
  );
}
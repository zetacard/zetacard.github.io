import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import { getTemplate } from "@/lib/templates";

export default function TemplateTile({ card, categoryName, href, actionLabel = "Use template" }) {
  const template = getTemplate(card.template_id);
  return (
    <div className="group">
      <div className="relative rounded-2xl overflow-hidden border border-border bg-secondary/40 p-2.5 zeta-lift">
        <ScaledCanvas card={card} radius={12} />
      </div>
      <div className="mt-3 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="text-[13px] font-medium truncate">{template.name}</div>
          {categoryName && <div className="text-[11.5px] text-muted-foreground truncate">{categoryName}</div>}
        </div>
        {href && (
          <Link
            to={href}
            className="shrink-0 inline-flex items-center gap-1 text-[11.5px] text-primary opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity"
          >
            {actionLabel} <ArrowUpRight className="w-3 h-3" />
          </Link>
        )}
      </div>
    </div>
  );
}
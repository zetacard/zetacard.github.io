import React, { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Loader2 } from "lucide-react";

export default function QrCode({ value, size = 220, className = "" }) {
  const [src, setSrc] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setSrc("");
    setError("");
    if (!value) return;
    QRCode.toDataURL(value, { margin: 1, width: 720, color: { dark: "#0B1020", light: "#FFFFFF" } })
      .then((url) => {
        if (active) setSrc(url);
      })
      .catch(() => {
        if (active) setError("This link is too long to turn into a QR code.");
      });
    return () => {
      active = false;
    };
  }, [value]);

  if (error) return <p className="text-xs text-destructive">{error}</p>;

  if (!src) {
    return (
      <div className={`flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt="QR code that opens this card"
      width={size}
      height={size}
      className={`rounded-xl bg-white ${className}`}
      style={{ width: size, height: size }}
    />
  );
}

export async function downloadQr(value, filename) {
  const url = await QRCode.toDataURL(value, { margin: 2, width: 1200, color: { dark: "#0B1020", light: "#FFFFFF" } });
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}
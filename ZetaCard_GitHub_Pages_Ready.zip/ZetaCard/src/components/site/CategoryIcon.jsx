import React from "react";
import { IdCard, Heart, Utensils, User, Package, Layers, CalendarDays, Building2 } from "lucide-react";

const MAP = {
  visiting: IdCard,
  wedding: Heart,
  menu: Utensils,
  identity: User,
  product: Package,
  catalog: Layers,
  event: CalendarDays,
  property: Building2
};

export default function CategoryIcon({ category, className = "w-4 h-4" }) {
  const Icon = MAP[category] || IdCard;
  return <Icon className={className} />;
}
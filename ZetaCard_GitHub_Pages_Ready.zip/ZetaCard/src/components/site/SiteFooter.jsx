import React from "react";
import { Link } from "react-router-dom";
import Brand from "@/components/site/Brand";

const GROUPS = [
  {
    title: "Product",
    links: [
      { label: "Features", to: "/features" },
      { label: "Card categories", to: "/categories" },
      { label: "Template gallery", to: "/templates" },
      { label: "How it works", to: "/how-it-works" },
      { label: "Dashboard", to: "/dashboard" }
    ]
  },
  {
    title: "Company",
    links: [
      { label: "About ZetaCard", to: "/about" },
      { label: "Help & FAQ", to: "/help" },
      { label: "Contact", to: "/contact" }
    ]
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy policy", to: "/privacy" },
      { label: "Terms of service", to: "/terms" }
    ]
  }
];

export default function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14">
        <div className="grid gap-10 md:grid-cols-[1.6fr_repeat(3,1fr)]">
          <div className="max-w-xs">
            <Brand />
            <p className="mt-4 text-[13.5px] leading-relaxed text-muted-foreground">
              Digital cards for people and small businesses — designed properly, shared with a link or QR code, kept up to date.
            </p>
            <p className="mt-5 text-[11.5px] text-muted-foreground/80">
              Free to create and share. No card details required.
            </p>
          </div>
          {GROUPS.map((group) => (
            <div key={group.title}>
              <div className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground/80 mb-3">{group.title}</div>
              <ul className="space-y-2.5">
                {group.links.map((link) => (
                  <li key={link.to}>
                    <Link to={link.to} className="text-[13.5px] text-foreground/75 hover:text-foreground transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 pt-6 border-t border-border flex flex-col sm:flex-row gap-3 justify-between text-[12px] text-muted-foreground">
          <span>© {new Date().getFullYear()} ZetaCard. All rights reserved.</span>
          <span>Built for people who would rather not print 500 cards.</span>
        </div>
      </div>
    </footer>
  );
}
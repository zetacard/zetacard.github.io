import React, { useEffect, useState } from "react";
import QRCode from "qrcode";

export default function QrCodeMini({ value, size = 120 }) {
  const [src, setSrc] = useState("");
  useEffect(() => {
    let active = true;
    QRCode.toDataURL(value, { margin: 1, width: 480, color: { dark: "#0B1020", light: "#FFFFFF" } })
      .then((url) => active && setSrc(url))
      .catch(() => active && setSrc(""));
    return () => {
      active = false;
    };
  }, [value]);

  if (!src) return <div style={{ width: size, height: size }} className="rounded-lg bg-secondary animate-pulse" />;
  return <img src={src} alt="QR code preview" width={size} height={size} style={{ width: size, height: size }} />;
}
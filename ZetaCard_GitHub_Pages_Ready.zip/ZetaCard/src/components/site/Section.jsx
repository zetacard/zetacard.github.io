import React from "react";

export default function Section({ eyebrow, title, description, children, align = "left", className = "" }) {
  return (
    <section className={`mx-auto max-w-7xl px-5 sm:px-8 ${className}`}>
      {(eyebrow || title || description) && (
        <div className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : ""}`}>
          {eyebrow && (
            <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground mb-3">{eyebrow}</div>
          )}
          {title && <h2 className="text-[28px] sm:text-[36px] leading-[1.1] font-semibold text-balance">{title}</h2>}
          {description && (
            <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground text-balance">{description}</p>
          )}
        </div>
      )}
      {children && <div className={eyebrow || title ? "mt-10 sm:mt-14" : ""}>{children}</div>}
    </section>
  );
}
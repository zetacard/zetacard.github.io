import React, { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Menu, X, ArrowUpRight } from "lucide-react";
import Brand from "@/components/site/Brand";
import { Button } from "@/components/ui/button";

const LINKS = [
  { label: "Features", to: "/features" },
  { label: "Categories", to: "/categories" },
  { label: "Templates", to: "/templates" },
  { label: "How it works", to: "/how-it-works" },
  { label: "Help", to: "/help" }
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-background/85 backdrop-blur-xl border-b border-border/70" : "bg-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 h-16 flex items-center justify-between gap-6">
        <Brand />

        <nav className="hidden lg:flex items-center gap-1" aria-label="Main">
          {LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `px-3 py-2 text-[13.5px] rounded-full transition-colors ${
                  isActive ? "text-foreground bg-secondary" : "text-muted-foreground hover:text-foreground"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-2">
          <Link to="/login" className="text-[13.5px] text-muted-foreground hover:text-foreground px-3 py-2 transition-colors">
            Sign in
          </Link>
          <Button asChild size="sm" className="rounded-full px-4 h-9 text-[13px]">
            <Link to="/dashboard">
              Create a card <ArrowUpRight className="w-3.5 h-3.5 ml-1" />
            </Link>
          </Button>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="lg:hidden w-10 h-10 -mr-2 flex items-center justify-center rounded-full hover:bg-secondary transition-colors"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border bg-background/98 backdrop-blur-xl">
          <div className="px-5 py-4 flex flex-col gap-1">
            {LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className="px-3 py-2.5 rounded-lg text-sm text-foreground/80 hover:bg-secondary"
              >
                {link.label}
              </NavLink>
            ))}
            <Link to="/about" className="px-3 py-2.5 rounded-lg text-sm text-foreground/80 hover:bg-secondary">
              About
            </Link>
            <Link to="/contact" className="px-3 py-2.5 rounded-lg text-sm text-foreground/80 hover:bg-secondary">
              Contact
            </Link>
            <div className="flex gap-2 pt-3">
              <Button asChild variant="outline" className="flex-1 rounded-full h-10">
                <Link to="/login">Sign in</Link>
              </Button>
              <Button asChild className="flex-1 rounded-full h-10">
                <Link to="/dashboard">Create a card</Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
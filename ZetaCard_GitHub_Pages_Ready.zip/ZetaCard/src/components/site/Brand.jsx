import React from "react";
import { Link } from "react-router-dom";

export default function Brand({ light = false, compact = false }) {
  return (
    <Link to="/" className="flex items-center gap-2.5 group" aria-label="ZetaCard home">
      <span
        className="relative flex items-center justify-center rounded-[10px] w-9 h-9 overflow-hidden"
        style={{
          background: light
            ? "linear-gradient(140deg, #FFFFFF 0%, #D9DBFF 55%, #9BE7F0 100%)"
            : "linear-gradient(140deg, #12163A 0%, #3B37C9 58%, #17B8C9 100%)"
        }}
      >
        <span
          className="font-heading font-semibold text-[17px] leading-none"
          style={{ color: light ? "#12163A" : "#FFFFFF" }}
        >
          Z
        </span>
        <span className="absolute -right-2 -bottom-2 w-5 h-5 rounded-full bg-white/25 blur-[2px]" />
      </span>
      {!compact && (
        <span className={`font-heading text-[17px] tracking-tight ${light ? "text-white" : "text-foreground"}`}>
          Zeta<span className={light ? "text-white/60" : "text-muted-foreground"}>Card</span>
        </span>
      )}
    </Link>
  );
}
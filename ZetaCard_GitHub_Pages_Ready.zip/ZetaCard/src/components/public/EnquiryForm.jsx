import React, { useState } from "react";
import { Loader2, Check, AlertCircle, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function EnquiryForm({ card }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "", consent: false });
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.name.trim() || !form.email.trim() || form.message.trim().length < 10) {
      setError("Please add your name, email and a message of at least 10 characters.");
      return;
    }
    if (!form.consent) {
      setError("Please confirm you are happy for the card owner to contact you.");
      return;
    }
    setStatus("sending");
    try {
      const response = await base44.functions.invoke("submitEnquiry", {
        kind: "card",
        card_id: card.id,
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        message: form.message.trim()
      });
      if (response.data?.error) {
        setError(response.data.error);
        setStatus("idle");
        return;
      }
      base44.functions.invoke("trackEvent", { card_id: card.id, type: "enquiry" }).catch(() => {});
      setStatus("sent");
    } catch (err) {
      setError(err?.response?.data?.error || "Your message could not be sent. Please try again.");
      setStatus("idle");
    }
  };

  if (status === "sent") {
    return (
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <Check className="w-4 h-4 text-primary" />
          </div>
          <div>
            <div className="text-[14px] font-medium">Message sent</div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
              It has been delivered to the owner of this card. They will reply to the email address you gave.
            </p>
            <Button variant="outline" size="sm" className="mt-4 h-8 rounded-lg text-[12px]" onClick={() => { setStatus("idle"); setForm({ name: "", email: "", phone: "", message: "", consent: false }); }}>
              Send another message
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-border bg-card p-5 sm:p-6" noValidate>
      <h2 className="text-[15px] font-medium">Send a message</h2>
      <p className="mt-1 text-[12.5px] text-muted-foreground">Goes straight to the card owner's inbox.</p>
      <div className="mt-4 space-y-3">
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <Label htmlFor="e-name" className="text-[12px]">Your name</Label>
            <Input id="e-name" value={form.name} onChange={(e) => update("name", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="name" />
          </div>
          <div>
            <Label htmlFor="e-email" className="text-[12px]">Email</Label>
            <Input id="e-email" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="email" />
          </div>
        </div>
        <div>
          <Label htmlFor="e-phone" className="text-[12px]">Phone <span className="text-muted-foreground font-normal">(optional)</span></Label>
          <Input id="e-phone" type="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="tel" />
        </div>
        <div>
          <Label htmlFor="e-message" className="text-[12px]">Message</Label>
          <Textarea id="e-message" rows={4} value={form.message} onChange={(e) => update("message", e.target.value)} className="mt-1.5 text-[13px]" placeholder="What would you like to ask?" />
        </div>
        <label className="flex items-start gap-2 text-[11.5px] text-muted-foreground">
          <input type="checkbox" checked={form.consent} onChange={(e) => update("consent", e.target.checked)} className="mt-0.5 w-4 h-4 rounded border-border accent-[hsl(var(--primary))]" />
          I agree that this message and my contact details are shared with the card owner so they can reply.
        </label>
        {error && (
          <div className="flex gap-2 items-start rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-[12px] text-destructive">
            <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {error}
          </div>
        )}
        <Button type="submit" className="h-10 rounded-lg text-[13px]" disabled={status === "sending"}>
          {status === "sending" ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending</> : <><Send className="w-3.5 h-3.5 mr-2" /> Send message</>}
        </Button>
      </div>
    </form>
  );
}
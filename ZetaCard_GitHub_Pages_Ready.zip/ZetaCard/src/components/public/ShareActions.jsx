import React, { useState } from "react";
import { Copy, Share2, QrCode, Download, Printer, FileImage, FileText, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import QrCodeBlock, { downloadQr } from "@/components/card/QrCode";
import { downloadVCard, slugify } from "@/lib/cardUtils";
import { exportPdf, exportPng } from "@/lib/exports";
import { base44 } from "@/api/base44Client";

export default function ShareActions({ card, url, cardRef }) {
  const [copied, setCopied] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [working, setWorking] = useState("");
  const [message, setMessage] = useState("");

  const track = (type) => {
    base44.functions.invoke("trackEvent", { card_id: card.id, type }).catch(() => {});
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setMessage("Link copied");
      track("share");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setMessage("Could not copy. Select the address bar and copy it manually.");
    }
  };

  const share = async () => {
    track("share");
    if (navigator.share) {
      try {
        await navigator.share({ title: card.card_name || card.headline || "ZetaCard", url });
        return;
      } catch {
        return;
      }
    }
    copy();
  };

  const runExport = async (kind) => {
    setWorking(kind);
    setMessage("");
    try {
      if (kind === "png") await exportPng(cardRef?.current, card.headline || card.card_name);
      if (kind === "pdf") await exportPdf(cardRef?.current, card);
      setMessage(kind === "png" ? "Image downloaded" : "PDF downloaded");
    } catch (error) {
      setMessage(error?.message || "The export could not be created.");
    } finally {
      setWorking("");
    }
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" className="h-9 rounded-full text-[12px] px-3.5" onClick={copy}>
          {copied ? <Check className="w-3.5 h-3.5 mr-1.5" /> : <Copy className="w-3.5 h-3.5 mr-1.5" />} Copy link
        </Button>
        <Button size="sm" variant="outline" className="h-9 rounded-full text-[12px] px-3.5" onClick={share}>
          <Share2 className="w-3.5 h-3.5 mr-1.5" /> Share
        </Button>
        <Button size="sm" variant="outline" className="h-9 rounded-full text-[12px] px-3.5" onClick={() => { setQrOpen((v) => !v); track("qr"); }}>
          <QrCode className="w-3.5 h-3.5 mr-1.5" /> QR code
        </Button>
        <Button size="sm" variant="outline" className="h-9 rounded-full text-[12px] px-3.5" onClick={() => downloadVCard(card)}>
          <Download className="w-3.5 h-3.5 mr-1.5" /> Save contact
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 mt-2">
        <Button size="sm" variant="ghost" className="h-8 rounded-full text-[11.5px] px-3" onClick={() => runExport("png")} disabled={working === "png"}>
          {working === "png" ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <FileImage className="w-3.5 h-3.5 mr-1.5" />} PNG
        </Button>
        <Button size="sm" variant="ghost" className="h-8 rounded-full text-[11.5px] px-3" onClick={() => runExport("pdf")} disabled={working === "pdf"}>
          {working === "pdf" ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <FileText className="w-3.5 h-3.5 mr-1.5" />} PDF
        </Button>
        <Button size="sm" variant="ghost" className="h-8 rounded-full text-[11.5px] px-3" onClick={() => window.print()}>
          <Printer className="w-3.5 h-3.5 mr-1.5" /> Print
        </Button>
      </div>

      {message && <p className="mt-2 text-[11.5px] text-muted-foreground">{message}</p>}

      {qrOpen && (
        <div className="mt-4 rounded-2xl border border-border p-4 flex flex-col sm:flex-row items-center gap-4">
          <QrCodeBlock value={url} size={132} />
          <div className="text-center sm:text-left">
            <div className="text-[12.5px] font-medium">Scan to open this card</div>
            <p className="mt-1 text-[11.5px] text-muted-foreground max-w-[220px]">
              Works with any phone camera. Download it for print or a slide.
            </p>
            <Button
              size="sm"
              variant="secondary"
              className="mt-2.5 h-8 rounded-lg text-[11.5px]"
              onClick={() => downloadQr(url, `${slugify(card.card_name || "zetacard")}-qr.png`)}
            >
              <Download className="w-3.5 h-3.5 mr-1.5" /> Download QR
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
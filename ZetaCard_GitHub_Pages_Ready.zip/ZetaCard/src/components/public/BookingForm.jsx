import React, { useEffect, useMemo, useState } from "react";
import { Loader2, Check, AlertCircle, CalendarDays, Clock } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

function dayLabel(iso) {
  const date = new Date(`${iso}T00:00:00`);
  return {
    weekday: date.toLocaleDateString("en-GB", { weekday: "short" }),
    day: date.getDate(),
    month: date.toLocaleDateString("en-GB", { month: "short" })
  };
}

export default function BookingForm({ card }) {
  const [slots, setSlots] = useState(null);
  const [loadError, setLoadError] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [form, setForm] = useState({ visitor_name: "", visitor_email: "", visitor_phone: "", message: "", consent: false });
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [receipt, setReceipt] = useState(null);

  useEffect(() => {
    let active = true;
    base44.functions
      .invoke("cardSlots", { card_id: card.id, days: 21 })
      .then((response) => {
        if (!active) return;
        if (response.data?.error) {
          setLoadError(response.data.error);
          return;
        }
        const withSlots = (response.data.dates || []).filter((d) => d.slots.some((s) => s.available));
        setSlots(withSlots);
        if (withSlots[0]) setDate(withSlots[0].date);
      })
      .catch(() => active && setLoadError("Available times could not be loaded. Please refresh."));
    return () => {
      active = false;
    };
  }, [card.id]);

  const times = useMemo(() => {
    const day = slots?.find((d) => d.date === date);
    return day?.slots || [];
  }, [slots, date]);

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!date || !time) {
      setError("Choose a date and a time first.");
      return;
    }
    if (!form.visitor_name.trim() || !form.visitor_email.trim()) {
      setError("Please add your name and email.");
      return;
    }
    if (!form.consent) {
      setError("Please confirm you are happy for the card owner to contact you about this booking.");
      return;
    }
    setStatus("sending");
    try {
      const response = await base44.functions.invoke("submitBooking", {
        card_id: card.id,
        date,
        time,
        visitor_name: form.visitor_name.trim(),
        visitor_email: form.visitor_email.trim(),
        visitor_phone: form.visitor_phone.trim(),
        message: form.message.trim()
      });
      if (response.data?.error) {
        setError(response.data.error);
        setStatus("idle");
        return;
      }
      base44.functions.invoke("trackEvent", { card_id: card.id, type: "booking" }).catch(() => {});
      setReceipt({ date, time, emailStatus: response.data.email_status });
      setStatus("sent");
    } catch (err) {
      setError(err?.response?.data?.error || "The booking could not be sent. Please try another time.");
      setStatus("idle");
    }
  };

  if (status === "sent" && receipt) {
    return (
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <Check className="w-4 h-4 text-primary" />
          </div>
          <div>
            <div className="text-[14px] font-medium">Request sent — pending confirmation</div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
              You asked for {receipt.date} at {receipt.time} ({card.availability?.timezone || "local time"}). The owner
              reviews it before it is confirmed.
            </p>
            <p className="mt-2 text-[12px] text-muted-foreground">
              {receipt.emailStatus === "sent"
                ? "A notification has been sent to the card owner."
                : receipt.emailStatus === "failed"
                ? "The request is saved, but the notification email could not be delivered. Keep this page as your record."
                : "The request is saved with the owner. Keep this page as your record."}
            </p>
            <Button variant="outline" size="sm" className="mt-4 h-8 rounded-lg text-[12px]" onClick={() => { setStatus("idle"); setReceipt(null); setTime(""); }}>
              Book another slot
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-5 sm:p-6">
      <h2 className="text-[15px] font-medium">Request an appointment</h2>
      <p className="mt-1 text-[12.5px] text-muted-foreground">
        Times shown in {card.availability?.timezone || "local time"} · {card.availability?.slot_minutes || 30}-minute slots
      </p>

      {loadError ? (
        <p className="mt-4 text-[12.5px] text-destructive">{loadError}</p>
      ) : slots === null ? (
        <div className="mt-5 flex items-center gap-2 text-[12.5px] text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin" /> Loading available times
        </div>
      ) : slots.length === 0 ? (
        <div className="mt-5 rounded-xl border border-dashed border-border p-5 text-[12.5px] text-muted-foreground">
          <Clock className="w-4 h-4 mb-2" />
          No open times in the next three weeks. Please use the message form instead.
        </div>
      ) : (
        <form onSubmit={submit} className="mt-5 space-y-5" noValidate>
          <div>
            <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-[0.14em] text-muted-foreground mb-2">
              <CalendarDays className="w-3.5 h-3.5" /> Choose a date
            </div>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
              {slots.map((day) => {
                const label = dayLabel(day.date);
                const active = day.date === date;
                return (
                  <button
                    key={day.date}
                    type="button"
                    onClick={() => { setDate(day.date); setTime(""); }}
                    className={`shrink-0 w-16 rounded-xl border px-2 py-2.5 text-center transition-colors ${
                      active ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-foreground/30"
                    }`}
                  >
                    <div className="text-[10px] uppercase tracking-wide opacity-70">{label.weekday}</div>
                    <div className="text-[16px] font-medium leading-tight">{label.day}</div>
                    <div className="text-[10px] opacity-70">{label.month}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground mb-2">Choose a time</div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {times.map((slot) => (
                <button
                  key={slot.time}
                  type="button"
                  disabled={!slot.available}
                  onClick={() => setTime(slot.time)}
                  className={`h-9 rounded-lg border text-[12px] transition-colors ${
                    time === slot.time
                      ? "border-primary bg-primary text-primary-foreground"
                      : slot.available
                      ? "border-border hover:border-foreground/30"
                      : "border-border/60 text-muted-foreground/40 line-through cursor-not-allowed"
                  }`}
                >
                  {slot.time}
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="b-name" className="text-[12px]">Your name</Label>
              <Input id="b-name" value={form.visitor_name} onChange={(e) => update("visitor_name", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="name" />
            </div>
            <div>
              <Label htmlFor="b-email" className="text-[12px]">Email</Label>
              <Input id="b-email" type="email" value={form.visitor_email} onChange={(e) => update("visitor_email", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="email" />
            </div>
          </div>
          <div>
            <Label htmlFor="b-phone" className="text-[12px]">Phone <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Input id="b-phone" type="tel" value={form.visitor_phone} onChange={(e) => update("visitor_phone", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="tel" />
          </div>
          <div>
            <Label htmlFor="b-message" className="text-[12px]">Anything to add? <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Textarea id="b-message" rows={3} value={form.message} onChange={(e) => update("message", e.target.value)} className="mt-1.5 text-[13px]" />
          </div>
          <label className="flex items-start gap-2 text-[11.5px] text-muted-foreground">
            <input type="checkbox" checked={form.consent} onChange={(e) => update("consent", e.target.checked)} className="mt-0.5 w-4 h-4 rounded border-border accent-[hsl(var(--primary))]" />
            I agree that my name, email and phone are shared with the card owner so they can confirm this appointment.
          </label>

          {error && (
            <div className="flex gap-2 items-start rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-[12px] text-destructive">
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {error}
            </div>
          )}

          <Button type="submit" className="h-10 rounded-lg text-[13px]" disabled={status === "sending" || !time}>
            {status === "sending" ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending request</> : "Request this slot"}
          </Button>
          <p className="text-[11px] text-muted-foreground">
            Requests are confirmed by the owner. The slot is held as pending as soon as you submit.
          </p>
        </form>
      )}
    </div>
  );
}
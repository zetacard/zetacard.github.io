import React, { useState } from "react";
import { Loader2, Check, AlertCircle, UserPlus } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const EMPTY = { name: "", email: "", phone: "", organization: "", role: "", note: "", consent: false };

export default function ContactExchange({ card }) {
  const [form, setForm] = useState(EMPTY);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));
  const owner = (card.headline || card.organization || "").split(" ")[0];

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (form.name.trim().length < 2) return setError("Please enter your name.");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email.trim())) return setError("Please enter a valid email address.");
    if (!form.consent) return setError("Please confirm you are happy to share these details.");
    setStatus("sending");
    try {
      const source = new URLSearchParams(window.location.search).get("src") === "qr" ? "qr" : "link";
      const response = await base44.functions.invoke("submitContact", {
        card_id: card.id,
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        organization: form.organization.trim(),
        role: form.role.trim(),
        note: form.note.trim(),
        consent: true,
        source
      });
      if (response.data?.error) {
        setError(response.data.error);
        setStatus("idle");
        return;
      }
      setStatus("sent");
    } catch (err) {
      setError(err?.response?.data?.error || "Your details could not be sent. Please try again.");
      setStatus("idle");
    }
  };

  if (status === "sent") {
    return (
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <Check className="w-4 h-4 text-primary" />
          </div>
          <div>
            <div className="text-[14px] font-medium">Details shared</div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
              {owner ? `${owner} has` : "The card owner has"} your name and contact details and can follow up directly.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="mt-4 h-8 rounded-lg text-[12px]"
              onClick={() => { setForm(EMPTY); setStatus("idle"); }}
            >
              Share different details
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-border bg-card p-5 sm:p-6" noValidate>
      <div className="flex items-center gap-2">
        <UserPlus className="w-4 h-4 text-primary" />
        <h2 className="text-[15px] font-medium">Share your details</h2>
      </div>
      <p className="mt-1 text-[12.5px] text-muted-foreground">
        Send your contact details to {owner || "the card owner"} — no account needed.
      </p>

      <div className="mt-4 space-y-3">
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <Label htmlFor="cx-name" className="text-[12px]">Your name</Label>
            <Input id="cx-name" value={form.name} onChange={(e) => update("name", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="name" />
          </div>
          <div>
            <Label htmlFor="cx-email" className="text-[12px]">Email</Label>
            <Input id="cx-email" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="email" />
          </div>
          <div>
            <Label htmlFor="cx-phone" className="text-[12px]">Phone <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Input id="cx-phone" type="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="tel" />
          </div>
          <div>
            <Label htmlFor="cx-company" className="text-[12px]">Company <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Input id="cx-company" value={form.organization} onChange={(e) => update("organization", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="organization" />
          </div>
        </div>
        <div>
          <Label htmlFor="cx-role" className="text-[12px]">Your role <span className="text-muted-foreground font-normal">(optional)</span></Label>
          <Input id="cx-role" value={form.role} onChange={(e) => update("role", e.target.value)} className="mt-1.5 h-10 text-[13px]" autoComplete="organization-title" />
        </div>
        <div>
          <Label htmlFor="cx-note" className="text-[12px]">Note <span className="text-muted-foreground font-normal">(optional)</span></Label>
          <Textarea id="cx-note" rows={3} value={form.note} onChange={(e) => update("note", e.target.value)} className="mt-1.5 text-[13px]" placeholder="Where you met, or what you would like to discuss." />
        </div>
        <label className="flex items-start gap-2 text-[11.5px] text-muted-foreground">
          <input type="checkbox" checked={form.consent} onChange={(e) => update("consent", e.target.checked)} className="mt-0.5 w-4 h-4 rounded border-border accent-[hsl(var(--primary))]" />
          I agree to share these details with the card owner for follow-up. They are stored privately and not shown publicly.
        </label>
        {error && (
          <div className="flex gap-2 items-start rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-[12px] text-destructive">
            <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {error}
          </div>
        )}
        <Button type="submit" className="h-10 rounded-lg text-[13px]" disabled={status === "sending"}>
          {status === "sending" ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending</> : <><UserPlus className="w-3.5 h-3.5 mr-2" /> Send my details</>}
        </Button>
      </div>
    </form>
  );
}
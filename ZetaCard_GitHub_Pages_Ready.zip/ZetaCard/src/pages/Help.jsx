import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Mail, LifeBuoy } from "lucide-react";
import Section from "@/components/site/Section";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

const GROUPS = [
  {
    title: "Creating a card",
    items: [
      {
        q: "Do I need to choose a category first?",
        a: "Yes — the category decides which fields appear and which designs are available. You can duplicate a card and change category by starting a new one, but an existing card keeps its category."
      },
      {
        q: "Can I switch template without losing my text?",
        a: "Yes. Templates only change the design. Your name, menu items, dates and images all stay exactly as entered."
      },
      {
        q: "What images can I upload?",
        a: "PNG, JPG, WEBP or GIF up to 5 MB. Images are checked before upload; if a file is rejected you will see the reason instead of a silent failure."
      },
      {
        q: "Is my draft saved automatically?",
        a: "While you edit an existing draft, changes autosave about a second after you stop typing, and the header shows the status. A brand-new card is only created when you press Save draft for the first time."
      }
    ]
  },
  {
    title: "Publishing and sharing",
    items: [
      {
        q: "What is my card's address?",
        a: "Every published card gets /c/ followed by a short address based on its name. You can see the exact link in the publish panel and copy it from there."
      },
      {
        q: "Does unpublishing break a printed QR code?",
        a: "Unpublishing makes the link show a 'not available' page, so an old QR code stops working. Publishing again restores it at the same address."
      },
      {
        q: "How do I share a card?",
        a: "Use Copy link, the native share sheet on a phone, or download the QR code. On desktop where there is no share sheet, you get copy-link and email options instead."
      },
      {
        q: "Can I export a card as an image?",
        a: "Yes. PNG exports at twice the design size, PDF exports at the card's own proportions, and the print view keeps the same proportions."
      }
    ]
  },
  {
    title: "Enquiries and bookings",
    items: [
      {
        q: "Who can see my enquiries?",
        a: "Only the account that owns the card, plus the app's administrators. Visitors never see each other's messages, and enquiries are never exposed on a public page."
      },
      {
        q: "How does availability work?",
        a: "Each card with bookings enabled has open days, a start and end time and a slot length. Booked slots are removed from the public list, and the server checks again when a booking is submitted so two people cannot take the same slot."
      },
      {
        q: "Why does a booking say 'email not sent'?",
        a: "Booking emails require the app owner to connect an email provider. The booking itself is saved either way — the dashboard reports the email separately so you always know whether a notification actually went out."
      }
    ]
  },
  {
    title: "Account and privacy",
    items: [
      {
        q: "What is public and what is private?",
        a: "A published card is public. Drafts, archived cards, enquiries, bookings, notes and analytics are private to your account. Your login email is never shown on a card unless you put it there."
      },
      {
        q: "How do I delete my data?",
        a: "Account settings has a delete option that removes your cards, enquiries, bookings and analytics events from the app. It asks you to confirm by typing your card count first, because it cannot be undone."
      },
      {
        q: "Do you use cookies or third-party trackers?",
        a: "The app records its own card events (a view, a share, a tap) without third-party advertising trackers. It uses browser storage for your session only."
      }
    ]
  }
];

export default function Help() {
  return (
    <div>
      <Section
        eyebrow="Help & FAQ"
        title="Answers, without the runaround"
        description="Everything about creating, publishing and managing a ZetaCard. If your question is not here, the contact page reaches a person."
        className="pt-16 pb-14 sm:pt-24"
      >
        <div className="grid lg:grid-cols-[1fr_300px] gap-10 items-start">
          <div className="space-y-10">
            {GROUPS.map((group) => (
              <div key={group.title}>
                <h2 className="text-[15px] font-medium mb-3">{group.title}</h2>
                <Accordion type="single" collapsible className="border-t border-border">
                  {group.items.map((item, i) => (
                    <AccordionItem key={item.q} value={`${group.title}-${i}`} className="border-border">
                      <AccordionTrigger className="text-left text-[14px] hover:no-underline py-4">{item.q}</AccordionTrigger>
                      <AccordionContent className="text-[13.5px] leading-relaxed text-muted-foreground pb-4">
                        {item.a}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            ))}
          </div>

          <aside className="lg:sticky lg:top-24 space-y-3">
            <div className="rounded-2xl border border-border bg-card p-6">
              <LifeBuoy className="w-5 h-5 text-primary" />
              <div className="mt-3 text-[14px] font-medium">Still stuck?</div>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground">
                Send us the card name and what you expected to happen. We can look at the exact record.
              </p>
              <Button asChild className="mt-4 w-full rounded-full h-10 text-[13px]">
                <Link to="/contact">Contact support <ArrowRight className="w-3.5 h-3.5 ml-1.5" /></Link>
              </Button>
            </div>
            <div className="rounded-2xl border border-border p-6">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div className="mt-3 text-[13px] font-medium">For account owners</div>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground">
                Booking confirmation emails need an email provider connected on the server. Until then bookings are saved and marked "email not sent".
              </p>
            </div>
          </aside>
        </div>
      </Section>
    </div>
  );
}
import React from "react";
import Section from "@/components/site/Section";

const BLOCKS = [
  {
    title: "1. The service",
    body: "ZetaCard lets you create, publish and share digital cards, and manage enquiries, bookings and basic analytics relating to them. The service is provided free of charge in this version. No payment is collected."
  },
  {
    title: "2. Your account",
    body: "You need an account to create cards. Keep your login credentials secure; activity under your account is your responsibility. You must provide accurate information and be old enough to enter a binding agreement in your jurisdiction."
  },
  {
    title: "3. Your content",
    body: "You keep ownership of the text and images you upload. You grant ZetaCard permission to store and display that content for the purpose of running your cards. You confirm you have the right to use any image or personal detail you upload, including details about other people."
  },
  {
    title: "4. Acceptable use",
    body: "Do not use ZetaCard for unlawful, deceptive or harmful content; to impersonate someone; to publish another person's private information without consent; to send spam through enquiry or booking forms; or to attempt to access records that are not yours. We may remove content or suspend access where these rules are broken."
  },
  {
    title: "5. Public pages",
    body: "Publishing a card makes it readable by anyone with the link or QR code. You are responsible for what you choose to publish. Unpublishing removes public access, but copies other people saved or screenshotted are outside our control."
  },
  {
    title: "6. Third-party services",
    body: "The app relies on a hosting and authentication platform, and optionally on an email provider configured by the operator. Their availability affects the service. We do not control third-party outages."
  },
  {
    title: "7. Availability and changes",
    body: "The service is provided as-is, without a guarantee of uninterrupted availability. Features may change as the product develops. Anything that requires setup on the operator's side is disclosed in the interface rather than presented as working."
  },
  {
    title: "8. Limitation of liability",
    body: "To the extent permitted by law, ZetaCard is not liable for indirect or consequential loss arising from use of the service, including lost business, missed appointments or printing costs. Nothing here limits rights that cannot be limited by law."
  },
  {
    title: "9. Ending use",
    body: "You can stop using the service at any time and delete your data from account settings. We may suspend accounts that breach these terms or place the service or other users at risk."
  },
  {
    title: "10. Contact",
    body: "Questions about these terms can be sent through the contact page."
  }
];

export default function Terms() {
  return (
    <Section eyebrow="Legal" title="Terms of service" className="pt-16 pb-20 sm:pt-24">
      <div className="max-w-3xl">
        <p className="text-[12.5px] text-muted-foreground">Last updated 29 October 2026</p>
        <div className="mt-8 space-y-8">
          {BLOCKS.map((block) => (
            <div key={block.title}>
              <h2 className="text-[15px] font-medium">{block.title}</h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">{block.body}</p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
import React, { useState } from "react";
import { Loader2, Check, AlertCircle } from "lucide-react";
import Section from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "", consent: false });
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.name.trim() || !form.email.trim() || form.message.trim().length < 10) {
      setError("Please add your name, email and a message of at least 10 characters.");
      return;
    }
    if (!form.consent) {
      setError("Please confirm we may reply to you by email.");
      return;
    }
    setStatus("sending");
    try {
      const response = await base44.functions.invoke("submitEnquiry", {
        kind: "platform",
        name: form.name.trim(),
        email: form.email.trim(),
        message: form.message.trim()
      });
      if (response.data?.error) {
        setError(response.data.error);
        setStatus("idle");
        return;
      }
      setStatus("sent");
      setForm({ name: "", email: "", message: "", consent: false });
    } catch (err) {
      setError(err?.response?.data?.error || "We could not send that. Please try again in a moment.");
      setStatus("idle");
    }
  };

  return (
    <Section
      eyebrow="Contact"
      title="Tell us what you are trying to make"
      description="Product questions, a card that will not publish, or a category you wish existed — this reaches the team that builds ZetaCard."
      className="pt-16 pb-20 sm:pt-24"
    >
      <div className="grid lg:grid-cols-[1fr_360px] gap-10 items-start max-w-5xl">
        <div className="rounded-2xl border border-border bg-card p-7 sm:p-9">
          {status === "sent" ? (
            <div className="flex gap-3 items-start">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <Check className="w-4 h-4 text-primary" />
              </div>
              <div>
                <div className="text-[15px] font-medium">Message received</div>
                <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
                  It is stored in the ZetaCard inbox with your email address, so we can reply to you directly.
                </p>
                <Button variant="outline" size="sm" className="mt-5 rounded-full" onClick={() => setStatus("idle")}>
                  Send another message
                </Button>
              </div>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5" noValidate>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="c-name">Your name</Label>
                  <Input id="c-name" value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Ira Kapoor" autoComplete="name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="c-email">Email</Label>
                  <Input id="c-email" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="you@example.com" autoComplete="email" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="c-message">Message</Label>
                <Textarea
                  id="c-message"
                  rows={6}
                  value={form.message}
                  onChange={(e) => update("message", e.target.value)}
                  placeholder="What are you trying to do, and what happened instead?"
                />
              </div>
              <label className="flex items-start gap-2.5 text-[12.5px] text-muted-foreground">
                <input
                  type="checkbox"
                  checked={form.consent}
                  onChange={(e) => update("consent", e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded border-border accent-[hsl(var(--primary))]"
                />
                I agree that ZetaCard may store this message and reply to me by email. See the privacy policy.
              </label>

              {error && (
                <div className="flex gap-2 items-start rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2.5 text-[12.5px] text-destructive">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  {error}
                </div>
              )}

              <Button type="submit" disabled={status === "sending"} className="rounded-full h-11 px-6">
                {status === "sending" ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending</> : "Send message"}
              </Button>
            </form>
          )}
        </div>

        <div className="space-y-3">
          <div className="rounded-2xl border border-border bg-secondary/50 p-6">
            <div className="text-[13px] font-medium">Before you write</div>
            <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
              The help page answers most questions about templates, publishing, sharing, bookings and account deletion — often faster than waiting for a reply.
            </p>
          </div>
          <div className="rounded-2xl border border-border p-6">
            <div className="text-[13px] font-medium">What we can help with</div>
            <ul className="mt-2.5 space-y-1.5 text-[12.5px] text-muted-foreground">
              <li>Cards that will not save or publish</li>
              <li>Sharing, QR or export problems</li>
              <li>Booking or enquiry issues</li>
              <li>Account and data deletion</li>
            </ul>
          </div>
        </div>
      </div>
    </Section>
  );
}
import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Check } from "lucide-react";
import Section from "@/components/site/Section";
import { Button } from "@/components/ui/button";

const STEPS = [
  {
    n: "01",
    title: "Choose what you are making",
    body: "Eight categories, each with the right fields. A wedding invitation asks for a date and venue; a menu asks for courses and prices. You are never handed a generic form."
  },
  {
    n: "02",
    title: "Choose a design",
    body: "Twenty layouts per category — centred and formal, editorial and left-aligned, grid-based and technical, image-led and minimal. You can change your mind later without retyping anything."
  },
  {
    n: "03",
    title: "Fill in the details",
    body: "The preview on the right is the real card. Your draft autosaves, and the save status always tells you the truth — saving, saved, or failed."
  },
  {
    n: "04",
    title: "Publish and share",
    body: "Publishing gives you a public address at /c/your-name. Copy the link, use the share sheet, or download the QR code for print. Unpublish whenever you want."
  }
];

const INCLUDED = [
  "Public card page, mobile first",
  "Save-to-contacts download",
  "Click-to-call, email, website and map links",
  "QR code and link sharing",
  "PNG, PDF and print output",
  "Enquiry form with an owner-only inbox",
  "Booking requests with real availability",
  "Views, shares and tap analytics"
];

export default function HowItWorks() {
  return (
    <div>
      <Section
        eyebrow="How it works"
        title="From blank page to a link you can send, in one sitting"
        description="No design software, no print shop, no invoice. You need a name and about six minutes."
        className="pt-16 pb-16 sm:pt-24"
      >
        <div className="grid lg:grid-cols-2 gap-4">
          {STEPS.map((step) => (
            <div key={step.n} className="rounded-2xl border border-border bg-card p-7 sm:p-9">
              <div className="font-mono text-[11px] tracking-[0.22em] text-primary">{step.n}</div>
              <h3 className="mt-5 text-[19px] font-medium">{step.title}</h3>
              <p className="mt-2.5 text-[13.5px] leading-relaxed text-muted-foreground">{step.body}</p>
            </div>
          ))}
        </div>
      </Section>

      <div className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-16 grid lg:grid-cols-[0.9fr_1.1fr] gap-10">
          <div>
            <h2 className="text-[26px] sm:text-[34px] font-semibold leading-tight text-balance">What every published card gets</h2>
            <p className="mt-4 text-[14px] leading-relaxed text-muted-foreground max-w-md">
              These are switched on for every card, in every category. Booking and enquiry forms appear when the category supports them and you leave them enabled.
            </p>
            <Button asChild className="mt-7 rounded-full h-11 px-5">
              <Link to="/dashboard">Create your first card <ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
          <ul className="grid sm:grid-cols-2 gap-3">
            {INCLUDED.map((item) => (
              <li key={item} className="flex gap-2.5 rounded-xl border border-border bg-card px-4 py-3 text-[13px] text-foreground/80">
                <Check className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <Section className="py-16 sm:py-24" title="Two things worth knowing before you start">
        <div className="grid md:grid-cols-2 gap-4 max-w-4xl">
          <div className="rounded-2xl border border-border p-6">
            <div className="text-[13px] font-medium">Your card link is permanent, your design is not</div>
            <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
              The address stays the same even if you change the design, so a QR code you printed last month keeps working.
            </p>
          </div>
          <div className="rounded-2xl border border-border p-6">
            <div className="text-[13px] font-medium">Booking emails need one setup step</div>
            <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
              Booking requests are always saved. Sending the confirmation email requires the app owner to connect an email provider — until that is done, the dashboard tells you no email went out.
            </p>
          </div>
        </div>
      </Section>
    </div>
  );
}
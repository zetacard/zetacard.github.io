import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import Section from "@/components/site/Section";
import { Button } from "@/components/ui/button";

const PRINCIPLES = [
  {
    title: "The template should do the design work",
    body: "Most people do not want a canvas of sliders. They want a card that looks considered. So we ship a small number of genuinely different layouts and keep the controls limited to what changes the outcome."
  },
  {
    title: "A card is a living thing",
    body: "Printed cards freeze a mistake for years. A digital card should be correct the moment you notice it is wrong — a new role, a new price, a new address."
  },
  {
    title: "Honest software",
    body: "No invented testimonials, no fake user counters, no placeholder features dressed up as done. If something needs setup, the interface says so."
  },
  {
    title: "Private by default",
    body: "Drafts stay private. Enquiries and bookings belong to the card owner. Publishing is an explicit action you can reverse."
  }
];

export default function About() {
  return (
    <div>
      <section className="relative overflow-hidden zeta-ink">
        <div className="absolute inset-0 zeta-aurora opacity-90" />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 py-20 sm:py-28">
          <div className="max-w-3xl">
            <div className="text-[11px] uppercase tracking-[0.2em] text-white/45">About ZetaCard</div>
            <h1 className="mt-4 text-[36px] sm:text-[52px] leading-[1.05] font-semibold tracking-[-0.03em] text-white text-balance">
              Cards are how people remember you. They should not be a design problem.
            </h1>
            <p className="mt-6 text-[15px] leading-relaxed text-white/55 max-w-xl">
              ZetaCard is a small, focused product: templates that hold up, a studio that stays out of the way, and a public page that works on a phone in one hand.
            </p>
          </div>
        </div>
      </section>

      <Section className="py-20" eyebrow="What we believe" title="Four principles the product is built on">
        <div className="grid sm:grid-cols-2 gap-4">
          {PRINCIPLES.map((p) => (
            <div key={p.title} className="rounded-2xl border border-border bg-card p-7">
              <h3 className="text-[16px] font-medium">{p.title}</h3>
              <p className="mt-2.5 text-[13.5px] leading-relaxed text-muted-foreground">{p.body}</p>
            </div>
          ))}
        </div>
      </Section>

      <div className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-16 grid lg:grid-cols-2 gap-10">
          <div>
            <h2 className="text-[24px] sm:text-[30px] font-semibold leading-tight">Where the product stands today</h2>
            <p className="mt-4 text-[14px] leading-relaxed text-muted-foreground">
              ZetaCard is new. This version is free, with no checkout and no paid tier — so you will not find customer counts, ratings or press logos on this site, because there are none to show yet.
            </p>
            <p className="mt-3 text-[14px] leading-relaxed text-muted-foreground">
              What does exist is the whole creation flow, publishing, sharing, QR codes, exports, enquiries, bookings and analytics. You can judge it by using it.
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-7">
            <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Built for</div>
            <ul className="mt-4 space-y-3 text-[13.5px] text-foreground/80">
              <li>Consultants and freelancers who meet people in person</li>
              <li>Restaurants that reprint menus too often</li>
              <li>Couples who want an invitation people can actually open</li>
              <li>Agents with more listings than business cards</li>
              <li>Small studios that need a services page, not a website project</li>
            </ul>
            <Button asChild variant="outline" className="mt-7 rounded-full h-10 px-4">
              <Link to="/contact">Tell us what is missing <ArrowRight className="w-3.5 h-3.5 ml-1.5" /></Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
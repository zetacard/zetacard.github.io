import React, { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Compass } from "lucide-react";
import Brand from "@/components/site/Brand";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  const location = useLocation();

  useEffect(() => {
    const meta = document.createElement("meta");
    meta.name = "prerender-status-code";
    meta.content = "404";
    document.head.appendChild(meta);
    return () => meta.remove();
  }, []);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="px-5 py-5">
        <Brand />
      </div>
      <div className="flex-1 flex items-center justify-center px-5 pb-16">
        <div className="max-w-md text-center">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center text-primary">
            <Compass className="w-5 h-5" />
          </div>
          <div className="mt-5 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">404</div>
          <h1 className="mt-1.5 text-[24px] font-semibold tracking-tight">This page does not exist</h1>
          <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
            Nothing lives at <span className="font-mono text-[12.5px] text-foreground">{location.pathname}</span>. It may
            have moved, or the link was mistyped.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <Button asChild className="rounded-full h-10 px-5 text-[13px]">
              <Link to="/">Back to ZetaCard</Link>
            </Button>
            <Button asChild variant="outline" className="rounded-full h-10 px-5 text-[13px]">
              <Link to="/dashboard">Go to dashboard</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
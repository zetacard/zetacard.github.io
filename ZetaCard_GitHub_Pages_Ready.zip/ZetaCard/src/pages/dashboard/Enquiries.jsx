import React, { useEffect, useState } from "react";
import { Inbox, Mail, Phone, Loader2, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";

const STATUSES = ["new", "contacted", "won", "closed"];

const STATUS_STYLES = {
  new: "bg-primary/10 text-primary border-primary/20",
  contacted: "bg-amber-50 text-amber-700 border-amber-200",
  won: "bg-emerald-50 text-emerald-700 border-emerald-200",
  closed: "bg-slate-100 text-slate-600 border-slate-200"
};

export default function Enquiries() {
  const [filter, setFilter] = useState("all");
  const [enquiries, setEnquiries] = useState(null);
  const [notes, setNotes] = useState({});
  const [saving, setSaving] = useState("");
  const { toast } = useToast();

  const load = async (status) => {
    const query = status === "all" ? {} : { status };
    const page = await base44.entities.Enquiry.filter(query, { sort: "-created_date", limit: 100 });
    setEnquiries(page.items || []);
  };

  useEffect(() => {
    setEnquiries(null);
    load(filter);
  }, [filter]);

  const setStatus = async (enquiry, status) => {
    setSaving(enquiry.id);
    try {
      await base44.entities.Enquiry.update(enquiry.id, { status });
      load(filter);
    } catch {
      toast({ title: "Could not update", variant: "destructive" });
    } finally {
      setSaving("");
    }
  };

  const saveNote = async (enquiry) => {
    setSaving(enquiry.id);
    try {
      await base44.entities.Enquiry.update(enquiry.id, { notes: notes[enquiry.id] ?? enquiry.notes ?? "" });
      toast({ title: "Note saved" });
    } catch {
      toast({ title: "Could not save the note", variant: "destructive" });
    } finally {
      setSaving("");
    }
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-4xl mx-auto">
      <h1 className="text-[24px] sm:text-[28px] font-semibold tracking-tight">Enquiries</h1>
      <p className="mt-1 text-[13px] text-muted-foreground">
        Messages sent from your public cards. Only you can see these.
      </p>

      <div className="mt-6 flex gap-1 overflow-x-auto no-scrollbar">
        {["all", ...STATUSES].map((status) => (
          <button
            key={status}
            type="button"
            onClick={() => setFilter(status)}
            className={`whitespace-nowrap px-3.5 py-2 rounded-full text-[12.5px] capitalize transition-colors ${
              filter === status ? "bg-foreground text-background" : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {enquiries === null ? (
        <div className="mt-6 space-y-3">
          {[...Array(3)].map((_, i) => <div key={i} className="h-28 rounded-2xl bg-secondary animate-pulse" />)}
        </div>
      ) : enquiries.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-border bg-card p-12 text-center">
          <div className="mx-auto w-11 h-11 rounded-xl bg-secondary flex items-center justify-center text-primary">
            <Inbox className="w-5 h-5" />
          </div>
          <div className="mt-4 text-[15px] font-medium">No enquiries here</div>
          <p className="mt-1.5 text-[13px] text-muted-foreground max-w-sm mx-auto">
            Enquiries appear when someone uses the message form on one of your published cards.
          </p>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {enquiries.map((enquiry) => (
            <div key={enquiry.id} className="rounded-2xl border border-border bg-card p-4 sm:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[14px] font-medium">{enquiry.name}</span>
                    <Badge variant="outline" className={`text-[10.5px] capitalize ${STATUS_STYLES[enquiry.status] || ""}`}>
                      {enquiry.status}
                    </Badge>
                    {enquiry.card_name && (
                      <span className="text-[11px] text-muted-foreground">via {enquiry.card_name}</span>
                    )}
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-muted-foreground">
                    <a href={`mailto:${enquiry.email}`} className="inline-flex items-center gap-1 hover:text-foreground">
                      <Mail className="w-3 h-3" /> {enquiry.email}
                    </a>
                    {enquiry.phone && (
                      <a href={`tel:${enquiry.phone}`} className="inline-flex items-center gap-1 hover:text-foreground">
                        <Phone className="w-3 h-3" /> {enquiry.phone}
                      </a>
                    )}
                    <span>{new Date(enquiry.created_date).toLocaleString()}</span>
                  </div>
                  <p className="mt-3 text-[13px] leading-relaxed">{enquiry.message}</p>
                </div>
                <select
                  value={enquiry.status}
                  onChange={(e) => setStatus(enquiry, e.target.value)}
                  className="h-9 rounded-lg border border-input bg-background px-2 text-[12px] capitalize"
                  aria-label="Enquiry status"
                  disabled={saving === enquiry.id}
                >
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div className="mt-4 pt-3 border-t border-border">
                <Textarea
                  rows={2}
                  value={notes[enquiry.id] ?? enquiry.notes ?? ""}
                  onChange={(e) => setNotes((prev) => ({ ...prev, [enquiry.id]: e.target.value }))}
                  placeholder="Private note — only you see this."
                  className="text-[12.5px]"
                />
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 h-8 rounded-lg text-[11.5px]"
                  onClick={() => saveNote(enquiry)}
                  disabled={saving === enquiry.id}
                >
                  {saving === enquiry.id ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Check className="w-3.5 h-3.5 mr-1.5" />}
                  Save note
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
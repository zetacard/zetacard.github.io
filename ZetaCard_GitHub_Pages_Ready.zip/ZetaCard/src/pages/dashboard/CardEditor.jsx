import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { ArrowLeft, Check, Loader2, AlertCircle, Save, ExternalLink, Nfc } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import TemplateRail from "@/components/dashboard/TemplateRail";
import ImageUploader from "@/components/dashboard/ImageUploader";
import ListEditor from "@/components/dashboard/ListEditor";
import BookingSettings from "@/components/dashboard/BookingSettings";
import PublishPanel from "@/components/dashboard/PublishPanel";
import AiCopilot from "@/components/dashboard/AiCopilot";
import CompletenessPanel from "@/components/dashboard/CompletenessPanel";
import { CATEGORIES, FONT_STYLES, getCategory, templatesFor } from "@/lib/templates";
import { buildSlug, slugify } from "@/lib/cardUtils";
import { useToast } from "@/components/ui/use-toast";

const TEXT_FIELDS = [
  "card_name", "category", "template_id", "headline", "subheadline", "organization", "about",
  "phone", "email", "website", "address", "map_url", "socials", "items", "details",
  "event_date", "event_time", "venue", "portrait_url", "cover_url", "accent", "font_style",
  "booking_enabled", "availability", "enquiry_enabled", "exchange_enabled", "slug", "status"
];

const LABELS = {
  headline: "Name / title",
  subheadline: "Role, price or tagline",
  organization: "Business or practice",
  about: "Description",
  phone: "Phone",
  email: "Email",
  website: "Website",
  address: "Address",
  map_url: "Map link (optional)",
  venue: "Venue",
  event_date: "Date",
  event_time: "Time"
};

const PLACEHOLDERS = {
  headline: "Aarav Mehta",
  subheadline: "Principal Architect",
  organization: "Mehta & Co. Studio",
  about: "A sentence or two about what you do.",
  phone: "+91 98200 41122",
  email: "you@example.com",
  website: "yourstudio.in",
  address: "14 Turner Road, Bandra West, Mumbai",
  map_url: "Google Maps link",
  venue: "The Oberoi Udaivilas",
  event_time: "6:30 PM"
};

const NEW_STATUS = { idle: null, saving: "Saving…", saved: "Saved", error: "Not saved" };

function newCard(categoryId, templateId) {
  const category = getCategory(categoryId);
  return {
    card_name: "",
    category: category.id,
    template_id: templateId || templatesFor(category.id)[0].id,
    status: "draft",
    slug: "",
    headline: "",
    subheadline: "",
    organization: "",
    about: "",
    phone: "",
    email: "",
    website: "",
    address: "",
    map_url: "",
    socials: [],
    items: [],
    details: [],
    event_date: "",
    event_time: "",
    venue: "",
    portrait_url: "",
    cover_url: "",
    accent: "",
    font_style: "",
    booking_enabled: false,
    enquiry_enabled: true,
    exchange_enabled: true,
    availability: { days: [1, 2, 3, 4, 5], start: "09:00", end: "17:00", slot_minutes: 30, timezone: "Asia/Kolkata" }
  };
}

function pick(card) {
  return TEXT_FIELDS.reduce((acc, key) => {
    if (card[key] !== undefined) acc[key] = card[key];
    return acc;
  }, {});
}

export default function CardEditor() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [card, setCard] = useState(() => newCard(params.get("category") || "visiting", params.get("template") || ""));
  const [loading, setLoading] = useState(Boolean(id));
  const [notFound, setNotFound] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [saveState, setSaveState] = useState("idle");
  const [busy, setBusy] = useState(false);
  const [slugError, setSlugError] = useState("");
  const dirtyRef = useRef(false);

  useEffect(() => {
    dirtyRef.current = dirty;
  }, [dirty]);

  useEffect(() => {
    if (!id) {
      setLoading(false);
      return;
    }
    let active = true;
    base44.entities.Card.get(id)
      .then((record) => {
        if (!active) return;
        setCard({ ...newCard(record.category, record.template_id), ...record });
        setSaveState("saved");
      })
      .catch((error) => {
        if (!active) return;
        if (error?.status === 404) setNotFound(true);
        else toast({ title: "Could not load this card", description: "Refresh and try again.", variant: "destructive" });
      })
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [id]);

  // Autosave existing cards
  useEffect(() => {
    if (!card.id || !dirty) return;
    setSaveState("saving");
    const timer = setTimeout(async () => {
      try {
        await base44.entities.Card.update(card.id, pick(card));
        setDirty(false);
        setSaveState("saved");
      } catch {
        setSaveState("error");
      }
    }, 1100);
    return () => clearTimeout(timer);
  }, [card, dirty]);

  useEffect(() => {
    const handler = (event) => {
      if (!dirtyRef.current) return;
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  const category = useMemo(() => getCategory(card.category), [card.category]);
  const requiredMissing = useMemo(
    () =>
      (category.required || [])
        .filter((field) => {
          const value = card[field];
          return Array.isArray(value) ? value.length === 0 : !String(value || "").trim();
        })
        .map((field) => LABELS[field] || field.replace("_", " ")),
    [card, category]
  );

  const update = (key, value) => {
    setCard((prev) => ({ ...prev, [key]: value }));
    setDirty(true);
    if (saveState !== "saving") setSaveState("idle");
  };

  const applyPatch = (patch) => {
    setCard((prev) => ({ ...prev, ...patch }));
    setDirty(true);
    if (saveState !== "saving") setSaveState("idle");
  };

  const FALLBACK_SECTION = {
    accent: "section-design",
    font_style: "section-design",
    template_id: "section-design",
    portrait_url: "section-content",
    cover_url: "section-content",
    socials: "section-content",
    items: "section-content",
    details: "section-content",
    exchange_enabled: "section-visitors"
  };

  const focusField = (field) => {
    const target =
      document.getElementById(field) ||
      document.getElementById(FALLBACK_SECTION[field] || "section-content");
    if (!target) return;
    target.scrollIntoView({ behavior: "smooth", block: "center" });
    if (typeof target.focus === "function") target.focus({ preventScroll: true });
  };

  const changeCategory = (categoryId) => {
    const next = getCategory(categoryId);
    setCard((prev) => ({
      ...prev,
      category: next.id,
      template_id: templatesFor(next.id)[0].id
    }));
    setDirty(true);
  };

  const ensureUniqueSlug = async (desired) => {
    const base = slugify(desired);
    if (!base) return buildSlug(card.headline || card.card_name);
    const page = await base44.entities.Card.filter({ slug: base }, { limit: 1 });
    if (!page.items?.length) return base;
    return buildSlug(base);
  };

  const persist = async (publish) => {
    setBusy(true);
    setSlugError("");
    try {
      const data = pick(card);
      if (publish) {
        if (requiredMissing.length) {
          toast({ title: "A few details are missing", description: `Please add ${requiredMissing.join(", ").toLowerCase()}.`, variant: "destructive" });
          setBusy(false);
          return;
        }
        data.slug = card.slug ? await ensureUniqueSlug(card.slug) : await ensureUniqueSlug(card.headline || card.card_name);
        data.status = "published";
      }

      if (card.id) {
        await base44.entities.Card.update(card.id, data);
        setCard((prev) => ({ ...prev, ...data }));
        setDirty(false);
        setSaveState("saved");
        toast({ title: publish ? "Card published" : "Draft saved" });
      } else {
        const created = await base44.entities.Card.create({
          ...data,
          card_name: data.card_name || data.headline || `${category.short} card`,
          status: publish ? "published" : "draft"
        });
        setDirty(false);
        navigate(`/dashboard/cards/${created.id}`, { replace: true });
        toast({ title: publish ? "Card published" : "Draft created" });
      }
    } catch (error) {
      toast({ title: "That did not save", description: error?.response?.data?.error || "Please try again.", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const unpublish = async () => {
    setBusy(true);
    try {
      await base44.entities.Card.update(card.id, { status: "draft" });
      setCard((prev) => ({ ...prev, status: "draft" }));
      toast({ title: "Card unpublished", description: "The public link now shows a not-available page." });
    } catch {
      toast({ title: "Could not unpublish", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const setSlug = (value) => {
    const clean = slugify(value);
    setSlugError(value && clean !== value.toLowerCase().trim() ? "Only letters, numbers and hyphens are allowed." : "");
    update("slug", clean);
  };

  if (loading) {
    return (
      <div className="p-6 lg:p-10 max-w-6xl mx-auto">
        <div className="h-8 w-48 rounded-lg bg-secondary animate-pulse" />
        <div className="mt-8 grid lg:grid-cols-[1fr_420px] gap-6">
          <div className="h-96 rounded-2xl bg-secondary animate-pulse" />
          <div className="h-96 rounded-2xl bg-secondary animate-pulse" />
        </div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="p-6 lg:p-10 max-w-xl mx-auto text-center">
        <div className="mt-16 text-[18px] font-medium">This card is not available</div>
        <p className="mt-2 text-[13px] text-muted-foreground">
          It may have been deleted, or it belongs to another account.
        </p>
        <Button asChild className="mt-6 rounded-full"><Link to="/dashboard/cards">Back to my cards</Link></Button>
      </div>
    );
  }

  const saveLabel = NEW_STATUS[saveState] || (dirty ? "Unsaved changes" : null);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-[1240px] mx-auto">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div className="flex items-center gap-2 min-w-0">
          <Button asChild variant="ghost" size="sm" className="h-9 px-2">
            <Link to="/dashboard/cards" aria-label="Back to cards"><ArrowLeft className="w-4 h-4" /></Link>
          </Button>
          <div className="min-w-0">
            <div className="text-[15px] font-semibold truncate">{card.card_name || "Untitled card"}</div>
            <div className="text-[11.5px] text-muted-foreground capitalize">{category.short} · {card.status}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11.5px] text-muted-foreground inline-flex items-center gap-1.5">
            {saveState === "saving" && <Loader2 className="w-3 h-3 animate-spin" />}
            {saveState === "saved" && <Check className="w-3 h-3 text-primary" />}
            {saveState === "error" && <AlertCircle className="w-3 h-3 text-destructive" />}
            {saveLabel}
          </span>
          {card.status === "published" && card.slug && (
            <Button asChild variant="outline" size="sm" className="h-9 rounded-lg text-[12px]">
              <Link to={`/c/${card.slug}`} target="_blank">Public page <ExternalLink className="w-3 h-3 ml-1.5" /></Link>
            </Button>
          )}
          {card.id && (
            <Button asChild variant="outline" size="sm" className="h-9 rounded-lg text-[12px]">
              <Link to={`/dashboard/cards/${card.id}/share`}><Nfc className="w-3.5 h-3.5 mr-1.5" /> Share & NFC</Link>
            </Button>
          )}
          {!card.id && (
            <Button size="sm" variant="outline" className="h-9 rounded-lg text-[12px]" onClick={() => persist(false)} disabled={busy}>
              <Save className="w-3.5 h-3.5 mr-1.5" /> Save draft
            </Button>
          )}
        </div>
      </div>

      <div className="mt-6 grid lg:grid-cols-[minmax(0,1fr)_420px] gap-6 items-start">
        <div className="space-y-4 min-w-0">
          {/* Basics */}
          <section className="rounded-2xl border border-border bg-card p-5">
            <h2 className="text-[13px] font-medium">Basics</h2>
            <div className="mt-4 space-y-4">
              <div>
                <Label htmlFor="card_name" className="text-[12.5px]">Internal card name</Label>
                <Input
                  id="card_name"
                  value={card.card_name}
                  onChange={(e) => update("card_name", e.target.value)}
                  placeholder="e.g. Aarav — visiting card"
                  className="mt-1.5 h-10 text-[13px]"
                />
                <p className="mt-1 text-[11px] text-muted-foreground">Only you see this. It helps you find the card in your dashboard.</p>
              </div>
              <div>
                <Label htmlFor="category" className="text-[12.5px]">Category</Label>
                <select
                  id="category"
                  value={card.category}
                  onChange={(e) => changeCategory(e.target.value)}
                  className="mt-1.5 h-10 w-full rounded-md border border-input bg-background px-3 text-[13px]"
                >
                  {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Changing the category changes the fields and the available designs. Saved text is kept.
                </p>
              </div>
            </div>
          </section>

          {/* Design */}
          <section id="section-design" className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-[13px] font-medium">Design</h2>
              <span className="text-[11px] text-muted-foreground">{templatesFor(card.category).length} designs</span>
            </div>
            <div className="mt-4">
              <TemplateRail card={card} onSelect={(templateId) => update("template_id", templateId)} />
            </div>
            <div className="mt-5 grid sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-[12px]">Accent colour</Label>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="color"
                    value={card.accent || "#12163A"}
                    onChange={(e) => update("accent", e.target.value)}
                    className="w-9 h-9 rounded-lg border border-border bg-transparent p-0.5"
                    aria-label="Accent colour"
                  />
                  <Button type="button" variant="ghost" size="sm" className="h-8 text-[11.5px]" onClick={() => update("accent", "")}>
                    Use template colour
                  </Button>
                </div>
              </div>
              <div>
                <Label className="text-[12px]">Typography</Label>
                <select
                  value={card.font_style || ""}
                  onChange={(e) => update("font_style", e.target.value)}
                  className="mt-2 h-9 w-full rounded-md border border-input bg-background px-2.5 text-[12.5px]"
                >
                  <option value="">Template default</option>
                  {FONT_STYLES.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
                </select>
              </div>
            </div>
          </section>

          {/* Content */}
          <section id="section-content" className="rounded-2xl border border-border bg-card p-5">
            <h2 className="text-[13px] font-medium">Content</h2>
            <div className="mt-4 space-y-4">
              {category.fields.map((field) => {
                if (field === "socials") {
                  return (
                    <ListEditor
                      key={field}
                      label="Social links"
                      hint="Shown as text on the card and as links on the public page."
                      items={card.socials}
                      onChange={(value) => update("socials", value)}
                      addLabel="Add link"
                      max={6}
                      fields={[
                        { key: "label", placeholder: "Instagram" },
                        { key: "url", placeholder: "https://instagram.com/you" }
                      ]}
                    />
                  );
                }
                if (field === "items") {
                  return (
                    <ListEditor
                      key={field}
                      label={card.category === "menu" ? "Menu items" : card.category === "catalog" ? "Services" : "Items"}
                      hint="Name, a short description and a price."
                      items={card.items}
                      onChange={(value) => update("items", value)}
                      addLabel="Add row"
                      max={10}
                      fields={[
                        { key: "name", placeholder: "Item name" },
                        { key: "price", placeholder: "₹480" },
                        { key: "description", placeholder: "Short description", wide: true }
                      ]}
                    />
                  );
                }
                if (field === "details") {
                  return (
                    <ListEditor
                      key={field}
                      label="Details"
                      hint="Specifications, schedule, dress code — anything in label/value pairs."
                      items={card.details}
                      onChange={(value) => update("details", value)}
                      addLabel="Add detail"
                      max={8}
                      fields={[
                        { key: "label", placeholder: "Label" },
                        { key: "value", placeholder: "Value" }
                      ]}
                    />
                  );
                }
                if (field === "portrait_url" || field === "cover_url") {
                  return (
                    <ImageUploader
                      key={field}
                      label={field === "portrait_url" ? "Portrait or logo" : "Cover image"}
                      hint={field === "portrait_url" ? "Square images look best. Stored publicly — anyone with the link can open it." : "Wide images look best. Stored publicly — anyone with the link can open it."}
                      value={card[field]}
                      onChange={(value) => update(field, value)}
                      aspect={field === "portrait_url" ? "1 / 1" : "16 / 9"}
                    />
                  );
                }
                if (field === "about") {
                  return (
                    <div key={field}>
                      <Label htmlFor={field} className="text-[12.5px]">{LABELS[field]}</Label>
                      <Textarea
                        id={field}
                        value={card[field] || ""}
                        onChange={(e) => update(field, e.target.value)}
                        rows={4}
                        placeholder={PLACEHOLDERS[field]}
                        className="mt-1.5 text-[13px]"
                      />
                    </div>
                  );
                }
                if (field === "address") {
                  return (
                    <div key={field}>
                      <Label htmlFor={field} className="text-[12.5px]">{LABELS[field]}</Label>
                      <Textarea
                        id={field}
                        value={card[field] || ""}
                        onChange={(e) => update(field, e.target.value)}
                        rows={2}
                        placeholder={PLACEHOLDERS[field]}
                        className="mt-1.5 text-[13px]"
                      />
                    </div>
                  );
                }
                return (
                  <div key={field}>
                    <Label htmlFor={field} className="text-[12.5px]">
                      {category.labels?.[field] || LABELS[field] || field}
                    </Label>
                    <Input
                      id={field}
                      type={field === "event_date" ? "date" : field === "email" ? "email" : field === "phone" ? "tel" : "text"}
                      value={card[field] || ""}
                      onChange={(e) => update(field, e.target.value)}
                      placeholder={PLACEHOLDERS[field]}
                      className="mt-1.5 h-10 text-[13px]"
                    />
                  </div>
                );
              })}
            </div>
          </section>

          {/* Sharing & bookings */}
          <section id="section-visitors" className="rounded-2xl border border-border bg-card p-5">
            <h2 className="text-[13px] font-medium">Visitors</h2>
            <div className="mt-4">
              <BookingSettings card={card} onChange={update} />
            </div>
            <label className="mt-4 pt-4 border-t border-border flex items-start justify-between gap-4 cursor-pointer">
              <span>
                <span className="block text-[12.5px] font-medium">Contact exchange</span>
                <span className="mt-0.5 block text-[11px] leading-relaxed text-muted-foreground">
                  Visitors can send their name, email and phone so you can follow up. They land in your Contacts — stored privately, never shown on the card.
                </span>
              </span>
              <input
                type="checkbox"
                checked={card.exchange_enabled !== false}
                onChange={(e) => update("exchange_enabled", e.target.checked)}
                className="mt-0.5 w-4 h-4 shrink-0 rounded border-border accent-[hsl(var(--primary))]"
                aria-label="Enable contact exchange"
              />
            </label>
          </section>
        </div>

        {/* Preview */}
        <div className="lg:sticky lg:top-6 space-y-4 min-w-0">
          <div className="rounded-2xl border border-border bg-card p-3">
            <div className="flex items-center justify-between px-1 pb-2">
              <span className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Live preview</span>
              <span className="text-[11px] text-muted-foreground">{category.canvas.w} × {category.canvas.h}</span>
            </div>
            <div className="rounded-xl overflow-hidden border border-border">
              <ScaledCanvas card={card} radius={0} />
            </div>
          </div>

          <CompletenessPanel card={card} onFocus={focusField} />
          <AiCopilot card={card} onApply={applyPatch} />
          <PublishPanel
            card={card}
            onSlugChange={(value) => (value ? setSlug(value) : update("slug", ""))}
            onPublish={() => persist(true)}
            onUnpublish={unpublish}
            busy={busy}
            requiredMissing={requiredMissing}
          />
          {slugError && <p className="text-[11px] text-destructive px-1">{slugError}</p>}
        </div>
      </div>
    </div>
  );
}
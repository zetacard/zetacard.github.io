import React, { useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import {
  LayoutDashboard, IdCard, CalendarClock, Inbox, Users, BarChart3, Settings, LifeBuoy,
  Plus, LogOut, Menu, X, Globe
} from "lucide-react";
import Brand from "@/components/site/Brand";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";

const NAV = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "/dashboard/cards", label: "My cards", icon: IdCard },
  { to: "/dashboard/bookings", label: "Bookings", icon: CalendarClock },
  { to: "/dashboard/enquiries", label: "Enquiries", icon: Inbox },
  { to: "/dashboard/contacts", label: "Contacts", icon: Users },
  { to: "/dashboard/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/dashboard/settings", label: "Settings", icon: Settings }
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const nav = (
    <nav className="flex flex-col gap-0.5">
      {NAV.map(({ to, label, icon: Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          onClick={() => setOpen(false)}
          className={({ isActive }) =>
            `flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13.5px] transition-colors ${
              isActive ? "bg-secondary text-foreground font-medium" : "text-muted-foreground hover:text-foreground hover:bg-secondary/60"
            }`
          }
        >
          <Icon className="w-4 h-4" />
          {label}
        </NavLink>
      ))}
      <div className="h-px bg-border my-3" />
      <Link to="/help" className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13.5px] text-muted-foreground hover:text-foreground hover:bg-secondary/60">
        <LifeBuoy className="w-4 h-4" /> Help
      </Link>
      <Link to="/" className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13.5px] text-muted-foreground hover:text-foreground hover:bg-secondary/60">
        <Globe className="w-4 h-4" /> Public site
      </Link>
    </nav>
  );

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="flex">
        <aside className="hidden lg:flex flex-col w-[248px] shrink-0 h-screen sticky top-0 border-r border-border bg-card px-4 py-5">
          <div className="px-2 mb-6"><Brand /></div>
          <Button asChild className="w-full rounded-lg h-9 text-[13px] mb-5">
            <Link to="/dashboard/new"><Plus className="w-3.5 h-3.5 mr-1.5" /> New card</Link>
          </Button>
          {nav}
          <div className="mt-auto pt-4 border-t border-border">
            <div className="px-3 py-2">
              <div className="text-[12.5px] font-medium truncate">{user?.full_name || "Your account"}</div>
              <div className="text-[11.5px] text-muted-foreground truncate">{user?.email}</div>
            </div>
            <button
              type="button"
              onClick={() => logout()}
              className="flex w-full items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] text-muted-foreground hover:text-foreground hover:bg-secondary/60"
            >
              <LogOut className="w-4 h-4" /> Sign out
            </button>
          </div>
        </aside>

        <div className="flex-1 min-w-0">
          <header className="lg:hidden sticky top-0 z-40 bg-background/90 backdrop-blur-xl border-b border-border">
            <div className="h-14 px-4 flex items-center justify-between">
              <Brand />
              <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-secondary"
                aria-label={open ? "Close menu" : "Open menu"}
              >
                {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
            {open && <div className="px-4 pb-4">{nav}<button type="button" onClick={() => logout()} className="w-full text-left px-3 py-2.5 text-[13px] text-muted-foreground">Sign out</button></div>}
          </header>

          <div key={location.pathname} className="pb-20 lg:pb-8">
            <Outlet />
          </div>
        </div>
      </div>

      <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-card/95 backdrop-blur border-t border-border">
        <div className="grid grid-cols-5">
          {[NAV[0], NAV[1], { to: "/dashboard/new", label: "Create", icon: Plus }, NAV[4], NAV[6]].map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/dashboard"}
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 py-2.5 text-[10.5px] ${isActive ? "text-primary" : "text-muted-foreground"}`
              }
            >
              <Icon className="w-4 h-4" />
              {label}
            </NavLink>
          ))}
        </div>
      </div>
    </div>
  );
}
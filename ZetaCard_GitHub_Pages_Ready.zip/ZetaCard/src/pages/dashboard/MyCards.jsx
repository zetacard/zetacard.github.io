import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Plus, Search, Copy, Files, ExternalLink, Archive, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import { publicCardUrl } from "@/lib/cardUtils";
import { useToast } from "@/components/ui/use-toast";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";

const TABS = [
  { id: "all", label: "All" },
  { id: "draft", label: "Drafts" },
  { id: "published", label: "Published" },
  { id: "archived", label: "Archived" }
];

export default function MyCards() {
  const [tab, setTab] = useState("all");
  const [search, setSearch] = useState("");
  const [cards, setCards] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const load = async (status, term) => {
    const query = {};
    if (status !== "all") query.status = status;
    if (term.trim()) query.card_name = { $regex: term.trim(), $options: "i" };
    const page = await base44.entities.Card.filter(query, { sort: "-updated_date", limit: 60 });
    setCards(page.items || []);
  };

  useEffect(() => {
    const timer = setTimeout(() => load(tab, search), search ? 300 : 0);
    return () => clearTimeout(timer);
  }, [tab, search]);

  const duplicate = async (card) => {
    const { id, created_date, updated_date, created_by_id, created_by, ...rest } = card;
    await base44.entities.Card.create({
      ...rest,
      card_name: `${card.card_name} copy`,
      status: "draft",
      slug: ""
    });
    load(tab, search);
    toast({ title: "Card duplicated as a draft" });
  };

  const archive = async (card) => {
    await base44.entities.Card.update(card.id, { status: card.status === "archived" ? "draft" : "archived" });
    load(tab, search);
    toast({ title: card.status === "archived" ? "Card restored to drafts" : "Card archived" });
  };

  const remove = async () => {
    if (!toDelete) return;
    await base44.entities.Card.delete(toDelete.id);
    setToDelete(null);
    load(tab, search);
    toast({ title: "Card deleted" });
  };

  const copy = async (slug) => {
    try {
      await navigator.clipboard.writeText(publicCardUrl(slug));
      toast({ title: "Link copied" });
    } catch {
      toast({ title: "Could not copy", description: "Copy the link from the card's publish panel instead.", variant: "destructive" });
    }
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-6xl mx-auto">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[24px] sm:text-[28px] font-semibold tracking-tight">My cards</h1>
          <p className="mt-1 text-[13px] text-muted-foreground">Drafts, published cards and archived work.</p>
        </div>
        <Button asChild className="rounded-full h-10 px-4 text-[13px]">
          <Link to="/dashboard/new"><Plus className="w-3.5 h-3.5 mr-1.5" /> New card</Link>
        </Button>
      </div>

      <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="flex gap-1 overflow-x-auto no-scrollbar">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`whitespace-nowrap px-3.5 py-2 rounded-full text-[12.5px] transition-colors ${
                tab === t.id ? "bg-foreground text-background" : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="relative sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name" className="pl-9 h-10 text-[13px]" />
        </div>
      </div>

      {cards === null ? (
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => <div key={i} className="h-72 rounded-2xl bg-secondary animate-pulse" />)}
        </div>
      ) : cards.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-border bg-card p-12 text-center">
          <div className="text-[15px] font-medium">{search ? "No cards match that search" : "Nothing here yet"}</div>
          <p className="mt-1.5 text-[13px] text-muted-foreground">
            {search ? "Try a different word, or clear the search." : "Start a card and it will appear here as a draft."}
          </p>
          {!search && (
            <Button asChild className="mt-5 rounded-full h-10 px-5 text-[13px]">
              <Link to="/dashboard/new">Create a card</Link>
            </Button>
          )}
        </div>
      ) : (
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card) => (
            <div key={card.id} className="rounded-2xl border border-border bg-card p-3">
              <Link to={`/dashboard/cards/${card.id}`} className="block rounded-xl overflow-hidden border border-border">
                <ScaledCanvas card={card} radius={0} />
              </Link>
              <div className="px-1 pt-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <Link to={`/dashboard/cards/${card.id}`} className="text-[13px] font-medium hover:underline truncate block">
                      {card.card_name}
                    </Link>
                    <div className="text-[11px] text-muted-foreground capitalize mt-0.5">
                      {card.status} · {card.category}
                    </div>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  <Button asChild variant="secondary" size="sm" className="h-8 rounded-lg text-[11.5px] px-2.5">
                    <Link to={`/dashboard/cards/${card.id}`}>Edit</Link>
                  </Button>
                  {card.status === "published" && card.slug && (
                    <>
                      <Button variant="ghost" size="sm" className="h-8 px-2 rounded-lg" onClick={() => copy(card.slug)} aria-label="Copy link">
                        <Copy className="w-3.5 h-3.5" />
                      </Button>
                      <Button asChild variant="ghost" size="sm" className="h-8 px-2 rounded-lg">
                        <a href={`/c/${card.slug}`} target="_blank" rel="noreferrer" aria-label="Open public card">
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </Button>
                    </>
                  )}
                  <div className="ml-auto flex items-center gap-0.5">
                    <Button variant="ghost" size="sm" className="h-8 px-2 rounded-lg" onClick={() => duplicate(card)} aria-label="Duplicate">
                      <Files className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 px-2 rounded-lg" onClick={() => archive(card)} aria-label="Archive">
                      <Archive className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 px-2 rounded-lg text-destructive" onClick={() => setToDelete(card)} aria-label="Delete">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!toDelete} onOpenChange={(open) => !open && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete “{toDelete?.card_name}”?</AlertDialogTitle>
            <AlertDialogDescription>
              The card and its public page are removed permanently. Enquiries and bookings already received stay in your inbox. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep card</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, Check, AlertTriangle, Mail, Trash2, ShieldCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";

export default function Settings() {
  const { user, logout, checkUserAuth } = useAuth();
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [savingName, setSavingName] = useState(false);
  const [counts, setCounts] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (user?.full_name) setName(user.full_name);
  }, [user]);

  useEffect(() => {
    base44.entities.Card.count({}).then(setCounts);
  }, []);

  const saveName = async () => {
    setSavingName(true);
    try {
      await base44.auth.updateMe({ full_name: name.trim() });
      await checkUserAuth();
      toast({ title: "Profile updated" });
    } catch {
      toast({ title: "Could not update your profile", variant: "destructive" });
    } finally {
      setSavingName(false);
    }
  };

  const deleteData = async () => {
    setDeleting(true);
    try {
      const response = await base44.functions.invoke("deleteMyData", { confirm: "DELETE" });
      if (response.data?.error) {
        toast({ title: "Could not delete data", description: response.data.error, variant: "destructive" });
        setDeleting(false);
        return;
      }
      toast({
        title: "Your card data has been deleted",
        description: `${response.data.deleted.cards} cards, ${response.data.deleted.enquiries} enquiries, ${response.data.deleted.bookings} bookings and ${response.data.deleted.events} events removed.`
      });
      setConfirmOpen(false);
      setDeleting(false);
      logout();
    } catch {
      toast({ title: "Could not delete data", description: "Please try again.", variant: "destructive" });
      setDeleting(false);
    }
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-3xl mx-auto">
      <h1 className="text-[24px] sm:text-[28px] font-semibold tracking-tight">Settings</h1>
      <p className="mt-1 text-[13px] text-muted-foreground">Your account, your data, and what is connected.</p>

      <section className="mt-7 rounded-2xl border border-border bg-card p-5">
        <h2 className="text-[13px] font-medium">Profile</h2>
        <div className="mt-4 grid sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="full_name" className="text-[12.5px]">Full name</Label>
            <Input id="full_name" value={name} onChange={(e) => setName(e.target.value)} className="mt-1.5 h-10 text-[13px]" />
          </div>
          <div>
            <Label className="text-[12.5px]">Login email</Label>
            <Input value={user?.email || ""} readOnly className="mt-1.5 h-10 text-[13px] bg-secondary/60" />
          </div>
        </div>
        <Button size="sm" className="mt-4 h-9 rounded-lg text-[12px]" onClick={saveName} disabled={savingName || !name.trim()}>
          {savingName ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Check className="w-3.5 h-3.5 mr-1.5" />} Save profile
        </Button>
        <p className="mt-2 text-[11px] text-muted-foreground">
          Your email is used to sign in and is never shown on a card unless you type it into a card field.
        </p>
      </section>

      <section className="mt-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-primary" />
          <h2 className="text-[13px] font-medium">Booking emails</h2>
        </div>
        <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
          Booking requests are always saved here first. Notifications use the platform's built-in email sender, so you
          don't need an API key or your own domain. Booking requests are emailed to your login address. Confirmation
          emails to visitors go out only when their address belongs to a registered app user and your plan allows it;
          otherwise the booking is still recorded and the email is marked as not sent.
        </p>
        <div className="mt-3 inline-flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
          <AlertTriangle className="w-3.5 h-3.5" /> Email delivery is reported separately from the saved record.
        </div>
      </section>

      <section className="mt-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-primary" />
          <h2 className="text-[13px] font-medium">Privacy and access</h2>
        </div>
        <ul className="mt-3 space-y-2 text-[12.5px] leading-relaxed text-muted-foreground">
          <li>Published cards are readable by anyone with the link. Drafts and archived cards are private.</li>
          <li>Enquiries, bookings and analytics are restricted to your account on the server.</li>
          <li>Visitors who submit a booking can only see the confirmation shown on the page.</li>
          <li>Read the <Link to="/privacy" className="text-primary hover:underline">privacy policy</Link> for the full picture.</li>
        </ul>
      </section>

      <section className="mt-4 rounded-2xl border border-destructive/30 bg-destructive/[0.03] p-5">
        <div className="flex items-center gap-2">
          <Trash2 className="w-4 h-4 text-destructive" />
          <h2 className="text-[13px] font-medium">Delete my data</h2>
        </div>
        <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
          Removes every card you own — published or draft — along with their enquiries, bookings and analytics events.
          This cannot be undone, and any printed QR code will stop working. You will be signed out afterwards.
        </p>
        <p className="mt-2 text-[12px] text-muted-foreground">
          You currently have {counts === null ? "…" : counts} card{counts === 1 ? "" : "s"} on this account.
        </p>
        <Button variant="destructive" size="sm" className="mt-4 h-9 rounded-lg text-[12px]" onClick={() => setConfirmOpen(true)}>
          Delete my data
        </Button>
      </section>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete all ZetaCard data?</AlertDialogTitle>
            <AlertDialogDescription>
              Type DELETE to confirm. Every card, enquiry, booking and analytics event on this account is removed permanently.
              Your login record stays with the platform; contact support if you also want the account removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="DELETE" className="mt-1" />
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setConfirmText("")}>Keep my data</AlertDialogCancel>
            <AlertDialogAction
              onClick={(event) => {
                if (confirmText !== "DELETE") {
                  event.preventDefault();
                  return;
                }
                deleteData();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? "Deleting…" : "Delete everything"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
import React, { useEffect, useState } from "react";
import { CalendarClock, Check, X, CheckCheck, Mail, AlertCircle, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";

const TABS = [
  { id: "pending", label: "Pending" },
  { id: "confirmed", label: "Confirmed" },
  { id: "completed", label: "Completed" },
  { id: "cancelled", label: "Cancelled" },
  { id: "all", label: "All" }
];

const STATUS_STYLES = {
  pending: "bg-amber-50 text-amber-700 border-amber-200",
  confirmed: "bg-emerald-50 text-emerald-700 border-emerald-200",
  cancelled: "bg-rose-50 text-rose-700 border-rose-200",
  completed: "bg-slate-100 text-slate-600 border-slate-200"
};

function emailNote(status) {
  if (!status || status === "pending") return null;
  if (status.includes("sent")) return "Email sent";
  if (status.includes("failed")) return "Email not delivered";
  if (status.includes("skipped")) return "No valid email address";
  if (status.includes("not_configured")) return "No email sent";
  return null;
}

export default function Bookings() {
  const [tab, setTab] = useState("pending");
  const [bookings, setBookings] = useState(null);
  const [working, setWorking] = useState("");
  const { toast } = useToast();

  const load = async (status) => {
    const query = status === "all" ? {} : { status };
    const page = await base44.entities.Booking.filter(query, { sort: "-created_date", limit: 100 });
    setBookings(page.items || []);
  };

  useEffect(() => {
    setBookings(null);
    load(tab);
  }, [tab]);

  const act = async (booking, status) => {
    setWorking(booking.id);
    try {
      const response = await base44.functions.invoke("updateBookingStatus", { id: booking.id, status });
      if (response.data?.error) {
        toast({ title: "Could not update", description: response.data.error, variant: "destructive" });
      } else {
        const note = response.data?.email_status;
        toast({
          title: status === "confirmed" ? "Booking confirmed" : status === "cancelled" ? "Booking cancelled" : "Booking completed",
          description: note === "failed" ? "Saved, but the confirmation email could not be delivered." : note === "skipped" ? "Saved. No confirmation email was sent." : undefined
        });
        load(tab);
      }
    } catch {
      toast({ title: "Could not update", description: "Please try again.", variant: "destructive" });
    } finally {
      setWorking("");
    }
  };

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-5xl mx-auto">
      <h1 className="text-[24px] sm:text-[28px] font-semibold tracking-tight">Bookings</h1>
      <p className="mt-1 text-[13px] text-muted-foreground">
        Requests made through your cards. A booking is only confirmed when you confirm it here.
      </p>

      <div className="mt-6 flex gap-1 overflow-x-auto no-scrollbar">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`whitespace-nowrap px-3.5 py-2 rounded-full text-[12.5px] transition-colors ${
              tab === t.id ? "bg-foreground text-background" : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {bookings === null ? (
        <div className="mt-6 space-y-3">
          {[...Array(3)].map((_, i) => <div key={i} className="h-24 rounded-2xl bg-secondary animate-pulse" />)}
        </div>
      ) : bookings.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-border bg-card p-12 text-center">
          <div className="mx-auto w-11 h-11 rounded-xl bg-secondary flex items-center justify-center text-primary">
            <CalendarClock className="w-5 h-5" />
          </div>
          <div className="mt-4 text-[15px] font-medium">No {tab === "all" ? "" : tab} bookings</div>
          <p className="mt-1.5 text-[13px] text-muted-foreground max-w-sm mx-auto">
            Turn on bookings in a card's editor to let visitors request a time slot.
          </p>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {bookings.map((booking) => (
            <div key={booking.id} className="rounded-2xl border border-border bg-card p-4 sm:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[14px] font-medium">{booking.visitor_name}</span>
                    <Badge variant="outline" className={`text-[10.5px] capitalize ${STATUS_STYLES[booking.status] || ""}`}>
                      {booking.status}
                    </Badge>
                  </div>
                  <div className="mt-1 text-[12.5px] text-muted-foreground">
                    {booking.date} · {booking.time} ({booking.timezone || "local"}) · {booking.card_name}
                  </div>
                  <div className="mt-2 text-[12.5px]">
                    <a href={`mailto:${booking.visitor_email}`} className="text-primary hover:underline">{booking.visitor_email}</a>
                    {booking.visitor_phone && <span className="text-muted-foreground"> · {booking.visitor_phone}</span>}
                  </div>
                  {booking.message && (
                    <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground border-l-2 border-border pl-3">
                      {booking.message}
                    </p>
                  )}
                  {emailNote(booking.email_status) && (
                    <div className="mt-2 inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      {booking.email_status.includes("failed") ? <AlertCircle className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
                      {emailNote(booking.email_status)}
                    </div>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  {booking.status === "pending" && (
                    <>
                      <Button size="sm" className="h-9 rounded-lg text-[12px]" onClick={() => act(booking, "confirmed")} disabled={working === booking.id}>
                        {working === booking.id ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Check className="w-3.5 h-3.5 mr-1.5" />} Confirm
                      </Button>
                      <Button size="sm" variant="outline" className="h-9 rounded-lg text-[12px]" onClick={() => act(booking, "cancelled")} disabled={working === booking.id}>
                        <X className="w-3.5 h-3.5 mr-1.5" /> Decline
                      </Button>
                    </>
                  )}
                  {booking.status === "confirmed" && (
                    <>
                      <Button size="sm" variant="outline" className="h-9 rounded-lg text-[12px]" onClick={() => act(booking, "completed")} disabled={working === booking.id}>
                        <CheckCheck className="w-3.5 h-3.5 mr-1.5" /> Mark completed
                      </Button>
                      <Button size="sm" variant="ghost" className="h-9 rounded-lg text-[12px] text-destructive" onClick={() => act(booking, "cancelled")} disabled={working === booking.id}>
                        Cancel
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
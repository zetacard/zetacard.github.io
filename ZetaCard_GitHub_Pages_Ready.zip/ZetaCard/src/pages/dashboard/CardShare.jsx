import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft, Copy, Check, ExternalLink, Download, Printer, Nfc, QrCode as QrIcon,
  Loader2, AlertCircle, Pencil
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import QrCode, { downloadQr } from "@/components/card/QrCode";
import { useToast } from "@/components/ui/use-toast";
import { publicCardUrl } from "@/lib/cardUtils";

const STEPS = [
  "Open your phone's NFC app, or any free NFC writer app from your app store.",
  "Choose \"Write tag\" or \"Write URL\", then paste the profile link below.",
  "Hold the phone against your NFC card or sticker until the app confirms the write.",
  "Test it: lock your phone, then tap the card. Your page should open in the browser."
];

export default function CardShare() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [card, setCard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let active = true;
    base44.entities.Card.get(id)
      .then((record) => active && setCard(record))
      .catch((error) => {
        if (!active) return;
        if (error?.status === 404) setMissing(true);
      })
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [id]);

  const url = card?.slug ? publicCardUrl(card.slug) : "";
  const live = card?.status === "published" && Boolean(card?.slug);

  const track = (type) => {
    if (!card) return;
    base44.functions.invoke("trackEvent", { card_id: card.id, type, source: "share" }).catch(() => {});
  };

  const copy = async () => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      track("share");
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "Link copied" });
    } catch {
      toast({ title: "Copy did not work", description: "Select the link and copy it manually.", variant: "destructive" });
    }
  };

  const download = async () => {
    if (!url) return;
    try {
      await downloadQr(url, `zetacard-${card.slug}-qr.png`);
      toast({ title: "QR code downloaded" });
    } catch {
      toast({ title: "Could not create the QR file", variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="p-10 flex items-center justify-center text-muted-foreground">
        <Loader2 className="w-5 h-5 animate-spin" />
      </div>
    );
  }

  if (missing || !card) {
    return (
      <div className="p-6 max-w-xl mx-auto text-center">
        <div className="mt-16 text-[16px] font-medium">This card is not available</div>
        <p className="mt-2 text-[13px] text-muted-foreground">It may have been deleted, or it belongs to another account.</p>
        <Button asChild className="mt-6 rounded-full"><Link to="/dashboard/cards">Back to my cards</Link></Button>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-[900px] mx-auto">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" className="h-9 px-2" onClick={() => navigate(`/dashboard/cards/${card.id}`)} aria-label="Back to editor">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="min-w-0">
          <h1 className="text-[18px] font-semibold tracking-tight truncate">Share & NFC</h1>
          <div className="text-[11.5px] text-muted-foreground truncate">{card.card_name || card.headline || "Untitled card"}</div>
        </div>
      </div>

      {!live && (
        <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4">
          <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
          <div>
            <div className="text-[12.5px] font-medium">Publish first to get a working link</div>
            <p className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">
              This card is still a draft, so there is no public address to put on a QR code or NFC tag yet.
            </p>
            <Button asChild size="sm" variant="outline" className="mt-3 h-8 rounded-lg text-[11.5px]">
              <Link to={`/dashboard/cards/${card.id}`}><Pencil className="w-3.5 h-3.5 mr-1.5" /> Open the editor</Link>
            </Button>
          </div>
        </div>
      )}

      {/* Link */}
      <section className="mt-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2">
          <ExternalLink className="w-3.5 h-3.5 text-primary" />
          <h2 className="text-[13px] font-medium">Profile link</h2>
        </div>
        <div className="mt-3 flex flex-col sm:flex-row gap-2">
          <Input value={url || "Publish the card to create a link"} readOnly className="h-10 text-[12.5px] font-mono" aria-label="Public profile link" />
          <div className="flex gap-2">
            <Button className="h-10 rounded-lg text-[12px]" onClick={copy} disabled={!live}>
              {copied ? <><Check className="w-3.5 h-3.5 mr-1.5" /> Copied</> : <><Copy className="w-3.5 h-3.5 mr-1.5" /> Copy link</>}
            </Button>
            <Button
              asChild
              variant="outline"
              className="h-10 rounded-lg text-[12px]"
            >
              <a href={card.slug ? `/c/${card.slug}?src=qr` : "#"} target="_blank" rel="noreferrer" aria-disabled={!live}>
                Test link <ExternalLink className="w-3 h-3 ml-1.5" />
              </a>
            </Button>
          </div>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">
          The test link opens exactly what a visitor sees, marked as a QR visit so it shows up correctly in analytics.
        </p>
      </section>

      {/* QR */}
      <section className="mt-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2">
          <QrIcon className="w-3.5 h-3.5 text-primary" />
          <h2 className="text-[13px] font-medium">QR code</h2>
        </div>
        <div className="mt-4 flex flex-col sm:flex-row gap-5">
          <div className="shrink-0 rounded-xl border border-border p-2 bg-white">
            {url ? <QrCode value={url} size={168} /> : <div className="w-[168px] h-[168px] flex items-center justify-center text-[11px] text-muted-foreground text-center px-4">Publish to generate</div>}
          </div>
          <div className="min-w-0">
            <p className="text-[12px] leading-relaxed text-muted-foreground">
              Print it on a card, a badge or a table tent. It always points at this profile, so the design can change without reprinting.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button variant="outline" className="h-9 rounded-lg text-[12px]" onClick={download} disabled={!live}>
                <Download className="w-3.5 h-3.5 mr-1.5" /> Download PNG
              </Button>
              <Button variant="outline" className="h-9 rounded-lg text-[12px]" onClick={() => window.print()} disabled={!live}>
                <Printer className="w-3.5 h-3.5 mr-1.5" /> Print QR card
              </Button>
            </div>
          </div>
        </div>

        {/* Print-ready sheet */}
        <div className="mt-4 rounded-xl border border-dashed border-border p-4">
          <div className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Print preview</div>
          <div className="print-area mt-2 rounded-xl bg-white p-6 flex items-center gap-6">
            <div className="shrink-0">
              {url ? <QrCode value={url} size={132} /> : <div className="w-[132px] h-[132px] bg-secondary rounded-lg" />}
            </div>
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-[0.22em] text-neutral-500">Scan to connect</div>
              <div className="mt-1 text-[19px] font-semibold text-neutral-900 leading-tight">
                {card.headline || card.card_name}
              </div>
              {card.subheadline && <div className="text-[12.5px] text-neutral-600">{card.subheadline}</div>}
              {card.organization && <div className="mt-0.5 text-[11.5px] text-neutral-500">{card.organization}</div>}
              <div className="mt-3 text-[10.5px] font-mono text-neutral-500 break-all">{url}</div>
            </div>
          </div>
        </div>
      </section>

      {/* NFC */}
      <section className="mt-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2">
          <Nfc className="w-3.5 h-3.5 text-primary" />
          <h2 className="text-[13px] font-medium">Set up an NFC card or tag</h2>
        </div>
        <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
          An NFC tag simply stores a URL. Write this card's profile link to the tag once, and any phone that taps it opens your page.
        </p>
        <ol className="mt-3 space-y-2">
          {STEPS.map((step, index) => (
            <li key={step} className="flex gap-2.5 text-[12px] leading-relaxed">
              <span className="mt-0.5 w-5 h-5 rounded-full bg-secondary text-[10.5px] font-medium flex items-center justify-center shrink-0">{index + 1}</span>
              <span className="text-foreground/80">{step}</span>
            </li>
          ))}
        </ol>
        <div className="mt-4 rounded-xl border border-border bg-secondary/40 p-3.5">
          <div className="flex items-start gap-2 text-[11.5px] leading-relaxed text-muted-foreground">
            <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
            <span>
              This app cannot write to a physical tag from the browser — that needs a write-capable NFC app on the phone, plus the tag itself.
              ZetaCard does not sell, ship or pair NFC hardware, and no tag is connected to this card.
            </span>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="outline" className="h-9 rounded-lg text-[12px]" onClick={copy} disabled={!live}>
            <Copy className="w-3.5 h-3.5 mr-1.5" /> Copy link for the writer app
          </Button>
        </div>
      </section>

      {/* Destination */}
      <section className="mt-4 rounded-2xl border border-border bg-card p-5">
        <h2 className="text-[13px] font-medium">Where the tag points</h2>
        <dl className="mt-3 space-y-2 text-[12px]">
          <div className="flex justify-between gap-4">
            <dt className="text-muted-foreground">Address</dt>
            <dd className="font-mono text-[11.5px] truncate">{card.slug ? `/c/${card.slug}` : "Not published yet"}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-muted-foreground">Status</dt>
            <dd className="capitalize">{card.status}</dd>
          </div>
        </dl>
        <p className="mt-3 text-[11.5px] leading-relaxed text-muted-foreground">
          Editing your name, photo or contact details changes the page instantly — every printed QR code and written tag keeps working.
          Only changing the address itself makes old tags point somewhere else, so re-encode them if you rename the link.
        </p>
        <Button asChild variant="outline" size="sm" className="mt-3 h-8 rounded-lg text-[11.5px]">
          <Link to={`/dashboard/cards/${card.id}`}>Edit this card</Link>
        </Button>
      </section>

      <div className="mt-4 flex flex-wrap gap-2">
        <Button asChild variant="ghost" size="sm" className="h-9 rounded-lg text-[12px]">
          <Link to="/dashboard/cards">All my cards</Link>
        </Button>
        <Button asChild variant="ghost" size="sm" className="h-9 rounded-lg text-[12px]">
          <Link to="/dashboard/contacts">Contacts</Link>
        </Button>
      </div>
    </div>
  );
}
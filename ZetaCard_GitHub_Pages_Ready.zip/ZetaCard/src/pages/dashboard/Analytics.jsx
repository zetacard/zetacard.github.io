import React, { useEffect, useMemo, useState } from "react";
import { Eye, Share2, QrCode, Phone, Mail, Globe, CalendarClock, Inbox, Users, UserPlus } from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { base44 } from "@/api/base44Client";

const RANGES = [
  { id: 7, label: "7 days" },
  { id: 30, label: "30 days" },
  { id: 90, label: "90 days" }
];

const TYPES = [
  { key: "view", label: "Views", icon: Eye },
  { key: "share", label: "Shares", icon: Share2 },
  { key: "qr", label: "QR opens", icon: QrCode },
  { key: "contact_phone", label: "Phone taps", icon: Phone },
  { key: "contact_email", label: "Email taps", icon: Mail },
  { key: "website", label: "Website taps", icon: Globe },
  { key: "social", label: "Social taps", icon: Users },
  { key: "booking", label: "Bookings", icon: CalendarClock },
  { key: "enquiry", label: "Enquiries", icon: Inbox },
  { key: "contact", label: "Contacts", icon: UserPlus }
];

export default function Analytics() {
  const [range, setRange] = useState(30);
  const [events, setEvents] = useState(null);
  const [totals, setTotals] = useState({});

  useEffect(() => {
    let active = true;
    const since = new Date(Date.now() - range * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const load = async () => {
      const [page, grouped] = await Promise.all([
        base44.entities.CardEvent.filter({ created_date: { $gte: since } }, { sort: "-created_date", limit: 500 }),
        base44.entities.CardEvent.aggregate({ query: { created_date: { $gte: since } }, groupBy: "type" }).catch(() => ({ rows: [] }))
      ]);
      if (!active) return;
      setEvents(page.items || []);
      const map = {};
      (grouped.rows || []).forEach((row) => {
        map[row.type] = row.count;
      });
      setTotals(map);
    };
    load();
    return () => {
      active = false;
    };
  }, [range]);

  const chart = useMemo(() => {
    if (!events) return [];
    const days = [];
    for (let i = range - 1; i >= 0; i -= 1) {
      const date = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
      days.push({
        date: date.toISOString().slice(0, 10),
        label: date.toLocaleDateString("en-GB", { day: "numeric", month: "short" }),
        count: 0
      });
    }
    const index = Object.fromEntries(days.map((d, i) => [d.date, i]));
    events.forEach((event) => {
      const day = String(event.created_date || "").slice(0, 10);
      if (index[day] !== undefined) days[index[day]].count += 1;
    });
    return days;
  }, [events, range]);

  const total = Object.values(totals).reduce((sum, n) => sum + (Number(n) || 0), 0);

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-5xl mx-auto">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[24px] sm:text-[28px] font-semibold tracking-tight">Analytics</h1>
          <p className="mt-1 text-[13px] text-muted-foreground">Recorded events from your published cards. Nothing here is sampled or estimated.</p>
        </div>
        <div className="flex gap-1">
          {RANGES.map((r) => (
            <button
              key={r.id}
              type="button"
              onClick={() => setRange(r.id)}
              className={`px-3 py-1.5 rounded-full text-[12px] transition-colors ${
                range === r.id ? "bg-foreground text-background" : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {events === null ? (
        <div className="mt-6 space-y-4">
          <div className="h-28 rounded-2xl bg-secondary animate-pulse" />
          <div className="h-64 rounded-2xl bg-secondary animate-pulse" />
        </div>
      ) : (
        <>
          <div className="mt-6 rounded-2xl border border-border bg-card p-5">
            <div className="flex items-baseline justify-between">
              <div>
                <div className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Total interactions</div>
                <div className="mt-2 text-[32px] font-semibold leading-none">{total}</div>
              </div>
              <div className="text-[11.5px] text-muted-foreground">Last {range} days</div>
            </div>
            <div className="mt-6 h-56">
              {total === 0 ? (
                <div className="h-full flex items-center justify-center text-[13px] text-muted-foreground">
                  Nothing recorded in this period yet.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chart} margin={{ top: 4, right: 4, left: -22, bottom: 0 }}>
                    <defs>
                      <linearGradient id="zetaFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.28} />
                        <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      tickLine={false}
                      axisLine={false}
                      interval={Math.max(0, Math.floor(chart.length / 6))}
                    />
                    <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} tickLine={false} axisLine={false} allowDecimals={false} />
                    <Tooltip
                      contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", fontSize: 12 }}
                      labelStyle={{ color: "hsl(var(--muted-foreground))" }}
                    />
                    <Area type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#zetaFill)" name="Events" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
            {TYPES.map(({ key, label, icon: Icon }) => (
              <div key={key} className="rounded-2xl border border-border bg-card p-4">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Icon className="w-3.5 h-3.5" />
                  <span className="text-[11px] uppercase tracking-[0.12em]">{label}</span>
                </div>
                <div className="mt-2 text-[22px] font-semibold leading-none">{totals[key] || 0}</div>
              </div>
            ))}
          </div>

          <p className="mt-4 text-[11.5px] leading-relaxed text-muted-foreground">
            Views are recorded each time a published card page is opened. Shares, QR opens and contact taps are recorded when the visitor uses those actions. No personal data about visitors is stored with these events.
          </p>
        </>
      )}
    </div>
  );
}
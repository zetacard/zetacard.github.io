import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Plus, Eye, CalendarClock, Inbox, IdCard } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import { useAuth } from "@/lib/AuthContext";

function StatCard({ icon: Icon, label, value, hint, to }) {
  return (
    <Link to={to} className="rounded-2xl border border-border bg-card p-5 zeta-lift block">
      <div className="flex items-center justify-between">
        <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-primary">
          <Icon className="w-4 h-4" />
        </div>
        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/60" />
      </div>
      <div className="mt-4 text-[26px] font-semibold leading-none">{value}</div>
      <div className="mt-1.5 text-[12.5px] text-muted-foreground">{label}</div>
      {hint && <div className="mt-2 text-[11.5px] text-muted-foreground/80">{hint}</div>}
    </Link>
  );
}

export default function Overview() {
  const { user } = useAuth();
  const [data, setData] = useState(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      const [total, published, cards, pendingBookings, newEnquiries, views] = await Promise.all([
        base44.entities.Card.count({}),
        base44.entities.Card.count({ status: "published" }),
        base44.entities.Card.filter({}, { sort: "-updated_date", limit: 6 }),
        base44.entities.Booking.count({ status: "pending" }),
        base44.entities.Enquiry.count({ status: "new" }),
        base44.entities.CardEvent.count({ type: "view" })
      ]);
      if (!active) return;
      setData({
        cards: cards.items || [],
        total,
        published,
        pendingBookings,
        newEnquiries,
        views
      });
    };
    load();
    return () => {
      active = false;
    };
  }, []);

  if (!data) {
    return (
      <div className="p-6 lg:p-10 max-w-6xl mx-auto">
        <div className="h-8 w-52 rounded-lg bg-secondary animate-pulse" />
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[...Array(4)].map((_, i) => <div key={i} className="h-32 rounded-2xl bg-secondary animate-pulse" />)}
        </div>
      </div>
    );
  }

  const firstName = (user?.full_name || "").split(" ")[0];

  return (
    <div className="p-5 sm:p-8 lg:p-10 max-w-6xl mx-auto">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Dashboard</div>
          <h1 className="mt-2 text-[26px] sm:text-[30px] font-semibold tracking-tight">
            {firstName ? `Good to see you, ${firstName}` : "Your dashboard"}
          </h1>
        </div>
        <Button asChild className="rounded-full h-10 px-4 text-[13px]">
          <Link to="/dashboard/new"><Plus className="w-3.5 h-3.5 mr-1.5" /> New card</Link>
        </Button>
      </div>

      <div className="mt-7 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard icon={IdCard} label="Cards" value={data.total} hint={`${data.published} published`} to="/dashboard/cards" />
        <StatCard icon={Eye} label="Card views" value={data.views} hint="All time" to="/dashboard/analytics" />
        <StatCard icon={Inbox} label="New enquiries" value={data.newEnquiries} hint="Awaiting your reply" to="/dashboard/enquiries" />
        <StatCard icon={CalendarClock} label="Pending bookings" value={data.pendingBookings} hint="Need confirmation" to="/dashboard/bookings" />
      </div>

      <div className="mt-10 flex items-center justify-between">
        <h2 className="text-[15px] font-medium">Recent cards</h2>
        <Link to="/dashboard/cards" className="text-[12.5px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
          See all <ArrowRight className="w-3 h-3" />
        </Link>
      </div>

      {data.cards.length === 0 ? (
        <div className="mt-4 rounded-2xl border border-dashed border-border bg-card p-10 text-center">
          <div className="mx-auto w-11 h-11 rounded-xl bg-secondary flex items-center justify-center text-primary">
            <IdCard className="w-5 h-5" />
          </div>
          <div className="mt-4 text-[15px] font-medium">No cards yet</div>
          <p className="mt-1.5 text-[13px] text-muted-foreground max-w-sm mx-auto">
            Choose a category, pick a design and publish your first card. It takes about six minutes.
          </p>
          <Button asChild className="mt-5 rounded-full h-10 px-5 text-[13px]">
            <Link to="/dashboard/new">Create your first card</Link>
          </Button>
        </div>
      ) : (
        <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.cards.map((card) => (
            <Link
              key={card.id}
              to={`/dashboard/cards/${card.id}`}
              className="group rounded-2xl border border-border bg-card p-3 zeta-lift"
            >
              <div className="rounded-xl overflow-hidden border border-border">
                <ScaledCanvas card={card} radius={0} />
              </div>
              <div className="mt-3 flex items-center justify-between gap-2 px-1 pb-1">
                <div className="min-w-0">
                  <div className="text-[13px] font-medium truncate">{card.card_name}</div>
                  <div className="text-[11px] text-muted-foreground capitalize">{card.status}</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>
          ))}
        </div>
      )}

      <div className="mt-10 rounded-2xl border border-border bg-card p-6">
        <h2 className="text-[14px] font-medium">Getting the most out of a card</h2>
        <div className="mt-4 grid sm:grid-cols-3 gap-4">
          {[
            { t: "Publish, then share", d: "A published card gets a link and a QR code. Drafts are private." },
            { t: "Turn on enquiries", d: "Visitors can message you from the card, and it lands in Enquiries." },
            { t: "Watch the analytics", d: "Views and taps tell you whether the card is being opened." }
          ].map((item) => (
            <div key={item.t}>
              <div className="text-[12.5px] font-medium">{item.t}</div>
              <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{item.d}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
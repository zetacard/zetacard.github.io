import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Users, Search, Download, Trash2, Loader2, Tag, Plus, X, Check, Archive, ChevronDown, ContactRound
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { buildVCard, downloadBlob, downloadVCard } from "@/lib/cardUtils";

const TABS = [
  { id: "all", label: "All" },
  { id: "new", label: "New" },
  { id: "saved", label: "Saved" },
  { id: "archived", label: "Archived" }
];

function csvCell(value) {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

export default function Contacts() {
  const { toast } = useToast();
  const [rows, setRows] = useState([]);
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("all");
  const [cardFilter, setCardFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState(null);
  const [tagDraft, setTagDraft] = useState("");
  const [notesDraft, setNotesDraft] = useState("");
  const [pendingDelete, setPendingDelete] = useState(null);

  useEffect(() => {
    base44.entities.Card.filter({}, { sort: "-created_date", limit: 50 })
      .then((page) => setCards(page.items || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    const filter = {};
    if (tab !== "all") filter.status = tab;
    if (cardFilter !== "all") filter.card_id = cardFilter;
    base44.entities.Contact.filter(filter, { sort: "-created_date", limit: 100 })
      .then((page) => {
        if (active) setRows(page.items || []);
      })
      .catch(() => {
        if (!active) return;
        setRows([]);
        toast({ title: "Could not load contacts", description: "Refresh and try again.", variant: "destructive" });
      })
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [tab, cardFilter]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter((row) =>
      [row.name, row.email, row.phone, row.organization, row.role, (row.tags || []).join(" ")]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(needle))
    );
  }, [rows, query]);

  const patch = async (row, data, message) => {
    try {
      await base44.entities.Contact.update(row.id, data);
      setRows((prev) => prev.map((item) => (item.id === row.id ? { ...item, ...data } : item)));
      if (message) toast({ title: message });
    } catch {
      toast({ title: "That change did not save", variant: "destructive" });
    }
  };

  const remove = async () => {
    if (!pendingDelete) return;
    try {
      await base44.entities.Contact.delete(pendingDelete.id);
      setRows((prev) => prev.filter((item) => item.id !== pendingDelete.id));
      toast({ title: "Contact deleted" });
    } catch {
      toast({ title: "Could not delete this contact", variant: "destructive" });
    } finally {
      setPendingDelete(null);
    }
  };

  const addTag = async (row) => {
    const tag = tagDraft.trim().slice(0, 24);
    if (!tag) return;
    const tags = Array.from(new Set([...(row.tags || []), tag]));
    setTagDraft("");
    await patch(row, { tags }, "Tag added");
  };

  const removeTag = async (row, tag) => {
    await patch(row, { tags: (row.tags || []).filter((item) => item !== tag) });
  };

  const exportCsv = () => {
    if (!filtered.length) {
      toast({ title: "Nothing to export yet", description: "Contacts collected from your cards appear here." });
      return;
    }
    const header = ["Name", "Email", "Phone", "Company", "Role", "Tags", "Card", "Source", "Status", "Their note", "Your notes", "Received"];
    const lines = filtered.map((row) =>
      [
        row.name, row.email, row.phone, row.organization, row.role,
        (row.tags || []).join(" | "), row.card_name, row.source, row.status,
        row.note, row.owner_notes,
        row.created_date ? new Date(row.created_date).toISOString().slice(0, 10) : ""
      ].map(csvCell).join(",")
    );
    downloadBlob(new Blob([[header.map(csvCell).join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" }), "zetacard-contacts.csv");
    toast({ title: "CSV downloaded", description: `${filtered.length} contact${filtered.length === 1 ? "" : "s"} exported.` });
  };

  const openRow = (row) => {
    if (expanded === row.id) {
      setExpanded(null);
      return;
    }
    setExpanded(row.id);
    setNotesDraft(row.owner_notes || "");
    setTagDraft("");
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-[1100px] mx-auto">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-semibold tracking-tight">Contacts</h1>
          <p className="mt-1 text-[12.5px] text-muted-foreground">
            People who shared their details through your cards. Only you can see them.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-9 rounded-lg text-[12px]" onClick={exportCsv}>
            <Download className="w-3.5 h-3.5 mr-1.5" /> Export CSV
          </Button>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        <div className="flex gap-1 rounded-lg bg-secondary p-1">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`px-3 py-1.5 rounded-md text-[12px] transition-colors ${tab === item.id ? "bg-card shadow-sm font-medium" : "text-muted-foreground hover:text-foreground"}`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <select
          value={cardFilter}
          onChange={(event) => setCardFilter(event.target.value)}
          className="h-9 rounded-lg border border-input bg-background px-2.5 text-[12px] max-w-[220px]"
          aria-label="Filter by card"
        >
          <option value="all">All cards</option>
          {cards.map((card) => (
            <option key={card.id} value={card.id}>{card.card_name || "Untitled card"}</option>
          ))}
        </select>
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search name, email, company or tag"
            className="h-9 pl-8 text-[12.5px] rounded-lg"
            aria-label="Search contacts"
          />
        </div>
      </div>

      {loading ? (
        <div className="mt-10 flex items-center justify-center text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-border bg-card p-10 text-center">
          <div className="mx-auto w-11 h-11 rounded-2xl bg-secondary flex items-center justify-center text-primary">
            <Users className="w-5 h-5" />
          </div>
          <div className="mt-4 text-[14px] font-medium">
            {rows.length === 0 ? "No contacts yet" : "Nothing matches that search"}
          </div>
          <p className="mt-1.5 text-[12.5px] text-muted-foreground max-w-sm mx-auto leading-relaxed">
            {rows.length === 0
              ? "When someone shares their details on one of your published cards, they land here with the card that brought them."
              : "Try a different name, email or tag."}
          </p>
          {rows.length === 0 && (
            <Button asChild variant="outline" size="sm" className="mt-4 h-9 rounded-lg text-[12px]">
              <Link to="/dashboard/cards">Go to my cards</Link>
            </Button>
          )}
        </div>
      ) : (
        <div className="mt-4 space-y-2">
          <p className="text-[11px] text-muted-foreground px-1">
            {filtered.length} contact{filtered.length === 1 ? "" : "s"}{rows.length > filtered.length ? ` of ${rows.length} loaded` : ""}
          </p>
          {filtered.map((row) => (
            <div key={row.id} className="rounded-2xl border border-border bg-card">
              <div className="flex items-start gap-3 p-4">
                <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center text-[12px] font-medium shrink-0">
                  {(row.name || "?").trim().charAt(0).toUpperCase()}
                </div>
                <button type="button" onClick={() => openRow(row)} className="flex-1 min-w-0 text-left">
                  <div className="flex items-center gap-2">
                    <span className="text-[13.5px] font-medium truncate">{row.name}</span>
                    {row.status === "new" && <span className="text-[10px] uppercase tracking-[0.12em] text-primary">New</span>}
                    {row.status === "archived" && <span className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Archived</span>}
                  </div>
                  <div className="mt-0.5 text-[11.5px] text-muted-foreground truncate">
                    {[row.role, row.organization].filter(Boolean).join(" · ") || row.email}
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                    {row.email && <span className="truncate max-w-[220px]">{row.email}</span>}
                    {row.phone && <span>{row.phone}</span>}
                    {row.card_name && <span className="truncate max-w-[180px]">via {row.card_name}</span>}
                    {row.source === "qr" && <span>QR</span>}
                  </div>
                  {(row.tags || []).length > 0 && (
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {row.tags.map((tag) => (
                        <span key={tag} className="rounded-full bg-secondary px-2 py-0.5 text-[10.5px]">{tag}</span>
                      ))}
                    </div>
                  )}
                </button>
                <div className="flex items-center gap-1 shrink-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 rounded-lg"
                    aria-label="Download as vCard"
                    onClick={() => downloadVCard({
                      headline: row.name,
                      subheadline: row.role,
                      organization: row.organization,
                      phone: row.phone,
                      email: row.email,
                      about: row.note
                    })}
                  >
                    <ContactRound className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 rounded-lg"
                    aria-label="Delete contact"
                    onClick={() => setPendingDelete(row)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-lg" aria-label="Open contact" onClick={() => openRow(row)}>
                    <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expanded === row.id ? "rotate-180" : ""}`} />
                  </Button>
                </div>
              </div>

              {expanded === row.id && (
                <div className="border-t border-border p-4 space-y-3">
                  {row.note && (
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Their note</div>
                      <p className="mt-1 text-[12.5px] leading-relaxed text-foreground/80 whitespace-pre-line">{row.note}</p>
                    </div>
                  )}

                  <div>
                    <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Your notes</div>
                    <textarea
                      value={notesDraft}
                      onChange={(event) => setNotesDraft(event.target.value)}
                      onBlur={() => {
                        if ((row.owner_notes || "") !== notesDraft.trim()) patch(row, { owner_notes: notesDraft.trim() }, "Note saved");
                      }}
                      rows={3}
                      placeholder="Private — only visible to you."
                      className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2 text-[12.5px]"
                    />
                  </div>

                  <div>
                    <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Tags</div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      {(row.tags || []).map((tag) => (
                        <span key={tag} className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[11px]">
                          {tag}
                          <button type="button" onClick={() => removeTag(row, tag)} aria-label={`Remove ${tag}`} className="text-muted-foreground hover:text-foreground">
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                      <div className="flex items-center gap-1">
                        <Input
                          value={tagDraft}
                          onChange={(event) => setTagDraft(event.target.value)}
                          onKeyDown={(event) => {
                            if (event.key === "Enter") {
                              event.preventDefault();
                              addTag(row);
                            }
                          }}
                          placeholder="Add tag"
                          className="h-7 w-[110px] text-[11.5px] rounded-lg"
                        />
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0 rounded-lg" onClick={() => addTag(row)} aria-label="Add tag">
                          <Plus className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    {row.status !== "saved" && (
                      <Button variant="outline" size="sm" className="h-8 rounded-lg text-[11.5px]" onClick={() => patch(row, { status: "saved" }, "Marked as saved")}>
                        <Check className="w-3.5 h-3.5 mr-1.5" /> Mark saved
                      </Button>
                    )}
                    {row.status !== "archived" ? (
                      <Button variant="outline" size="sm" className="h-8 rounded-lg text-[11.5px]" onClick={() => patch(row, { status: "archived" }, "Archived")}>
                        <Archive className="w-3.5 h-3.5 mr-1.5" /> Archive
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm" className="h-8 rounded-lg text-[11.5px]" onClick={() => patch(row, { status: "saved" }, "Restored")}>
                        <Tag className="w-3.5 h-3.5 mr-1.5" /> Restore
                      </Button>
                    )}
                    {row.email && (
                      <Button asChild variant="outline" size="sm" className="h-8 rounded-lg text-[11.5px]">
                        <a href={`mailto:${row.email}`}>Email {row.name.split(" ")[0]}</a>
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={Boolean(pendingDelete)} onOpenChange={(open) => !open && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this contact?</AlertDialogTitle>
            <AlertDialogDescription>
              {pendingDelete?.name}'s details and your private notes will be removed permanently. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep contact</AlertDialogCancel>
            <AlertDialogAction onClick={remove}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
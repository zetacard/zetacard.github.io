import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import Section from "@/components/site/Section";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import CategoryIcon from "@/components/site/CategoryIcon";
import { Button } from "@/components/ui/button";
import { CATEGORIES, templatesFor } from "@/lib/templates";
import { demoCard } from "@/lib/demoCards";

const FIELD_LABELS = {
  headline: "Name / title",
  subheadline: "Role, price or tagline",
  organization: "Business name",
  about: "Description",
  phone: "Phone",
  email: "Email",
  website: "Website",
  address: "Address / map link",
  map_url: "Map link",
  socials: "Social links",
  items: "Items, courses or services",
  details: "Details and specifications",
  event_date: "Date",
  event_time: "Time",
  venue: "Venue",
  portrait_url: "Portrait",
  cover_url: "Cover image"
};

export default function Categories() {
  return (
    <div>
      <Section
        eyebrow="Card categories"
        title="Pick the shape of what you are making"
        description="Each category changes the fields, the layouts and what a visitor can do on the published page — book a slot, send an enquiry, save your contact or open directions."
        className="pt-16 pb-16 sm:pt-24"
      />

      <div className="mx-auto max-w-7xl px-5 sm:px-8 pb-24 space-y-6">
        {CATEGORIES.map((category, index) => {
          const templates = templatesFor(category.id);
          const preview = demoCard(category.id, index + 2);
          return (
            <div key={category.id} className="rounded-3xl border border-border bg-card overflow-hidden">
              <div className={`grid lg:grid-cols-[1.15fr_0.85fr] ${index % 2 ? "lg:[&>*:first-child]:order-2" : ""}`}>
                <div className="p-7 sm:p-10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-primary">
                      <CategoryIcon category={category.id} className="w-5 h-5" />
                    </div>
                    <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                      {templates.length} designs
                    </div>
                  </div>
                  <h2 className="mt-6 text-[24px] sm:text-[28px] font-semibold leading-snug">{category.headline}</h2>
                  <p className="mt-3 text-[14px] leading-relaxed text-muted-foreground max-w-xl">{category.description}</p>

                  <div className="mt-6 flex flex-wrap gap-1.5">
                    {category.fields.map((field) => (
                      <span
                        key={field}
                        className="text-[11px] px-2.5 py-1 rounded-full border border-border text-muted-foreground bg-secondary/60"
                      >
                        {FIELD_LABELS[field] || field}
                      </span>
                    ))}
                  </div>

                  <div className="mt-7 flex flex-wrap items-center gap-4">
                    <Button asChild className="rounded-full h-10 px-4 text-[13px]">
                      <Link to={`/dashboard/new?category=${category.id}`}>
                        Start a {category.short.toLowerCase()} card <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                      </Link>
                    </Button>
                    <Link
                      to={`/templates?category=${category.id}`}
                      className="text-[13px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                    >
                      See its {templates.length} designs <ArrowUpRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
                <div className="bg-secondary/50 p-6 sm:p-8 flex items-center justify-center">
                  <div className="w-full max-w-[330px] rounded-2xl overflow-hidden border border-border shadow-xl">
                    <ScaledCanvas card={preview} radius={0} />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
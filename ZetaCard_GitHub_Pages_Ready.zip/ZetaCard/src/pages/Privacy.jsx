import React from "react";
import Section from "@/components/site/Section";

const BLOCKS = [
  {
    title: "1. What this policy covers",
    body: "This policy explains what ZetaCard collects when you browse the site, create an account, build a card, or interact with someone else's published card. It describes what is stored in the app's database, who can see it, and how to have it removed."
  },
  {
    title: "2. Information you give us",
    body: "Account: your email address and name, handled by the platform's authentication service. Card content: whatever you type into a card — names, phone numbers, email addresses, prices, addresses, dates, images. Enquiries and bookings you send through someone else's card: your name, email, optional phone number and message."
  },
  {
    title: "3. What is public",
    body: "Only fields on a published card are public. A published card can be opened by anyone with its link or QR code. Drafts and archived cards are not publicly readable. Your login email is public only if you type it into a card field yourself. Enquiries, bookings, notes and analytics are never shown on a public page."
  },
  {
    title: "4. Analytics",
    body: "When someone opens a published card, the app records an event: a view, a share, a QR open, a contact tap, a website click, a booking or an enquiry. Events store the card they belong to and the card owner, not the visitor's identity. They exist so the owner can see whether a card is being used. There are no third-party advertising trackers in this app."
  },
  {
    title: "5. Who can see your records",
    body: "Cards, enquiries, bookings and analytics are restricted to the account that created them, enforced on the server for every read and write. The app's administrators can access records to operate and support the service. Other users of ZetaCard cannot see your records, including by changing an address."
  },
  {
    title: "6. Cookies and storage",
    body: "The app stores a session token in your browser so you stay signed in. It does not set advertising cookies. Your card editor keeps unsaved form state in the page only; nothing leaves the browser until you save."
  },
  {
    title: "7. Email",
    body: "If the operator connects an email provider, booking confirmations are sent to the visitor's email address. Until then no email is sent and the dashboard states that. Email delivery is reported separately from the saved record, so a failed email never changes a booking's status."
  },
  {
    title: "8. Retention and deletion",
    body: "Your records remain while your account exists. Account settings can delete your cards, enquiries, bookings and analytics events from the app; this cannot be undone. You can also unpublish a card to remove its public page without deleting the record."
  },
  {
    title: "9. Your choices",
    body: "You can edit or remove any detail on a card at any time, unpublish it, or delete it. Visitors who submitted an enquiry or booking can ask the card owner to remove it using the contact details on that card."
  },
  {
    title: "10. Changes and contact",
    body: "If this policy changes materially, the updated version will be published on this page with a new date. Questions about data can be sent through the contact page."
  }
];

export default function Privacy() {
  return (
    <Section eyebrow="Legal" title="Privacy policy" className="pt-16 pb-20 sm:pt-24">
      <div className="max-w-3xl">
        <p className="text-[12.5px] text-muted-foreground">Last updated 29 October 2026</p>
        <div className="mt-8 space-y-8">
          {BLOCKS.map((block) => (
            <div key={block.title}>
              <h2 className="text-[15px] font-medium">{block.title}</h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">{block.body}</p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Check, ShieldCheck, Layers, Smartphone, Download, BarChart3, CalendarClock, Inbox, Palette } from "lucide-react";
import { Button } from "@/components/ui/button";
import Section from "@/components/site/Section";

const GROUPS = [
  {
    icon: Palette,
    title: "Studio",
    items: [
      "160 templates — 20 distinct layouts in each of 8 categories",
      "Live preview that updates as you type",
      "Autosaving drafts with a visible save status",
      "Category-specific fields, not one giant form",
      "Switch template or palette without losing content",
      "Logo, portrait and cover image upload with validation"
    ]
  },
  {
    icon: Layers,
    title: "Publishing",
    items: [
      "One stable public link per card",
      "Downloadable QR code for print",
      "Publish, unpublish and archive at any time",
      "Drafts that never leak to a public URL",
      "Duplicate a card as the starting point for another"
    ]
  },
  {
    icon: Smartphone,
    title: "On the phone",
    items: [
      "Mobile-first public pages",
      "Click-to-call, email and map links",
      "Save-to-contacts (.vcf) download",
      "Native share sheet where supported, copy link everywhere else",
      "Print styles that keep proportions"
    ]
  },
  {
    icon: Download,
    title: "Exports",
    items: ["PNG export at 2× resolution", "PDF export at the card's own proportions", "Print-friendly layouts", "QR download for packaging and signage"]
  },
  {
    icon: Inbox,
    title: "Leads and enquiries",
    items: [
      "Enquiry form on any published card",
      "Owner-only lead inbox with status and notes",
      "Server-side validation and duplicate protection",
      "Visitors can never read each other's messages"
    ]
  },
  {
    icon: CalendarClock,
    title: "Bookings",
    items: [
      "Configurable days, hours and slot length",
      "Real availability — no double booking",
      "Pending, confirmed, cancelled and completed states",
      "Email notification when an owner connects a provider"
    ]
  },
  {
    icon: BarChart3,
    title: "Analytics",
    items: ["Views, shares and QR opens", "Contact and website taps", "Booking and enquiry counts", "Date-range filters, no invented numbers"]
  },
  {
    icon: ShieldCheck,
    title: "Privacy and access",
    items: [
      "Row-level rules: your records are yours",
      "Public visitors only see published cards",
      "Private data never appears in a public URL",
      "Delete your data from account settings"
    ]
  }
];

export default function Features() {
  return (
    <div>
      <section className="relative overflow-hidden zeta-ink">
        <div className="absolute inset-0 zeta-aurora opacity-80" />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 py-20 sm:py-28">
          <div className="max-w-3xl">
            <div className="text-[11px] uppercase tracking-[0.2em] text-white/45">Features</div>
            <h1 className="mt-4 text-[36px] sm:text-[52px] leading-[1.05] font-semibold tracking-[-0.03em] text-white text-balance">
              A studio, a share link and a small business inbox.
            </h1>
            <p className="mt-5 text-[15px] leading-relaxed text-white/55 max-w-xl">
              Everything below is part of the product — not a roadmap slide. Anything that needs setup on your side is marked as such.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button asChild size="lg" className="rounded-full h-12 px-6 bg-white text-[#0B1020] hover:bg-white/90">
                <Link to="/dashboard">Create a card <ArrowRight className="w-4 h-4 ml-1.5" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full h-12 px-6 border-white/20 bg-transparent text-white hover:bg-white/10 hover:text-white">
                <Link to="/templates">See the designs</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Section className="py-20 sm:py-24">
        <div className="grid md:grid-cols-2 gap-4">
          {GROUPS.map(({ icon: Icon, title, items }) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-7">
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-primary">
                <Icon className="w-4 h-4" />
              </div>
              <h3 className="mt-5 text-[17px] font-medium">{title}</h3>
              <ul className="mt-4 space-y-2.5">
                {items.map((item) => (
                  <li key={item} className="flex gap-2.5 text-[13px] leading-relaxed text-muted-foreground">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0 mt-1" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      <div className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14">
          <h2 className="text-[20px] font-medium">What is not included yet</h2>
          <p className="mt-2 text-[13.5px] text-muted-foreground max-w-2xl">
            We would rather be exact than impressive. These are not built in this version:
          </p>
          <ul className="mt-6 grid sm:grid-cols-2 gap-2.5 text-[13px] text-muted-foreground max-w-3xl">
            {[
              "Paid plans, checkout or subscriptions — everything here is free",
              "Team workspaces with multiple editors on one card",
              "Custom domain per card (cards live on this app's domain)",
              "Automatic calendar invites (.ics) for bookings",
              "SMS or WhatsApp notifications",
              "Scanning paper cards into contacts"
            ].map((item) => (
              <li key={item} className="flex gap-2">
                <span className="text-muted-foreground/50">—</span> {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import TemplateTile from "@/components/card/TemplateTile";
import { CATEGORIES, TEMPLATES, templatesFor } from "@/lib/templates";
import { demoCard } from "@/lib/demoCards";
import { Button } from "@/components/ui/button";

export default function Templates() {
  const [params, setParams] = useSearchParams();
  const initial = params.get("category");
  const [active, setActive] = useState(initial && CATEGORIES.some((c) => c.id === initial) ? initial : CATEGORIES[0].id);

  useEffect(() => {
    const fromUrl = params.get("category");
    if (fromUrl && CATEGORIES.some((c) => c.id === fromUrl)) setActive(fromUrl);
  }, [params]);

  const category = CATEGORIES.find((c) => c.id === active);
  const list = useMemo(() => templatesFor(active), [active]);

  const choose = (id) => {
    setActive(id);
    setParams({ category: id }, { replace: true });
  };

  return (
    <div>
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14 sm:py-20">
          <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Template gallery</div>
          <h1 className="mt-4 text-[32px] sm:text-[44px] leading-[1.08] font-semibold tracking-[-0.03em] text-balance">
            {TEMPLATES.length} designs. Every one of them usable.
          </h1>
          <p className="mt-4 max-w-2xl text-[14.5px] leading-relaxed text-muted-foreground">
            Twenty layouts per category, each with its own composition, type pairing and palette. What you see here is the actual renderer used on your published card — not a screenshot.
          </p>
        </div>
      </div>

      <div className="sticky top-16 z-30 bg-background/90 backdrop-blur-xl border-b border-border">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="flex gap-1 overflow-x-auto no-scrollbar py-3">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => choose(cat.id)}
                className={`whitespace-nowrap px-3.5 py-2 rounded-full text-[12.5px] transition-colors ${
                  active === cat.id
                    ? "bg-foreground text-background"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-12 sm:py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-[20px] font-medium">{category.headline}</h2>
            <p className="mt-1 text-[13px] text-muted-foreground">{category.tagline}</p>
          </div>
          <Button asChild size="sm" className="rounded-full h-9 px-4 text-[12.5px]">
            <Link to={`/dashboard/new?category=${category.id}`}>
              Start with this category <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
            </Link>
          </Button>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-9">
          {list.map((template, i) => {
            const card = demoCard(active, i);
            return (
              <TemplateTile
                key={template.id}
                card={{ ...card, template_id: template.id }}
                categoryName={template.name}
                href={`/dashboard/new?category=${active}&template=${template.id}`}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
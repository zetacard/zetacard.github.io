import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowUpRight, Check, ShieldCheck, Sparkles, Link2, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Section from "@/components/site/Section";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import TemplateTile from "@/components/card/TemplateTile";
import { CATEGORIES } from "@/lib/templates";
import { HERO_CARDS, SHOWCASE, demoCard } from "@/lib/demoCards";
import CategoryIcon from "@/components/site/CategoryIcon";
import QrCodeMini from "@/components/site/QrCodeMini";

const STEPS = [
  { n: "01", title: "Pick a category", body: "Visiting card, wedding invitation, menu, listing, event — each has fields that actually fit." },
  { n: "02", title: "Choose a design", body: "Twenty distinct layouts per category, from formal to editorial. Switch designs any time without retyping." },
  { n: "03", title: "Fill in your details", body: "A live preview updates as you type. Your draft autosaves while you work." },
  { n: "04", title: "Publish and share", body: "One stable link, a QR code, and a page that saves straight to someone's contacts." }
];

const FAQ = [
  {
    q: "Is it really free?",
    a: "Creating, editing, publishing and sharing a card is free, and there is no checkout in this version. Future premium features will be optional and clearly marked."
  },
  {
    q: "Can I edit a card after printing or sharing it?",
    a: "Yes. Your public link always shows the current saved version, so an address or price change reaches everyone who already has the link."
  },
  {
    q: "What happens to my details?",
    a: "Only what you put on a published card is public. Your drafts, enquiries, bookings and analytics are visible to your account only."
  },
  {
    q: "Do visitors need an account to view my card?",
    a: "No. Anyone with the link can open a published card on any device. Booking a slot or sending an enquiry only needs their name and contact details."
  },
  {
    q: "Can I print the card?",
    a: "Yes. Designed cards export to PNG and PDF, and print at the right proportions for the category."
  },
  {
    q: "How do booking emails work?",
    a: "Bookings are always saved in your dashboard. Email notifications need the app owner to connect an email provider — until then, the dashboard shows the saved request and notes that no email was sent."
  }
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden zeta-ink">
        <div className="absolute inset-0 zeta-aurora" />
        <div className="absolute inset-0 zeta-grid-lines opacity-60" />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 pt-16 pb-20 sm:pt-24 sm:pb-28">
          <div className="grid lg:grid-cols-[1.05fr_1fr] gap-14 items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-3 py-1.5 text-[11.5px] text-white/70 backdrop-blur">
                <Sparkles className="w-3.5 h-3.5 text-[#9BE7F0]" />
                Digital cards, designed properly
              </div>
              <h1 className="mt-6 text-[40px] leading-[1.03] sm:text-[62px] font-semibold tracking-[-0.03em] text-white text-balance">
                Your card,
                <br />
                <span className="text-white/45">always up to date.</span>
              </h1>
              <p className="mt-6 max-w-lg text-[15.5px] leading-relaxed text-white/60">
                ZetaCard turns a name, a menu, an invitation or a listing into a beautiful page you can share
                with a link or QR code — and update for free, forever.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Button asChild size="lg" className="rounded-full h-12 px-6 bg-white text-[#0B1020] hover:bg-white/90">
                  <Link to="/dashboard">
                    Create your card <ArrowRight className="w-4 h-4 ml-1.5" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="rounded-full h-12 px-6 border-white/20 bg-transparent text-white hover:bg-white/10 hover:text-white"
                >
                  <Link to="/templates">Browse 160 designs</Link>
                </Button>
              </div>
              <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-[12px] text-white/45">
                <span className="inline-flex items-center gap-1.5"><Check className="w-3.5 h-3.5" /> Free to start</span>
                <span className="inline-flex items-center gap-1.5"><Check className="w-3.5 h-3.5" /> No card details</span>
                <span className="inline-flex items-center gap-1.5"><Check className="w-3.5 h-3.5" /> Mobile-ready pages</span>
              </div>
            </div>

            <div className="relative">
              <div className="grid grid-cols-2 gap-4 sm:gap-5">
                <div className="col-span-2 sm:col-span-1 sm:mt-10">
                  <div className="rounded-2xl overflow-hidden ring-1 ring-white/10 shadow-[0_30px_80px_-40px_rgba(0,0,0,0.9)]">
                    <ScaledCanvas card={HERO_CARDS[0]} radius={16} />
                  </div>
                </div>
                <div className="space-y-4 sm:space-y-5">
                  <div className="rounded-2xl overflow-hidden ring-1 ring-white/10 shadow-[0_30px_80px_-40px_rgba(0,0,0,0.9)]">
                    <ScaledCanvas card={HERO_CARDS[1]} radius={16} />
                  </div>
                  <div className="rounded-2xl overflow-hidden ring-1 ring-white/10 shadow-[0_30px_80px_-40px_rgba(0,0,0,0.9)] hidden sm:block">
                    <ScaledCanvas card={HERO_CARDS[2]} radius={16} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <Section
        eyebrow="Eight categories"
        title="Not one template stretched across everything"
        description="Each category has its own fields, layouts and actions — a menu needs courses and prices, a listing needs area and viewing requests."
        className="py-20 sm:py-24"
      >
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {CATEGORIES.map((category) => (
            <Link
              key={category.id}
              to={`/dashboard/new?category=${category.id}`}
              className="group relative rounded-2xl border border-border bg-card p-5 zeta-lift"
            >
              <div className="w-9 h-9 rounded-xl bg-secondary flex items-center justify-center text-primary">
                <CategoryIcon category={category.id} className="w-4 h-4" />
              </div>
              <div className="mt-5 text-[14px] font-medium">{category.name}</div>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground line-clamp-2">{category.tagline}</p>
              <ArrowUpRight className="absolute top-5 right-4 w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
          ))}
        </div>
      </Section>

      {/* Templates */}
      <div className="bg-secondary/40 border-y border-border">
        <Section
          eyebrow="Template gallery"
          title="Twenty distinct designs per category"
          description="Different grids, different typography, different levels of formality. Switch designs without losing a single detail you typed."
          className="py-20 sm:py-24"
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-5 gap-y-9">
            {SHOWCASE.map((card) => (
              <TemplateTile
                key={card.id}
                card={card}
                categoryName={CATEGORIES.find((c) => c.id === card.category)?.name}
                href={`/dashboard/new?category=${card.category}&template=${card.template_id}`}
              />
            ))}
          </div>
          <div className="mt-12">
            <Button asChild variant="outline" className="rounded-full h-11 px-5">
              <Link to="/templates">Open the full gallery <ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </Section>
      </div>

      {/* How it works */}
      <Section eyebrow="How it works" title="Four steps, no design skills" className="py-20 sm:py-24">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {STEPS.map((step) => (
            <div key={step.n} className="rounded-2xl border border-border bg-card p-6">
              <div className="font-mono text-[11px] tracking-[0.2em] text-primary">{step.n}</div>
              <div className="mt-6 text-[15px] font-medium">{step.title}</div>
              <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{step.body}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Benefits */}
      <div className="bg-secondary/40 border-y border-border">
        <Section className="py-20 sm:py-24">
          <div className="grid lg:grid-cols-2 gap-4">
            <div className="rounded-3xl bg-card border border-border p-8 sm:p-10">
              <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">For individuals</div>
              <h3 className="mt-4 text-[24px] font-semibold leading-snug">One link instead of spelling out your number</h3>
              <ul className="mt-6 space-y-3 text-[13.5px] text-muted-foreground">
                {["Save-to-contacts button that works on iPhone and Android", "Click-to-call, email and map links", "A QR code for the back of a slide or a shop counter", "Update a job title without reprinting anything"].map((item) => (
                  <li key={item} className="flex gap-2.5">
                    <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-3xl bg-card border border-border p-8 sm:p-10">
              <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">For businesses</div>
              <h3 className="mt-4 text-[24px] font-semibold leading-snug">Menus, catalogues and listings that stay current</h3>
              <ul className="mt-6 space-y-3 text-[13.5px] text-muted-foreground">
                {["Change a price in the evening, before service", "Collect enquiries and leads in one inbox", "Take appointment requests with real availability", "See which cards people actually open and act on"].map((item) => (
                  <li key={item} className="flex gap-2.5">
                    <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Section>
      </div>

      {/* Sharing + privacy */}
      <Section className="py-20 sm:py-24">
        <div className="rounded-3xl zeta-ink relative overflow-hidden">
          <div className="absolute inset-0 zeta-aurora opacity-70" />
          <div className="relative grid lg:grid-cols-[1.2fr_0.8fr] gap-10 p-8 sm:p-12 items-center">
            <div>
              <div className="text-[11px] uppercase tracking-[0.2em] text-white/45">Sharing and privacy</div>
              <h2 className="mt-4 text-[26px] sm:text-[34px] leading-tight font-semibold text-white text-balance">
                You decide what is public. Everything else stays yours.
              </h2>
              <p className="mt-4 text-[14px] leading-relaxed text-white/55 max-w-lg">
                A published card shows only the details on the card. Drafts, unpublished cards, enquiries, bookings and analytics are visible only to your account. Unpublish any time and the link stops working immediately.
              </p>
              <div className="mt-8 grid sm:grid-cols-2 gap-3">
                {[
                  { icon: Link2, title: "Stable public link", body: "ZetaCard.com/c/your-name" },
                  { icon: QrCode, title: "Downloadable QR", body: "Print it or put it on a slide" },
                  { icon: ShieldCheck, title: "Owner-only dashboard", body: "Nobody else can open your records" },
                  { icon: Sparkles, title: "Unpublish instantly", body: "No link, no access" }
                ].map(({ icon: Icon, title, body }) => (
                  <div key={title} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                    <Icon className="w-4 h-4 text-[#9BE7F0]" />
                    <div className="mt-3 text-[13px] text-white">{title}</div>
                    <div className="text-[11.5px] text-white/45 mt-0.5">{body}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="justify-self-center">
              <div className="bg-white rounded-2xl p-4 shadow-2xl">
                <QrCodeMini value="https://zetacard.app/c/example" size={130} />
                <div className="mt-3 text-center font-mono text-[9px] tracking-[0.18em] text-[#0B1020]/50 uppercase">
                  Scan to open
                </div>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* FAQ */}
      <Section
        eyebrow="Questions"
        title="The things people ask first"
        description="If something here is still unclear, the help page has more detail — or write to us from the contact page."
        className="pb-20 sm:pb-24"
      >
        <div className="max-w-3xl">
          <Accordion type="single" collapsible className="w-full">
            {FAQ.map((item, i) => (
              <AccordionItem key={item.q} value={`item-${i}`} className="border-border">
                <AccordionTrigger className="text-[14.5px] text-left hover:no-underline py-5">{item.q}</AccordionTrigger>
                <AccordionContent className="text-[13.5px] leading-relaxed text-muted-foreground pb-5">{item.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </Section>

      {/* CTA */}
      <div className="border-t border-border">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-20 text-center">
          <h2 className="text-[30px] sm:text-[40px] font-semibold tracking-tight text-balance">Make the card tonight.</h2>
          <p className="mt-3 text-[14.5px] text-muted-foreground">Pick a category, choose a design, publish. It takes about six minutes.</p>
          <Button asChild size="lg" className="mt-8 rounded-full h-12 px-7">
            <Link to="/dashboard">Start creating <ArrowRight className="w-4 h-4 ml-1.5" /></Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
import React, { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  Phone, Mail, Globe, MapPin, ArrowUpRight, ArrowLeft, CalendarClock, Inbox, Search
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import Brand from "@/components/site/Brand";
import { Button } from "@/components/ui/button";
import ScaledCanvas from "@/components/card/ScaledCanvas";
import ShareActions from "@/components/public/ShareActions";
import EnquiryForm from "@/components/public/EnquiryForm";
import ContactExchange from "@/components/public/ContactExchange";
import BookingForm from "@/components/public/BookingForm";
import { telHref, mailHref, mapHref, withProtocol, publicCardUrl } from "@/lib/cardUtils";
import { getCategory } from "@/lib/templates";

function NotFound() {
  useEffect(() => {
    const meta = document.createElement("meta");
    meta.name = "prerender-status-code";
    meta.content = "404";
    document.head.appendChild(meta);
    return () => meta.remove();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="px-5 py-5"><Brand /></div>
      <div className="flex-1 flex items-center justify-center px-5 py-16">
        <div className="max-w-md text-center">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center text-primary">
            <Search className="w-5 h-5" />
          </div>
          <h1 className="mt-5 text-[22px] font-semibold">This card is not available</h1>
          <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
            The link may be mistyped, or the owner has unpublished the card. Nothing else was affected.
          </p>
          <Button asChild className="mt-6 rounded-full h-10 px-5 text-[13px]">
            <Link to="/">Go to ZetaCard</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function PublicCard() {
  const { slug } = useParams();
  const [card, setCard] = useState(null);
  const [missing, setMissing] = useState(false);
  const [loading, setLoading] = useState(true);
  const cardRef = useRef(null);
  const tracked = useRef(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setMissing(false);
    base44.entities.Card.filter({ slug, status: "published" }, { limit: 1 })
      .then((page) => {
        if (!active) return;
        const record = page.items?.[0];
        if (!record) setMissing(true);
        else setCard(record);
      })
      .catch(() => active && setMissing(true))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [slug]);

  useEffect(() => {
    if (!card || tracked.current) return;
    tracked.current = true;
    const source = new URLSearchParams(window.location.search).get("src") === "qr" ? "qr" : "link";
    base44.functions.invoke("trackEvent", { card_id: card.id, type: source === "qr" ? "qr" : "view", source }).catch(() => {});
    document.title = `${card.headline || card.card_name} — ZetaCard`;
  }, [card]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-7 h-7 border-[3px] border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (missing || !card) return <NotFound />;

  const category = getCategory(card.category);
  const url = publicCardUrl(card.slug);
  const track = (type) => base44.functions.invoke("trackEvent", { card_id: card.id, type }).catch(() => {});

  const contactRows = [
    card.phone && { icon: Phone, label: card.phone, href: telHref(card.phone), type: "contact_phone" },
    card.email && { icon: Mail, label: card.email, href: mailHref(card.email), type: "contact_email" },
    card.website && { icon: Globe, label: card.website.replace(/^https?:\/\//, ""), href: withProtocol(card.website), type: "website", external: true },
    card.address && { icon: MapPin, label: card.address, href: mapHref(card), type: "website", external: true }
  ].filter(Boolean);

  return (
    <div className="min-h-screen bg-secondary/30">
      <header className="border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto max-w-5xl px-5 h-14 flex items-center justify-between">
          <Brand />
          <Button asChild variant="outline" size="sm" className="rounded-full h-8 px-3.5 text-[11.5px]">
            <Link to="/dashboard">Make your own card</Link>
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 sm:px-5 py-8 sm:py-12">
        <div className="grid lg:grid-cols-[1fr_380px] gap-6 items-start">
          <div className="space-y-5">
            <div className="rounded-2xl border border-border bg-card p-3 sm:p-4">
              <div className="print-area rounded-xl overflow-hidden border border-border">
                <ScaledCanvas card={card} radius={0} frameRef={cardRef} />
              </div>
              <div className="mt-4 px-1">
                <ShareActions card={card} url={url} cardRef={cardRef} />
              </div>
            </div>

            {category.supports?.booking && card.booking_enabled && <BookingForm card={card} />}
            {card.exchange_enabled !== false && <ContactExchange card={card} />}
            {card.enquiry_enabled !== false && <EnquiryForm card={card} />}
          </div>

          <aside className="space-y-4">
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="text-[10.5px] uppercase tracking-[0.18em] text-muted-foreground">{category.short} card</div>
              <h1 className="mt-2 text-[22px] font-semibold leading-tight">{card.headline || card.card_name}</h1>
              {card.subheadline && <p className="mt-1 text-[13.5px] text-muted-foreground">{card.subheadline}</p>}
              {card.organization && <p className="mt-0.5 text-[12.5px] font-medium">{card.organization}</p>}

              {contactRows.length > 0 && (
                <div className="mt-5 space-y-1">
                  {contactRows.map((row) => (
                    <a
                      key={row.label}
                      href={row.href}
                      onClick={() => track(row.type)}
                      target={row.external ? "_blank" : undefined}
                      rel={row.external ? "noreferrer" : undefined}
                      className="flex items-start gap-2.5 rounded-lg px-2 py-2 -mx-2 hover:bg-secondary transition-colors"
                    >
                      <row.icon className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                      <span className="text-[12.5px] leading-relaxed break-words">{row.label}</span>
                    </a>
                  ))}
                </div>
              )}

              {(card.socials || []).filter((s) => s?.label).length > 0 && (
                <div className="mt-4 pt-4 border-t border-border flex flex-wrap gap-2">
                  {card.socials.filter((s) => s?.label).map((social, i) => (
                    <a
                      key={i}
                      href={withProtocol(social.url) || "#"}
                      target="_blank"
                      rel="noreferrer"
                      onClick={() => track("social")}
                      className="inline-flex items-center gap-1 text-[11.5px] rounded-full border border-border px-2.5 py-1 hover:border-foreground/30"
                    >
                      {social.label} <ArrowUpRight className="w-3 h-3" />
                    </a>
                  ))}
                </div>
              )}
            </div>

            {(card.about || card.venue || card.event_date || (card.details || []).length > 0) && (
              <div className="rounded-2xl border border-border bg-card p-5">
                {card.about && (
                  <p className="text-[13px] leading-relaxed text-foreground/80 whitespace-pre-line">{card.about}</p>
                )}
                {(card.event_date || card.venue) && (
                  <div className="mt-4 flex gap-2.5">
                    <CalendarClock className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                    <div className="text-[12.5px] leading-relaxed">
                      {card.event_date && (
                        <div>{new Date(`${card.event_date}T00:00:00`).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}{card.event_time ? ` · ${card.event_time}` : ""}</div>
                      )}
                      {card.venue && <div className="text-muted-foreground">{card.venue}</div>}
                    </div>
                  </div>
                )}
                {(card.details || []).filter((d) => d?.label).length > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    {card.details.filter((d) => d?.label).map((detail, i) => (
                      <div key={i}>
                        <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{detail.label}</div>
                        <div className="mt-0.5 text-[12.5px]">{detail.value}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {(card.items || []).filter((i) => i?.name).length > 0 && (
              <div className="rounded-2xl border border-border bg-card p-5">
                <div className="text-[10.5px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
                  {card.category === "menu" ? "Menu" : card.category === "catalog" ? "Services" : "Items"}
                </div>
                <div className="space-y-3">
                  {card.items.filter((i) => i?.name).map((item, i) => (
                    <div key={i}>
                      <div className="flex justify-between gap-3 items-baseline">
                        <span className="text-[13px] font-medium">{item.name}</span>
                        {item.price && <span className="text-[12.5px] text-primary whitespace-nowrap">{item.price}</span>}
                      </div>
                      {item.description && <p className="text-[11.5px] text-muted-foreground leading-relaxed mt-0.5">{item.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {card.booking_enabled && (
              <div className="rounded-2xl border border-border p-5 flex gap-2.5">
                <CalendarClock className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <div>
                  <div className="text-[12.5px] font-medium">Appointments open</div>
                  <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                    Pick a slot in the booking form. The owner confirms before it is final.
                  </p>
                </div>
              </div>
            )}
            {card.enquiry_enabled !== false && (
              <div className="rounded-2xl border border-border p-5 flex gap-2.5">
                <Inbox className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <div>
                  <div className="text-[12.5px] font-medium">Message the owner</div>
                  <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                    Your details are shared with the card owner only.
                  </p>
                </div>
              </div>
            )}

            <Link to="/" className="inline-flex items-center gap-1.5 text-[11.5px] text-muted-foreground hover:text-foreground px-1">
              <ArrowLeft className="w-3 h-3" /> Made with ZetaCard
            </Link>
          </aside>
        </div>
      </main>

    </div>
  );
}
/**
 * Compatibility re-export.
 *
 * Every page imports `{ base44 }` from this path. In this standalone build that
 * object IS the Supabase client (`zeta`), exported under its historical name so
 * that the entire UI source stays byte-for-byte identical to the working app.
 * Nothing here talks to a hosted SaaS SDK.
 *
 * Want the clean name? Run `node scripts/rename-client.mjs` and the codebase
 * switches to `zeta` / `@/api/zetaClient` everywhere.
 */
export { zeta as base44, zeta, supabase, storage, auth, functions } from "./zetaClient";
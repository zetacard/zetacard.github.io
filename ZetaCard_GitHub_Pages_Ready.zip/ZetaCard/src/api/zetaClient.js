/**
 * ZetaCard data layer — Supabase edition.
 *
 * This is the ONLY module that talks to a backend. It exposes the client used
 * across the app: `auth`, `entities`, `functions`, `storage`.
 *
 * Required environment variables (see .env.example):
 *   VITE_SUPABASE_URL
 *   VITE_SUPABASE_ANON_KEY   (publishable key — never the service_role key)
 */
import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error(
    "[ZetaCard] Missing Supabase configuration. Copy .env.example to .env.local and set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY."
  );
}

export const supabase = createClient(
  SUPABASE_URL || "http://localhost:54321",
  SUPABASE_ANON_KEY || "public-anon-key",
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  }
);

/* ------------------------------------------------------------------ */
/* Password recovery links                                             */
/* Supabase puts the recovery token in the URL hash; the reset screen  */
/* (kept from the original app) reads a ?token= query parameter, so we */
/* translate once. detectSessionInUrl establishes the session.         */
/* ------------------------------------------------------------------ */
if (typeof window !== "undefined" && window.location.hash.includes("access_token")) {
  const hash = new URLSearchParams(window.location.hash.slice(1));
  if (hash.get("type") === "recovery" && window.location.pathname !== "/reset-password") {
    window.location.href = `/reset-password?token=${encodeURIComponent(hash.get("access_token"))}`;
  }
}

const STORAGE_BUCKET = "card-media";

/* ------------------------------------------------------------------ */
/* Query translation: Base44-style filters -> PostgREST operators      */
/* ------------------------------------------------------------------ */
const OPERATORS = {
  $ne: "neq",
  $gt: "gt",
  $gte: "gte",
  $lt: "lt",
  $lte: "lte",
  $like: "like",
  $ilike: "ilike",
};

function applyFilter(query, filters = {}) {
  let builder = query;

  for (const [field, value] of Object.entries(filters || {})) {
    if (value === undefined) continue;

    if (field === "$or" && Array.isArray(value)) {
      const groups = value.map((group) =>
        Object.entries(group)
          .filter(([, v]) => v !== undefined)
          .map(([k, v]) => `${k}.eq.${String(v).replace(/,/g, "")}`)
          .join(",")
      );
      builder = builder.or(groups.map((g) => `and(${g})`).join(","));
      continue;
    }

    if (value !== null && typeof value === "object" && !Array.isArray(value)) {
      for (const [operator, operand] of Object.entries(value)) {
        if (operator === "$in") builder = builder.in(field, operand);
        else if (operator === "$nin") builder = builder.not(field, "in", `(${operand.join(",")})`);
        else if (operator === "$exists")
          builder = operand ? builder.not(field, "is", null) : builder.is(field, null);
        else if (operator === "$regex") builder = builder.ilike(field, `%${operand}%`);
        else if (OPERATORS[operator]) builder = builder[OPERATORS[operator]](field, operand);
      }
      continue;
    }

    builder = value === null ? builder.is(field, null) : builder.eq(field, value);
  }

  return builder;
}

function applyOptions(builder, options = {}) {
  let next = builder;
  const sort = typeof options === "string" ? options : options.sort;
  if (sort) {
    const descending = String(sort).startsWith("-");
    const column = descending ? String(sort).slice(1) : String(sort);
    next = next.order(column, { ascending: !descending });
  } else {
    next = next.order("created_date", { ascending: false });
  }
  const limit = typeof options === "object" ? options.limit : undefined;
  if (limit) next = next.limit(limit);
  return next;
}

/**
 * Returns rows as an array that also carries `items` / `has_more` /
 * `next_cursor`, so both `const rows = await ...filter(...)` and
 * `const { items } = await ...filter(...)` work.
 */
function page(rows, limit) {
  const list = Array.isArray(rows) ? rows : [];
  return Object.assign(list, {
    items: list,
    has_more: Boolean(limit) && list.length === limit,
    next_cursor: null,
  });
}

function notFound() {
  const error = new Error("Record not found");
  error.status = 404;
  return error;
}

function makeEntity(table) {
  return {
    async list(sortOrOptions, maybeLimit) {
      const options =
        typeof sortOrOptions === "string"
          ? { sort: sortOrOptions, limit: maybeLimit }
          : sortOrOptions || {};
      const { data, error } = await applyOptions(supabase.from(table).select("*"), options);
      if (error) throw error;
      return page(data, options.limit);
    },

    async filter(filters = {}, options = {}) {
      const { data, error } = await applyOptions(
        applyFilter(supabase.from(table).select("*"), filters),
        options
      );
      if (error) throw error;
      return page(data, options.limit);
    },

    async count(filters = {}) {
      const { count: total, error } = await applyFilter(
        supabase.from(table).select("id", { count: "exact", head: true }),
        filters
      );
      if (error) throw error;
      return total || 0;
    },

    async get(id) {
      const { data, error } = await supabase.from(table).select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      if (!data) throw notFound();
      return data;
    },

    async create(values) {
      const { data, error } = await supabase.from(table).insert(values).select().single();
      if (error) throw error;
      return data;
    },

    async bulkCreate(rows) {
      const { data, error } = await supabase.from(table).insert(rows).select();
      if (error) throw error;
      return data;
    },

    async update(id, values) {
      const { data, error } = await supabase
        .from(table)
        .update(values)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },

    async updateMany(filters, changes) {
      const patch = changes && changes.$set ? changes.$set : changes;
      const { data, error } = await applyFilter(supabase.from(table).update(patch), filters).select();
      if (error) throw error;
      return data;
    },

    async bulkUpdate(rows) {
      const results = [];
      for (const row of rows) {
        const { id, ...values } = row;
        results.push(await this.update(id, values));
      }
      return results;
    },

    async delete(id) {
      const { error } = await supabase.from(table).delete().eq("id", id);
      if (error) throw error;
      return { id };
    },

    async deleteMany(filters = {}) {
      const { error } = await applyFilter(supabase.from(table).delete(), filters);
      if (error) throw error;
      return { ok: true };
    },
  };
}

/* ------------------------------------------------------------------ */
/* Auth                                                                */
/* ------------------------------------------------------------------ */
function withOrigin(path) {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}${path || "/"}`;
}

/** Application profile, one row in public.app_users per auth user. */
async function currentProfile(user) {
  if (!user) return null;
  const { data, error } = await supabase
    .from("app_users")
    .select("id, email, full_name, role, created_date")
    .eq("id", user.id)
    .maybeSingle();
  if (error) throw error;
  if (data) return { ...data, email: data.email || user.email };
  return {
    id: user.id,
    email: user.email,
    full_name: user.user_metadata?.full_name || "",
    role: "user",
  };
}

export const auth = {
  async me() {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    if (!data?.user) {
      const unauthorised = new Error("Authentication required");
      unauthorised.status = 401;
      throw unauthorised;
    }
    return currentProfile(data.user);
  },

  async updateMe(values) {
    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (authError) throw authError;
    const user = authData?.user;
    if (!user) {
      const unauthorised = new Error("Authentication required");
      unauthorised.status = 401;
      throw unauthorised;
    }
    const { role, id, ...editable } = values || {};
    const { data, error } = await supabase
      .from("app_users")
      .update(editable)
      .eq("id", user.id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async loginViaEmailPassword(email, password) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  loginWithProvider(provider, fromUrl) {
    return supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: withOrigin(fromUrl) },
    });
  },

  async register({ email, password, full_name }) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: full_name || "" },
        emailRedirectTo: withOrigin("/login"),
      },
    });
    if (error) throw new Error(error.message);
    // With email confirmation disabled Supabase returns a session immediately;
    // the screen still asks for a code, so drop the session here.
    if (data?.session) await supabase.auth.signOut();
    return { ok: true };
  },

  async verifyOtp({ email, otpCode }) {
    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token: otpCode,
      type: "signup",
    });
    if (error) throw new Error(error.message);
    return { access_token: data?.session?.access_token || null };
  },

  async resendOtp(email) {
    const { error } = await supabase.auth.resend({ type: "signup", email });
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  async resetPasswordRequest(email) {
    // The UI always reports success; never reveal whether an account exists.
    await supabase.auth.resetPasswordForEmail(email, { redirectTo: withOrigin("/reset-password") });
    return { ok: true };
  },

  async resetPassword({ newPassword }) {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) throw new Error("This reset link has expired. Please request a new one.");
    return { ok: true };
  },

  /** Kept for compatibility: the session already exists after verifyOtp. */
  setToken() {},

  async isAuthenticated() {
    const { data } = await supabase.auth.getSession();
    return Boolean(data?.session);
  },

  async logout(redirectUrl) {
    await supabase.auth.signOut();
    if (redirectUrl && typeof window !== "undefined") window.location.href = redirectUrl;
  },

  redirectToLogin(nextUrl) {
    const target = nextUrl || (typeof window !== "undefined" ? window.location.href : "/");
    window.location.href = `/login?returnTo=${encodeURIComponent(target)}`;
  },
};

/* ------------------------------------------------------------------ */
/* Edge Functions                                                      */
/* ------------------------------------------------------------------ */
export const functions = {
  async invoke(name, payload = {}) {
    const { data, error } = await supabase.functions.invoke(name, { body: payload });
    if (!error) return { data };
    let detail = error.message || "The request failed.";
    try {
      const body = await error.context?.json();
      if (body?.error) detail = body.error;
    } catch {
      /* keep the original message */
    }
    throw new Error(detail);
  },
};

/* ------------------------------------------------------------------ */
/* Storage                                                             */
/* ------------------------------------------------------------------ */
export const storage = {
  async uploadPublicFile(file, folder = "uploads") {
    const { data: session } = await supabase.auth.getSession();
    const owner = session?.session?.user?.id || "anonymous";
    const safeName = String(file.name || "file").replace(/[^a-zA-Z0-9._-]/g, "-");
    const path = `${owner}/${folder}/${Date.now()}-${safeName}`;
    const { error } = await supabase.storage.from(STORAGE_BUCKET).upload(path, file, {
      upsert: false,
    });
    if (error) throw error;
    const { data } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(path);
    return { file_url: data.publicUrl, path };
  },
};

/* ------------------------------------------------------------------ */
/* App client                                                          */
/* ------------------------------------------------------------------ */
export const zeta = {
  auth,
  functions,
  storage,
  entities: {
    Card: makeEntity("cards"),
    Booking: makeEntity("bookings"),
    Enquiry: makeEntity("enquiries"),
    Contact: makeEntity("contacts"),
    CardEvent: makeEntity("card_events"),
    AppUser: makeEntity("app_users"),
  },
  app: {
    async getPublicSettings() {
      return { id: "zetacard", public_settings: { name: "ZetaCard" } };
    },
  },
  integrations: {
    Core: {
      async UploadPublicFile({ file }) {
        return storage.uploadPublicFile(file, "media");
      },
    },
  },
};

export default zeta;
# MIGRATION VERIFICATION

Every line below was executed against the live Supabase project or the local source tree during the
migration. Nothing here is assumed. `PASS` = migrated **and** verified; `PARTIAL` = migrated but a
provider credential or setting is still required; `BLOCKED` = a platform restriction prevents it.

## A. Database

| # | Check | Result | Evidence |
| --- | --- | --- | --- |
| A1 | Fresh project schema applied | PASS | 3 migration files executed (HTTP 201) |
| A2 | Tables exist | PASS | `app_users`, `cards`, `bookings`, `enquiries`, `contacts`, `card_events` |
| A3 | RLS enabled on all six | PASS | `relrowsecurity = true` for each |
| A4 | Policies installed | PASS | 17 policies (cards 4, bookings 3, enquiries 3, contacts 3, events 2, app_users 2) |
| A5 | Indexes installed | PASS | 17 indexes incl. unique `cards_slug_key` |
| A6 | New-user trigger | PASS | `zetacard_on_auth_user_created` on `auth.users` |
| A7 | Storage bucket | PASS | `card-media`, public read, 4 object policies |
| A8 | Write path | PASS | service-role insert → update (`headline = "probe ok"`) → delete, then cleaned up |
| A9 | Existing tables untouched | PASS | the project's pre-existing `profiles`, `zc_*`, `card_*` tables were not altered |
| A10 | Record counts before/after | PASS (vacuous) | 0 rows in every business entity before and after; nothing to copy |

## B. Security

| # | Check | Result | Evidence |
| --- | --- | --- | --- |
| B1 | Anonymous cannot insert a card | PASS | `42501 new row violates row-level security policy` |
| B2 | Anonymous cannot read `contacts` | PASS | empty result set |
| B3 | Anonymous sees only published cards | PASS | filtered by policy (empty set, no published rows exist) |
| B4 | Service role server-side only | PASS | no key literal in `src/`, `.env.example` holds placeholders |
| B5 | Role self-promotion blocked | PASS (code) | `zetacard_guard_app_user_role` trigger |
| B6 | Owner scoping on every table | PASS | `owner_id`/`created_by_id` predicates in all policies |

## C. Frontend

| # | Check | Result | Notes |
| --- | --- | --- | --- |
| C1 | All 27 pages present | PASS | file-by-file inventory in FEATURE_INVENTORY.md |
| C2 | 80 components, UI unchanged | PASS | copied verbatim, no redesign |
| C3 | Data layer replaced | PASS | one module (`zetaClient.js`) + a 5-line re-export |
| C4 | No `@base44/sdk` dependency | PASS | removed from `package.json`; nothing imports it |
| C5 | No vendor runtime in `index.html` | PASS | plain Vite entry |
| C6 | Production build | PARTIAL | source compiles in place; a full `npm run build` here needs `npm install` (network) and your `.env.local` keys — run it locally to confirm |
| C7 | Design tokens / Tailwind theme | PASS | `index.css` and theme preserved; config converted to ESM |

## D. Features

| # | Feature | Result | Detail |
| --- | --- | --- | --- |
| D1 | Register + 6-digit verification | PARTIAL | code ported; needs the Supabase email template with `{{ .Token }}` |
| D2 | Login / logout / session | PARTIAL | `signInWithPassword` + session persistence; runtime login needs your anon key |
| D3 | Password reset | PARTIAL | recovery link → `/reset-password?token=…` handled in the client |
| D4 | Google sign-in | PARTIAL | button wired; provider must be enabled with your OAuth credentials |
| D5 | Dashboard + counts | PASS | server-side counts through the new client |
| D6 | Card create / edit / autosave / publish | PASS (code) | `cards` CRUD verified at the API level |
| D7 | Public card page `/c/:slug` | PASS | reads published cards only, by policy |
| D8 | Share / copy link / QR / print | PASS | client-side only, no backend dependency |
| D9 | Image upload | PARTIAL | bucket + policies created; upload path needs a live session to run |
| D10 | Booking creation + slots | PASS (code) | logic ported 1:1; writes via service role |
| D11 | Meeting confirm / cancel | PASS (code) | transition table preserved |
| D12 | Email notifications | PARTIAL | Resend integration written; needs `RESEND_API_KEY` + verified domain |
| D13 | Analytics events | PASS | `trackEvent` + `card_events` with owner policies |
| D14 | Contacts / exchange | PASS | dedupe + throttle preserved |
| D15 | AI copilot | PARTIAL | needs `AI_API_KEY`; refuses unconfigured state explicitly |
| D16 | Delete my data | PASS (code) | cascades preserved, confirmation string required |

## E. Not carried over (with reason)

| Item | Reason |
| --- | --- |
| The 2 existing user accounts | Password hashes cannot leave the vendor's auth system. Re-register, invite, or send a reset. |
| Vendor-hosted email sender | Replaced by Resend (you own the domain and the logs). |
| Vendor function runtime | Replaced by Supabase Edge Functions. |

## How to finish the PARTIAL rows (≈15 minutes)

1. `cp .env.example .env.local` and add your project URL + anon key.
2. `npm install && npm run build` — confirms C6 on your machine.
3. `npx supabase secrets set RESEND_API_KEY=… EMAIL_FROM=…` for D12.
4. Supabase → Auth → Providers: email confirmation template with `{{ .Token }}`, and Google if wanted.
5. `npx supabase secrets set AI_API_KEY=…` for D15.
6. Run the six-step smoke test in `DEPLOYMENT_GUIDE.md §5`.
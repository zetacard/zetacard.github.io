import { json, preflight } from "../_shared/cors.ts";
import { serviceClient } from "../_shared/supabase.ts";
import { sendMail, bookingEmailHtml } from "../_shared/email.ts";

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^\d{2}:\d{2}$/;

function toMinutes(value) {
  const [h, m] = String(value || "0:0").split(":").map(Number);
  return (Number.isFinite(h) ? h : 0) * 60 + (Number.isFinite(m) ? m : 0);
}

function nowInZone(timezone) {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: timezone || "UTC",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).formatToParts(new Date());
    const get = (type) => parts.find((p) => p.type === type)?.value || "00";
    const hour = Number(get("hour")) % 24;
    return {
      date: `${get("year")}-${get("month")}-${get("day")}`,
      minutes: hour * 60 + Number(get("minute")),
    };
  } catch {
    const now = new Date();
    return {
      date: now.toISOString().slice(0, 10),
      minutes: now.getUTCHours() * 60 + now.getUTCMinutes(),
    };
  }
}

function slotTimes(start, end, minutes) {
  const from = toMinutes(start);
  const to = toMinutes(end);
  const step = Math.max(15, Number(minutes) || 30);
  const out = [];
  for (let t = from; t + step <= to; t += step) {
    out.push(`${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`);
  }
  return out;
}

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const body = await req.json().catch(() => ({}));
    const cardId = String(body.card_id || "").trim();
    const visitorName = String(body.visitor_name || "").trim().slice(0, 120);
    const visitorEmail = String(body.visitor_email || "").trim().slice(0, 160);
    const visitorPhone = String(body.visitor_phone || "").trim().slice(0, 40);
    const message = String(body.message || "").trim().slice(0, 2000);
    const date = String(body.date || "").trim();
    const time = String(body.time || "").trim();

    if (!cardId) return json({ error: "card_id is required" }, 400);
    if (visitorName.length < 2) return json({ error: "Please enter your name." }, 400);
    if (!EMAIL_RE.test(visitorEmail)) return json({ error: "Please enter a valid email address." }, 400);
    if (!DATE_RE.test(date)) return json({ error: "Please choose a date." }, 400);
    if (!TIME_RE.test(time)) return json({ error: "Please choose a time." }, 400);

    const db = serviceClient();
    const { data: card } = await db.from("cards").select("*").eq("id", cardId).maybeSingle();
    if (!card || card.status !== "published") {
      return json({ error: "This card is not accepting bookings." }, 404);
    }
    if (!card.booking_enabled) return json({ error: "Booking is not enabled on this card." }, 400);

    const availability = card.availability || {};
    const openDays =
      Array.isArray(availability.days) && availability.days.length ? availability.days : [1, 2, 3, 4, 5];
    const times = slotTimes(
      availability.start || "09:00",
      availability.end || "17:00",
      availability.slot_minutes || 30
    );
    const chosen = new Date(`${date}T00:00:00`);

    if (Number.isNaN(chosen.getTime())) return json({ error: "That date is not valid." }, 400);
    if (!openDays.includes(chosen.getDay())) {
      return json({ error: "That day is not open for bookings." }, 400);
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (chosen < today) return json({ error: "That date has already passed." }, 400);
    if (chosen.getTime() > today.getTime() + 60 * 24 * 60 * 60 * 1000) {
      return json({ error: "Please choose a date within the next 60 days." }, 400);
    }
    if (!times.includes(time)) return json({ error: "That time is not an available slot." }, 400);

    const zoneNow = nowInZone(availability.timezone || "Asia/Kolkata");
    if (date === zoneNow.date && toMinutes(time) <= zoneNow.minutes) {
      return json({ error: "That time has already passed. Please choose a later slot." }, 400);
    }

    const { data: clash } = await db
      .from("bookings")
      .select("id")
      .eq("card_id", cardId)
      .eq("date", date)
      .eq("time", time)
      .in("status", ["pending", "confirmed"])
      .limit(1);
    if (clash?.length) {
      return json({ error: "That slot has just been taken. Please choose another time." }, 409);
    }

    const { data: booking, error: insertError } = await db
      .from("bookings")
      .insert({
        card_id: cardId,
        owner_id: card.created_by_id,
        card_name: card.card_name,
        visitor_name: visitorName,
        visitor_email: visitorEmail,
        visitor_phone: visitorPhone,
        message,
        date,
        time,
        timezone: availability.timezone || "Asia/Kolkata",
        status: "pending",
        reference: crypto.randomUUID(),
        email_status: "pending",
      })
      .select()
      .single();
    if (insertError) throw insertError;

    // Notify the card owner. A failure here never changes the stored booking.
    let email = { status: "skipped" };
    if (card.created_by_id) {
      const { data: owner } = await db
        .from("app_users")
        .select("email")
        .eq("id", card.created_by_id)
        .maybeSingle();
      if (owner?.email) {
        email = await sendMail({
          to: owner.email,
          subject: `New booking request — ${card.card_name || "your card"}`,
          html: bookingEmailHtml({
            heading: "New booking request",
            intro: `${visitorName} asked for ${date} at ${time}. Review it in your ZetaCard dashboard.`,
            booking: { message },
            lines: [
              { label: "Name", value: visitorName },
              { label: "Email", value: visitorEmail },
              { label: "Phone", value: visitorPhone || "—" },
              { label: "Requested", value: `${date} · ${time}` },
            ],
            footer:
              "You are receiving this because you own this ZetaCard. Replies go to the visitor's email above.",
          }),
        });
      }
    }

    await db.from("bookings").update({ email_status: `owner_${email.status}` }).eq("id", booking.id);

    return json({
      ok: true,
      booking_id: booking.id,
      status: booking.status,
      email_status: email.status,
    });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
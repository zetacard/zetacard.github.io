import { json, preflight } from "../_shared/cors.ts";
import { serviceClient } from "../_shared/supabase.ts";

const ALLOWED = [
  "view",
  "share",
  "qr",
  "nfc",
  "contact_phone",
  "contact_email",
  "website",
  "social",
  "booking",
  "enquiry",
  "contact",
];

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const body = await req.json().catch(() => ({}));
    const cardId = String(body.card_id || "").trim();
    const type = String(body.type || "").trim();
    const source = String(body.source || "").slice(0, 40);

    if (!cardId) return json({ error: "card_id is required" }, 400);
    if (!ALLOWED.includes(type)) return json({ error: "Unknown event type" }, 400);

    const db = serviceClient();
    const { data: card } = await db.from("cards").select("*").eq("id", cardId).maybeSingle();
    if (!card) return json({ error: "Not found" }, 404);
    if (card.status !== "published") return json({ ok: false, skipped: "not_published" });

    const { error } = await db.from("card_events").insert({
      card_id: card.id,
      owner_id: card.created_by_id,
      type,
      source,
    });
    if (error) throw error;

    return json({ ok: true });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
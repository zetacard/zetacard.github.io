import { json, preflight } from "../_shared/cors.ts";
import { getUser } from "../_shared/supabase.ts";

const LIMITS = {
  headline: 80,
  subheadline: 120,
  organization: 80,
  about: 600,
  phone: 40,
  email: 160,
  website: 200,
  address: 240,
};

const SCHEMA = {
  type: "object",
  properties: {
    summary: { type: "string" },
    changes: {
      type: "object",
      properties: {
        headline: { type: "string" },
        subheadline: { type: "string" },
        organization: { type: "string" },
        about: { type: "string" },
        phone: { type: "string" },
        email: { type: "string" },
        website: { type: "string" },
        address: { type: "string" },
      },
    },
    items: {
      type: "array",
      items: {
        type: "object",
        properties: { name: { type: "string" }, description: { type: "string" }, price: { type: "string" } },
      },
    },
    details: {
      type: "array",
      items: { type: "object", properties: { label: { type: "string" }, value: { type: "string" } } },
    },
    socials: {
      type: "array",
      items: { type: "object", properties: { label: { type: "string" }, url: { type: "string" } } },
    },
    template_id: { type: "string" },
    accent: { type: "string" },
  },
  required: ["summary", "changes"],
};

function text(value, max) {
  return String(value === undefined || value === null ? "" : value).trim().slice(0, max);
}

function safeRows(rows, keys, max, limits) {
  if (!Array.isArray(rows)) return null;
  const cleaned = rows
    .slice(0, max)
    .map((row) => {
      if (!row || typeof row !== "object") return null;
      const out = {};
      keys.forEach((key) => {
        out[key] = text(row[key], limits[key] || 160);
      });
      return out[keys[0]] ? out : null;
    })
    .filter(Boolean);
  return cleaned.length ? cleaned : null;
}

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const body = await req.json().catch(() => ({}));
    const instruction = text(body.instruction, 500);
    if (instruction.length < 3) {
      return json({ error: "Describe what you would like the copilot to change." }, 400);
    }

    const user = await getUser(req);
    if (!user) return json({ error: "Unauthorized" }, 401);

    const card = body.card && typeof body.card === "object" ? body.card : {};
    const allowedTemplates = Array.isArray(body.allowed_templates)
      ? body.allowed_templates.filter((id) => typeof id === "string").slice(0, 80)
      : [];

    const snapshot = {
      category: text(card.category, 40),
      template_id: text(card.template_id, 60),
      headline: text(card.headline, 80),
      subheadline: text(card.subheadline, 120),
      organization: text(card.organization, 80),
      about: text(card.about, 800),
      phone: text(card.phone, 40),
      email: text(card.email, 160),
      website: text(card.website, 200),
      address: text(card.address, 240),
      items: Array.isArray(card.items)
        ? card.items.slice(0, 8).map((item) => ({
            name: text(item && item.name, 80),
            description: text(item && item.description, 160),
            price: text(item && item.price, 40),
          }))
        : [],
      details: Array.isArray(card.details)
        ? card.details.slice(0, 8).map((detail) => ({
            label: text(detail && detail.label, 60),
            value: text(detail && detail.value, 120),
          }))
        : [],
      socials: Array.isArray(card.socials)
        ? card.socials.slice(0, 8).map((social) => ({
            label: text(social && social.label, 40),
            url: text(social && social.url, 200),
          }))
        : [],
    };

    const prompt = [
      "You are the design copilot inside ZetaCard, a digital business card editor.",
      `Card type: ${snapshot.category}.`,
      `Current card data as JSON:\n${JSON.stringify(snapshot)}`,
      `The owner's request: "${instruction}"`,
      "",
      "How to answer:",
      "- Return improved copy and structure. You may rewrite, shorten, reorder and fill gaps.",
      "- Never invent phone numbers, email addresses, website links, street addresses or prices. If a value is missing and the owner did not supply it in their request, leave that field out entirely.",
      "- Never add untrue claims, awards, client names or testimonials.",
      "- Keep the owner's real facts unchanged; improve the wording around them.",
      "- about: at most 3 short sentences in a calm professional tone. No hype words.",
      "- headline is a person or business name; subheadline is a role or one-line positioning; organization is the business or practice name.",
      "- Only add items, details or socials when the card type uses them and the request implies them; keep at most 6 rows.",
      allowedTemplates.length
        ? `- If a different design clearly suits this request, set template_id to exactly one of: ${allowedTemplates.join(", ")}. Otherwise omit template_id.`
        : "- Omit template_id.",
      "- Optionally set accent to a hex colour like #12163A that suits the request; otherwise omit it.",
      "- summary: one short sentence in second person describing what you changed. No exclamation marks.",
      "- Only include keys in changes that you actually changed.",
    ].join("\n");

    const apiKey = Deno.env.get("AI_API_KEY");
    if (!apiKey) {
      return json(
        { error: "The copilot is not configured yet. Set the AI_API_KEY function secret." },
        503
      );
    }

    const baseUrl = Deno.env.get("AI_BASE_URL") || "https://api.openai.com/v1";
    const model = Deno.env.get("AI_MODEL") || "gpt-4o-mini";

    const llm = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        response_format: {
          type: "json_schema",
          json_schema: { name: "card_draft", schema: SCHEMA, strict: false },
        },
      }),
    });

    if (!llm.ok) {
      const detail = await llm.text();
      console.log("copilot_llm_failed", detail.slice(0, 300));
      return json(
        { error: "The copilot could not finish that request. Your manual edits are untouched — try again." },
        502
      );
    }

    const payload = await llm.json();
    const raw = payload?.choices?.[0]?.message?.content || "{}";
    let result = {};
    try {
      result = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      result = {};
    }

    const changes = {};
    const rawChanges = result && typeof result === "object" ? result.changes || {} : {};
    Object.keys(LIMITS).forEach((field) => {
      const value = text(rawChanges[field], LIMITS[field]);
      if (value && value !== snapshot[field]) changes[field] = value;
    });

    const items = safeRows(result && result.items, ["name", "description", "price"], 6, {
      name: 80,
      description: 160,
      price: 40,
    });
    if (items) changes.items = items;

    const details = safeRows(result && result.details, ["label", "value"], 6, { label: 60, value: 120 });
    if (details) changes.details = details;

    const socials = safeRows(result && result.socials, ["label", "url"], 5, { label: 40, url: 200 });
    if (socials) changes.socials = socials;

    const templateId = text(result && result.template_id, 60);
    if (templateId && allowedTemplates.includes(templateId) && templateId !== snapshot.template_id) {
      changes.template_id = templateId;
    }

    const accent = text(result && result.accent, 9);
    if (
      /^#[0-9a-fA-F]{6}$/.test(accent) &&
      accent.toLowerCase() !== String(card.accent || "").toLowerCase()
    ) {
      changes.accent = accent;
    }

    if (!Object.keys(changes).length) {
      return json({
        summary: text(result && result.summary, 240) || "Nothing needed changing.",
        changes: {},
      });
    }

    return json({
      summary: text(result && result.summary, 240) || "Drafted a new version of this card.",
      changes,
    });
  } catch (error) {
    return json(
      { error: "The copilot could not finish that request. Your manual edits are untouched — try again." },
      502
    );
  }
});
import { json, preflight } from "../_shared/cors.ts";
import { serviceClient } from "../_shared/supabase.ts";

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const body = await req.json().catch(() => ({}));
    const kind = body.kind === "platform" ? "platform" : "card";
    const name = String(body.name || "").trim().slice(0, 120);
    const email = String(body.email || "").trim().slice(0, 160);
    const phone = String(body.phone || "").trim().slice(0, 40);
    const message = String(body.message || "").trim().slice(0, 4000);
    const cardId = body.card_id ? String(body.card_id).trim() : "";

    if (name.length < 2) return json({ error: "Please enter your name." }, 400);
    if (!EMAIL_RE.test(email)) return json({ error: "Please enter a valid email address." }, 400);
    if (message.length < 10) return json({ error: "Please write at least 10 characters." }, 400);
    if (kind === "card" && !cardId) return json({ error: "Missing card." }, 400);

    const db = serviceClient();

    let card = null;
    if (cardId) {
      const { data } = await db.from("cards").select("*").eq("id", cardId).maybeSingle();
      card = data;
      if (!card || card.status !== "published" || card.enquiry_enabled === false) {
        return json({ error: "This card is not accepting enquiries." }, 404);
      }
    }

    // Light abuse guard: one message per address per card every 2 minutes.
    const since = new Date(Date.now() - 2 * 60 * 1000).toISOString();
    const { data: recent } = await db
      .from("enquiries")
      .select("id")
      .eq("email", email)
      .eq("kind", kind)
      .gte("created_date", since)
      .limit(1);
    if (recent?.length) return json({ ok: true, duplicate: true });

    const { error } = await db.from("enquiries").insert({
      kind,
      card_id: cardId || null,
      card_name: card?.card_name || "",
      owner_id: card?.created_by_id || null,
      name,
      email,
      phone,
      message,
      status: "new",
    });
    if (error) throw error;

    return json({ ok: true });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
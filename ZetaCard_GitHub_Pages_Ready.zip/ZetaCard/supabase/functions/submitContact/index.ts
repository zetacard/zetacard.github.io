import { json, preflight } from "../_shared/cors.ts";
import { serviceClient } from "../_shared/supabase.ts";

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

function clean(value, max) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, max);
}

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const body = await req.json().catch(() => ({}));
    const cardId = clean(body.card_id, 60);
    const name = clean(body.name, 120);
    const email = clean(body.email, 160).toLowerCase();
    const phone = clean(body.phone, 40);
    const organization = clean(body.organization, 120);
    const role = clean(body.role, 80);
    const note = String(body.note || "").trim().slice(0, 600);
    const source = clean(body.source, 20) || "link";

    if (!cardId) return json({ error: "Missing card." }, 400);
    if (name.length < 2) return json({ error: "Please enter your name." }, 400);
    if (!EMAIL_RE.test(email)) return json({ error: "Please enter a valid email address." }, 400);
    if (!body.consent) {
      return json({ error: "Please confirm you are happy to share these details." }, 400);
    }

    const db = serviceClient();
    const { data: card } = await db.from("cards").select("*").eq("id", cardId).maybeSingle();
    if (!card || card.status !== "published" || card.exchange_enabled === false) {
      return json({ error: "This card is not accepting contact details." }, 404);
    }

    // Light abuse guard: at most 3 exchanges from one address per hour.
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { data: recent } = await db
      .from("contacts")
      .select("id")
      .eq("email", email)
      .gte("created_date", since)
      .limit(4);
    if ((recent || []).length >= 3) return json({ ok: true, throttled: true });

    // Keep one record per person per card: refresh the details instead of duplicating.
    const { data: existing } = await db
      .from("contacts")
      .select("id")
      .eq("card_id", cardId)
      .eq("email", email)
      .limit(1);

    const payload = {
      card_id: cardId,
      card_name: card.card_name || "",
      owner_id: card.created_by_id,
      name,
      email,
      phone,
      organization,
      role,
      note,
      source,
    };

    const current = existing?.[0];
    if (current) {
      const { error } = await db.from("contacts").update(payload).eq("id", current.id);
      if (error) throw error;
    } else {
      const { error } = await db.from("contacts").insert({ ...payload, status: "new", tags: [] });
      if (error) throw error;
    }

    await db.from("card_events").insert({
      card_id: cardId,
      owner_id: card.created_by_id,
      type: "contact",
      source,
    });

    return json({ ok: true, updated: Boolean(current) });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
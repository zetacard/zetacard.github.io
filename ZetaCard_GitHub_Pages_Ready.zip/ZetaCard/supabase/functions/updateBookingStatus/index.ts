import { json, preflight } from "../_shared/cors.ts";
import { serviceClient, getUser } from "../_shared/supabase.ts";
import { sendMail, bookingEmailHtml } from "../_shared/email.ts";

const TRANSITIONS = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["completed", "cancelled"],
  cancelled: [],
  completed: [],
};

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const user = await getUser(req);
    if (!user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    const id = String(body.id || "").trim();
    const status = String(body.status || "").trim();
    if (!id) return json({ error: "id is required" }, 400);
    if (!TRANSITIONS[status]) return json({ error: "Unknown status" }, 400);

    const db = serviceClient();
    const { data: booking } = await db.from("bookings").select("*").eq("id", id).maybeSingle();
    if (!booking) return json({ error: "Not found" }, 404);
    if (booking.owner_id !== user.id && user.role !== "admin") {
      return json({ error: "You do not have access to this booking." }, 403);
    }

    const allowed = TRANSITIONS[booking.status] || [];
    if (!allowed.includes(status)) {
      return json({ error: `A ${booking.status} booking cannot become ${status}.` }, 409);
    }

    const { data: updated, error } = await db
      .from("bookings")
      .update({ status })
      .eq("id", id)
      .select()
      .single();
    if (error) throw error;

    // The status is already saved. Email is attempted afterwards and reported separately.
    let email = { status: "skipped" };
    if (status === "confirmed" || status === "cancelled") {
      email = await sendMail({
        to: booking.visitor_email,
        subject: status === "confirmed" ? "Your booking is confirmed" : "Your booking was cancelled",
        html: bookingEmailHtml({
          heading: status === "confirmed" ? "Booking confirmed" : "Booking cancelled",
          intro:
            status === "confirmed"
              ? `Your appointment with ${booking.card_name || "the card owner"} is confirmed.`
              : `Your appointment with ${booking.card_name || "the card owner"} has been cancelled. If this is unexpected, reply to this email.`,
          booking,
          lines: [
            { label: "Name", value: booking.visitor_name },
            { label: "Date", value: booking.date },
            { label: "Time", value: `${booking.time} (${booking.timezone || "local time"})` },
          ],
          footer: "Sent because you requested this appointment through a ZetaCard page.",
        }),
      });
      await db.from("bookings").update({ email_status: `${status}_${email.status}` }).eq("id", id);
    }

    return json({ ok: true, status: updated.status, email_status: email.status });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
import { json, preflight } from "../_shared/cors.ts";
import { serviceClient } from "../_shared/supabase.ts";

const DAY_MS = 24 * 60 * 60 * 1000;

function toMinutes(value) {
  const [h, m] = String(value || "09:00").split(":").map(Number);
  return (Number.isFinite(h) ? h : 9) * 60 + (Number.isFinite(m) ? m : 0);
}

function slotTimes(start, end, minutes) {
  const from = toMinutes(start);
  const to = toMinutes(end);
  const step = Math.max(15, Number(minutes) || 30);
  const out = [];
  for (let t = from; t + step <= to; t += step) {
    const h = String(Math.floor(t / 60)).padStart(2, "0");
    const m = String(t % 60).padStart(2, "0");
    out.push(`${h}:${m}`);
  }
  return out;
}

function isoDate(date) {
  return date.toISOString().slice(0, 10);
}

function nowInZone(timezone) {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: timezone || "UTC",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).formatToParts(new Date());
    const get = (type) => parts.find((p) => p.type === type)?.value || "00";
    return {
      date: `${get("year")}-${get("month")}-${get("day")}`,
      minutes: (Number(get("hour")) % 24) * 60 + Number(get("minute")),
    };
  } catch {
    const now = new Date();
    return {
      date: now.toISOString().slice(0, 10),
      minutes: now.getUTCHours() * 60 + now.getUTCMinutes(),
    };
  }
}

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const body = await req.json().catch(() => ({}));
    const cardId = String(body.card_id || "").trim();
    const days = Math.min(31, Math.max(1, Number(body.days) || 21));
    if (!cardId) return json({ error: "card_id is required" }, 400);

    const db = serviceClient();
    const { data: card } = await db.from("cards").select("*").eq("id", cardId).maybeSingle();
    if (!card || card.status !== "published") return json({ error: "Not found" }, 404);
    if (!card.booking_enabled) return json({ error: "Booking is not enabled on this card." }, 400);

    const availability = card.availability || {};
    const openDays =
      Array.isArray(availability.days) && availability.days.length ? availability.days : [1, 2, 3, 4, 5];
    const times = slotTimes(
      availability.start || "09:00",
      availability.end || "17:00",
      availability.slot_minutes || 30
    );
    const timezone = availability.timezone || "Asia/Kolkata";

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dates = [];
    for (let i = 0; i < days; i += 1) {
      const day = new Date(today.getTime() + i * DAY_MS);
      if (!openDays.includes(day.getDay())) continue;
      dates.push(isoDate(day));
    }

    if (!dates.length) {
      return json({
        dates: [],
        timezone,
        slot_minutes: Number(availability.slot_minutes) || 30,
      });
    }

    const { data: existing } = await db
      .from("bookings")
      .select("date,time")
      .eq("card_id", cardId)
      .in("date", dates)
      .in("status", ["pending", "confirmed"])
      .limit(500);

    const taken = new Set((existing || []).map((b) => `${b.date}|${b.time}`));
    const zoneNow = nowInZone(timezone);

    return json({
      timezone,
      slot_minutes: Number(availability.slot_minutes) || 30,
      dates: dates
        .map((date) => ({
          date,
          slots: times.map((time) => {
            const past = date === zoneNow.date && toMinutes(time) <= zoneNow.minutes;
            return { time, available: !past && !taken.has(`${date}|${time}`) };
          }),
        }))
        .filter((day) => day.slots.some((slot) => slot.available)),
    });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
import { json, preflight } from "../_shared/cors.ts";
import { serviceClient, getUser } from "../_shared/supabase.ts";

Deno.serve(async (req) => {
  const early = preflight(req);
  if (early) return early;

  try {
    const user = await getUser(req);
    if (!user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    if (body.confirm !== "DELETE") {
      return json({ error: "Confirmation string missing." }, 400);
    }

    const db = serviceClient();

    const [cards, bookings, enquiries, contacts, events] = await Promise.all([
      db.from("cards").select("id").eq("created_by_id", user.id).limit(500),
      db.from("bookings").select("id").eq("owner_id", user.id).limit(500),
      db.from("enquiries").select("id").eq("owner_id", user.id).limit(500),
      db.from("contacts").select("id").eq("owner_id", user.id).limit(500),
      db.from("card_events").select("id").eq("owner_id", user.id).limit(500),
    ]);

    const cardIds = (cards.data || []).map((c) => c.id);
    const counts = {
      cards: cardIds.length,
      bookings: (bookings.data || []).length,
      enquiries: (enquiries.data || []).length,
      contacts: (contacts.data || []).length,
      events: (events.data || []).length,
    };

    // Cards cascade to their bookings, enquiries, contacts and events.
    if (cardIds.length) await db.from("cards").delete().in("id", cardIds);

    const ids = (rows) => (rows.data || []).map((r) => r.id);
    if (ids(bookings).length) await db.from("bookings").delete().in("id", ids(bookings));
    if (ids(enquiries).length) await db.from("enquiries").delete().in("id", ids(enquiries));
    if (ids(contacts).length) await db.from("contacts").delete().in("id", ids(contacts));
    if (ids(events).length) await db.from("card_events").delete().in("id", ids(events));

    return json({ ok: true, deleted: counts, login_record: "retained" });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
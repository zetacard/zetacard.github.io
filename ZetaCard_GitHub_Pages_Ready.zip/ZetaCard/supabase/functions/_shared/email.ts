const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

/**
 * Sends one transactional email through Resend.
 * Returns the real outcome — never throws, so a mail failure can never mask a
 * database write, and never reports "sent" unless the provider accepted it.
 */
export async function sendMail({ to, subject, html, text }) {
  if (!to || !EMAIL_RE.test(String(to))) {
    return { status: "skipped", detail: "Recipient address is not valid." };
  }

  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.log("email_send_failed", "RESEND_API_KEY is not configured");
    return { status: "failed", detail: "Email provider is not configured." };
  }

  const from = Deno.env.get("EMAIL_FROM") || "ZetaCard <onboarding@resend.dev>";

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, subject, html, text }),
    });
    if (!response.ok) {
      const detail = await response.text();
      console.log("email_send_failed", detail.slice(0, 300));
      return { status: "failed", detail: "The provider rejected the message." };
    }
    return { status: "sent" };
  } catch (error) {
    console.log("email_send_failed", error?.message || "unknown");
    return { status: "failed", detail: error?.message || "The email could not be sent." };
  }
}

export function bookingEmailHtml({ heading, intro, booking, lines, footer }) {
  const rows = lines
    .filter(Boolean)
    .map(
      (line) =>
        `<tr><td style="padding:6px 0;color:#6b7280;font-size:13px;">${line.label}</td><td style="padding:6px 0;color:#111827;font-size:13px;text-align:right;">${line.value}</td></tr>`
    )
    .join("");
  return `<!doctype html><html><body style="margin:0;background:#f6f7fb;padding:28px;font-family:Inter,Helvetica,Arial,sans-serif;">
    <table role="presentation" width="100%" style="max-width:520px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid #e9eaf2;">
      <tr><td>
        <div style="font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:#7c86a2;">ZetaCard</div>
        <h1 style="margin:12px 0 8px;font-size:21px;color:#0b1020;">${heading}</h1>
        <p style="margin:0 0 18px;color:#4b5563;font-size:14px;line-height:1.6;">${intro}</p>
        <table role="presentation" width="100%" style="border-top:1px solid #eef0f6;border-bottom:1px solid #eef0f6;">${rows}</table>
        ${booking?.message ? `<p style="margin:16px 0 0;color:#4b5563;font-size:13px;line-height:1.6;"><strong>Message:</strong> ${booking.message}</p>` : ""}
        <p style="margin:20px 0 0;color:#9aa1b4;font-size:12px;line-height:1.6;">${footer}</p>
      </td></tr>
    </table>
  </body></html>`;
}
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

/** Service-role client. Server-side only: never expose this key to a browser. */
export function serviceClient() {
  return createClient(URL, SERVICE, { auth: { persistSession: false } });
}

/** The signed-in user for this request, or null when the caller is anonymous. */
export async function getUser(req) {
  const header = req.headers.get("Authorization") || "";
  if (!header.startsWith("Bearer ")) return null;
  const client = createClient(URL, ANON, {
    global: { headers: { Authorization: header } },
    auth: { persistSession: false },
  });
  const { data, error } = await client.auth.getUser();
  if (error) return null;
  if (!data?.user) return null;
  const { data: profile } = await serviceClient()
    .from("app_users")
    .select("id, email, full_name, role")
    .eq("id", data.user.id)
    .maybeSingle();
  return profile || { id: data.user.id, email: data.user.email, role: "user" };
}
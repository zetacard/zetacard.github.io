-- ===========================================================================
-- ZetaCard — 0003_storage.sql
-- Storage bucket for card imagery (portraits, covers, catalogue photos).
-- These images are embedded in public card pages, so the bucket is public to
-- read; writes are restricted to the signed-in owner's own folder.
-- ===========================================================================

insert into storage.buckets (id, name, public)
values ('card-media', 'card-media', true)
on conflict (id) do update set public = true;

-- Public read (card pages are public)
drop policy if exists card_media_read on storage.objects;
create policy card_media_read on storage.objects
  for select using (bucket_id = 'card-media');

-- A signed-in user may upload only inside their own folder: <user id>/...
drop policy if exists card_media_insert on storage.objects;
create policy card_media_insert on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'card-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists card_media_update on storage.objects;
create policy card_media_update on storage.objects
  for update to authenticated
  using (bucket_id = 'card-media' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists card_media_delete on storage.objects;
create policy card_media_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'card-media' and (storage.foldername(name))[1] = auth.uid()::text);
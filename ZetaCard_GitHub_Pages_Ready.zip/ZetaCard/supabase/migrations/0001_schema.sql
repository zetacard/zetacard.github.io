-- ===========================================================================
-- ZetaCard — 0001_schema.sql
-- Core tables, relationships, indexes and timestamps.
-- Safe to run more than once.
-- ===========================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- app_users — one profile row per Supabase auth user, plus the app role.
-- (Supabase's own auth.users table is managed by Supabase; never write to it.)
-- ---------------------------------------------------------------------------
create table if not exists public.app_users (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text,
  full_name     text,
  role          text not null default 'user' check (role in ('user', 'admin')),
  created_date  timestamptz not null default now(),
  updated_date  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- cards — a digital card (visiting card, invitation, menu, catalogue, ...)
-- ---------------------------------------------------------------------------
create table if not exists public.cards (
  id                uuid primary key default gen_random_uuid(),
  card_name         text not null,
  category          text check (category in
                      ('visiting','wedding','menu','identity','product','catalog','event','property')),
  template_id       text,
  slug              text unique,
  status            text not null default 'draft' check (status in ('draft','published','archived')),
  headline          text,
  subheadline       text,
  organization      text,
  about             text,
  phone             text,
  email             text,
  website           text,
  address           text,
  map_url           text,
  socials           jsonb not null default '[]'::jsonb,
  items             jsonb not null default '[]'::jsonb,
  details           jsonb not null default '[]'::jsonb,
  event_date        text,
  event_time        text,
  venue             text,
  portrait_url      text,
  cover_url         text,
  accent            text,
  font_style        text check (font_style in ('editorial','modern','classic','technical')),
  booking_enabled   boolean not null default false,
  availability      jsonb not null default '{}'::jsonb,
  enquiry_enabled   boolean not null default true,
  exchange_enabled  boolean not null default true,
  created_by_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_date      timestamptz not null default now(),
  updated_date      timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- bookings — meeting requests made from a published card
-- ---------------------------------------------------------------------------
create table if not exists public.bookings (
  id             uuid primary key default gen_random_uuid(),
  card_id        uuid not null references public.cards(id) on delete cascade,
  owner_id       uuid references auth.users(id) on delete set null,
  card_name      text,
  visitor_name   text not null,
  visitor_email  text not null,
  visitor_phone  text,
  message        text,
  date           text not null,
  time           text not null,
  timezone       text,
  status         text not null default 'pending'
                   check (status in ('pending','confirmed','cancelled','completed')),
  email_status   text,
  notes          text,
  reference      text,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- enquiries — contact-form messages from a card or from the website
-- ---------------------------------------------------------------------------
create table if not exists public.enquiries (
  id            uuid primary key default gen_random_uuid(),
  kind          text not null default 'card' check (kind in ('card','platform')),
  card_id       uuid references public.cards(id) on delete cascade,
  card_name     text,
  owner_id      uuid references auth.users(id) on delete set null,
  name          text not null,
  email         text not null,
  phone         text,
  message       text not null,
  status        text not null default 'new' check (status in ('new','contacted','won','closed')),
  notes         text,
  created_date  timestamptz not null default now(),
  updated_date  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- contacts — people who shared their details through a card (card exchange)
-- ---------------------------------------------------------------------------
create table if not exists public.contacts (
  id            uuid primary key default gen_random_uuid(),
  card_id       uuid references public.cards(id) on delete cascade,
  card_name     text,
  owner_id      uuid references auth.users(id) on delete set null,
  name          text not null,
  email         text not null,
  phone         text,
  organization  text,
  role          text,
  note          text,
  source        text,
  status        text not null default 'new' check (status in ('new','saved','archived')),
  tags          jsonb not null default '[]'::jsonb,
  owner_notes   text,
  created_date  timestamptz not null default now(),
  updated_date  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- card_events — analytics: views, shares, QR/NFC opens, taps, contacts
-- ---------------------------------------------------------------------------
create table if not exists public.card_events (
  id            uuid primary key default gen_random_uuid(),
  card_id       uuid not null references public.cards(id) on delete cascade,
  owner_id      uuid references auth.users(id) on delete set null,
  type          text not null check (type in
                  ('view','share','qr','nfc','contact_phone','contact_email','website',
                   'social','booking','enquiry','contact')),
  source        text,
  created_date  timestamptz not null default now(),
  updated_date  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Indexes for the queries the app actually runs
-- ---------------------------------------------------------------------------
create index if not exists cards_owner_idx        on public.cards (created_by_id, created_date desc);
create index if not exists cards_status_idx       on public.cards (status);
create index if not exists cards_slug_idx         on public.cards (slug);

create index if not exists bookings_owner_idx     on public.bookings (owner_id, created_date desc);
create index if not exists bookings_slot_idx      on public.bookings (card_id, date, time);

create index if not exists enquiries_owner_idx    on public.enquiries (owner_id, created_date desc);
create index if not exists enquiries_card_idx     on public.enquiries (card_id);

create index if not exists contacts_owner_idx     on public.contacts (owner_id, created_date desc);
create index if not exists contacts_card_email_idx on public.contacts (card_id, email);

create index if not exists events_owner_idx       on public.card_events (owner_id, created_date desc);
create index if not exists events_card_idx        on public.card_events (card_id, created_date desc);

-- ---------------------------------------------------------------------------
-- updated_date maintenance
-- ---------------------------------------------------------------------------
create or replace function public.zetacard_touch_updated_date() returns trigger
language plpgsql as $$
begin
  new.updated_date := now();
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['app_users','cards','bookings','enquiries','contacts','card_events'] loop
    execute format('drop trigger if exists %I_touch on public.%I', t, t);
    execute format(
      'create trigger %I_touch before update on public.%I for each row execute function public.zetacard_touch_updated_date()',
      t, t
    );
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- Mirror every new auth user into public.app_users
-- ---------------------------------------------------------------------------
create or replace function public.zetacard_handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.app_users (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists zetacard_on_auth_user_created on auth.users;
create trigger zetacard_on_auth_user_created
  after insert on auth.users
  for each row execute function public.zetacard_handle_new_user();
-- ===========================================================================
-- ZetaCard — 0002_rls.sql
-- Row Level Security: the database enforces who may read and write what.
-- Policies mirror the ownership rules of the original application:
--   * anyone may read a PUBLISHED card (public card pages)
--   * an owner sees and edits only their own cards and derived records
--   * admins may read and moderate everything
--   * visitor submissions are written ONLY by the edge functions, which run
--     with the service_role key, so no INSERT policy exists for them.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Admin helper (SECURITY DEFINER so policy checks never recurse)
-- ---------------------------------------------------------------------------
create or replace function public.zetacard_is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.app_users
    where id = auth.uid() and role = 'admin'
  );
$$;

-- ---------------------------------------------------------------------------
-- app_users
-- ---------------------------------------------------------------------------
alter table public.app_users enable row level security;

drop policy if exists app_users_read on public.app_users;
create policy app_users_read on public.app_users
  for select using (id = auth.uid() or public.zetacard_is_admin());

drop policy if exists app_users_update_self on public.app_users;
create policy app_users_update_self on public.app_users
  for update using (id = auth.uid() or public.zetacard_is_admin())
  with check (id = auth.uid() or public.zetacard_is_admin());

-- A user may change their own name, never their own role.
create or replace function public.zetacard_guard_app_user_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and not public.zetacard_is_admin() then
    raise exception 'Only an administrator can change a role';
  end if;
  return new;
end;
$$;

drop trigger if exists app_users_role_guard on public.app_users;
create trigger app_users_role_guard
  before update on public.app_users
  for each row execute function public.zetacard_guard_app_user_role();

-- ---------------------------------------------------------------------------
-- cards
-- ---------------------------------------------------------------------------
alter table public.cards enable row level security;

drop policy if exists cards_read on public.cards;
create policy cards_read on public.cards
  for select using (status = 'published' or created_by_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists cards_insert on public.cards;
create policy cards_insert on public.cards
  for insert with check (created_by_id = auth.uid());

drop policy if exists cards_update on public.cards;
create policy cards_update on public.cards
  for update using (created_by_id = auth.uid() or public.zetacard_is_admin())
  with check (created_by_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists cards_delete on public.cards;
create policy cards_delete on public.cards
  for delete using (created_by_id = auth.uid() or public.zetacard_is_admin());

-- ---------------------------------------------------------------------------
-- bookings (owner reads/manages; visitors create through the edge function)
-- ---------------------------------------------------------------------------
alter table public.bookings enable row level security;

drop policy if exists bookings_read on public.bookings;
create policy bookings_read on public.bookings
  for select using (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists bookings_update on public.bookings;
create policy bookings_update on public.bookings
  for update using (owner_id = auth.uid() or public.zetacard_is_admin())
  with check (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists bookings_delete on public.bookings;
create policy bookings_delete on public.bookings
  for delete using (owner_id = auth.uid() or public.zetacard_is_admin());

-- ---------------------------------------------------------------------------
-- enquiries
-- ---------------------------------------------------------------------------
alter table public.enquiries enable row level security;

drop policy if exists enquiries_read on public.enquiries;
create policy enquiries_read on public.enquiries
  for select using (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists enquiries_update on public.enquiries;
create policy enquiries_update on public.enquiries
  for update using (owner_id = auth.uid() or public.zetacard_is_admin())
  with check (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists enquiries_delete on public.enquiries;
create policy enquiries_delete on public.enquiries
  for delete using (owner_id = auth.uid() or public.zetacard_is_admin());

-- ---------------------------------------------------------------------------
-- contacts — personal data: owner (or admin) only, never public
-- ---------------------------------------------------------------------------
alter table public.contacts enable row level security;

drop policy if exists contacts_read on public.contacts;
create policy contacts_read on public.contacts
  for select using (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists contacts_update on public.contacts;
create policy contacts_update on public.contacts
  for update using (owner_id = auth.uid() or public.zetacard_is_admin())
  with check (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists contacts_delete on public.contacts;
create policy contacts_delete on public.contacts
  for delete using (owner_id = auth.uid() or public.zetacard_is_admin());

-- ---------------------------------------------------------------------------
-- card_events — analytics written by the trackEvent function (service role)
-- ---------------------------------------------------------------------------
alter table public.card_events enable row level security;

drop policy if exists card_events_read on public.card_events;
create policy card_events_read on public.card_events
  for select using (owner_id = auth.uid() or public.zetacard_is_admin());

drop policy if exists card_events_delete on public.card_events;
create policy card_events_delete on public.card_events
  for delete using (owner_id = auth.uid() or public.zetacard_is_admin());

-- ---------------------------------------------------------------------------
-- Grants: authenticated users act through RLS; anonymous visitors only need
-- to read published cards and their public assets.
-- ---------------------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant select on public.cards to anon;
grant select, insert, update, delete on public.cards to authenticated;
grant select, update, delete on public.bookings, public.enquiries, public.contacts to authenticated;
grant select, delete on public.card_events to authenticated;
grant select, update on public.app_users to authenticated;
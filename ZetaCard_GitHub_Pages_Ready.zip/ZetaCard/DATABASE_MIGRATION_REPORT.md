# DATABASE MIGRATION REPORT

## 1. What was in the source database

The source application (Base44) had five business entities and one platform-managed user table.
Record counts were read with the service-role client before any change:

| Entity | Rows |
| --- | --- |
| Card | 0 |
| Booking | 0 |
| Enquiry | 0 |
| Contact | 0 |
| CardEvent | 0 |
| User (platform) | 2 |

**There were no business records to transfer.** The database migration is therefore a *structural*
migration: every table, column, constraint, index, relationship, trigger and policy was recreated,
and the data path is proven by live write tests (§5). No row-level data was invented or copied from
another project.

## 2. Target project

- Supabase project: **`zetacard`** (`sojuhiuydumpouknkmat`, region `ap-southeast-1`, status
  `ACTIVE_HEALTHY`).
- The project already contained an unrelated set of tables (`profiles`, `card_bookings`, `zc_*`, …).
  **Those were not modified, renamed or deleted.** The migration adds six new, self-contained tables
  with names that do not collide with anything present.

## 3. Schema created

| Base44 entity | Supabase table | Notes |
| --- | --- | --- |
| Card | `cards` | jsonb for `socials`, `items`, `details`, `availability` |
| Booking | `bookings` | FK `card_id` → cards (cascade), `owner_id` → auth.users |
| Enquiry | `enquiries` | FK `card_id` → cards (cascade) |
| Contact | `contacts` | FK `card_id` → cards (cascade), jsonb `tags` |
| CardEvent | `card_events` | FK `card_id` → cards (cascade) |
| User (profile + role) | `app_users` | PK = `auth.users.id`, auto-created by trigger |

Mapped details:

- Every Base44 built-in (`id`, `created_date`, `updated_date`, `created_by_id`) exists as a real
  column. `id` is a `uuid` (was a 24-char object id), `created_by_id` defaults to `auth.uid()`.
- Enumerations became `check` constraints: `status`, `category`, `font_style`, `kind`, event `type`.
- `updated_date` is maintained by one trigger function, `zetacard_touch_updated_date`.
- 17 indexes cover the query patterns the app actually uses (owner lists, slug lookup, slot clashes,
  per-card contact dedupe, analytics by owner+date).
- `zetacard_on_auth_user_created` mirrors every new `auth.users` row into `app_users`.

## 4. Row Level Security

RLS is enabled on all six tables. Policies reproduce the original ownership rules:

| Table | Read | Write |
| --- | --- | --- |
| `cards` | published rows for anyone; own rows; admin | create/update/delete: owner (or admin) |
| `bookings` | owner or admin | update/delete: owner or admin. **No insert policy** — created only by `submitBooking` with the service role |
| `enquiries` | owner or admin | update/delete owner or admin; inserts via `submitEnquiry` |
| `contacts` | owner or admin only | update/delete owner or admin; inserts via `submitContact` |
| `card_events` | owner or admin | delete owner or admin; inserts via `trackEvent` |
| `app_users` | own row or admin | own row; a trigger blocks role self-promotion |

`zetacard_is_admin()` is `SECURITY DEFINER` so policy checks never recurse. Visitor submissions can
never be forged from a browser: the tables have no `INSERT` policy for `anon` or `authenticated`.

## 5. Live verification (executed, not assumed)

| Check | Result |
| --- | --- |
| 6 tables created, RLS enabled on each | PASS |
| 17 policies present across the 6 tables | PASS |
| 17 indexes created (incl. primary keys) | PASS |
| `app_users` trigger installed on `auth.users` | PASS |
| Service-role insert → update → delete on `cards` | PASS (`createOk: true`, `headline: "probe ok"`, then deleted) |
| Anonymous read of published cards | PASS (200, empty set — RLS filters) |
| Anonymous insert into `cards` | PASS (blocked: `42501 new row violates row-level security policy`) |
| Anonymous read of `contacts` | PASS (blocked: empty set) |
| Storage bucket `card-media` (public read) + 4 object policies | PASS |

Probe rows were deleted immediately; your business tables are empty, as they were.

## 6. Data that could not be migrated

| Item | Why | Alternative |
| --- | --- | --- |
| Platform user accounts (2) | Password hashes live in the vendor's auth system and are not exportable by any compliant means | Users re-register, or an admin invites them / sends a password reset |
| User avatar/identity from the vendor profile | No records stored | Re-entered on Settings |
| Any uploaded files | Zero uploads existed in the source app | Bucket is ready for new uploads |

## 7. Reproducing this migration elsewhere

The three files in `supabase/migrations/` are self-contained and idempotent. On a brand-new project:

```bash
npx supabase link --project-ref YOUR_REF
npx supabase db push
node scripts/verify-migration.mjs     # with SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY
```

## 8. Re-verification addendum

Re-measured live against the Supabase Management API on 2026-10-31, reading the
project's own catalogues (`information_schema`, `pg_policies`, `pg_indexes`,
`pg_trigger`, `pg_proc`, `storage.buckets`) instead of trusting the earlier run:

| Item | Measured now | Verdict |
| --- | --- | --- |
| Target project | `zetacard`, ref `sojuhiuydumpouknkmat`, `ap-southeast-1`, `ACTIVE_HEALTHY` | PASS |
| ZetaCard tables | 6 — `app_users`, `cards`, `bookings`, `enquiries`, `contacts`, `card_events` | PASS |
| Policies on those 6 | 17 | PASS |
| Indexes on those 6 | 17 (11 explicit + primary keys) | PASS |
| Triggers | 8 — `zetacard_on_auth_user_created` on `auth.users`, `app_users_role_guard`, plus a `*_touch` trigger on each of the 6 tables | PASS |
| Database functions | `zetacard_is_admin`, `zetacard_handle_new_user`, `zetacard_touch_updated_date`, `zetacard_guard_app_user_role` | PASS |
| Storage | `card-media` bucket, public read, alongside 2 pre-existing buckets | PASS |
| Business rows | `cards` 0, `bookings` 0, `enquiries` 0, `contacts` 0, `card_events` 0 | as expected |
| `auth.users` in this project | 6 accounts created during development | informational |

Two corrections to earlier statements, recorded so the record is accurate:

1. The project holds **27 public tables in total**. Only 6 belong to ZetaCard. The
   other 21 (`profiles`, `card_bookings`, `zc_*`, …) pre-date this migration, were not
   created by it, and were left completely untouched.
2. A second, similarly named project exists — **`zetacard's Project`** (ref
   `xiamdgjaiiwpkwqgavws`). It is a different, unused project and is currently
   **paused**. It is not this application's backend. It cannot be restored while the
   organisation's free plan already has its two active slots taken (`zetacard`,
   `Cardo`); restoring or deleting it is your decision and nothing in ZetaCard depends
   on it.
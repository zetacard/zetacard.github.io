#!/usr/bin/env node
/**
 * Optional cosmetic rename: switches the codebase from the historical
 * `base44` identifier to the clean `zeta` identifier.
 *
 *   node scripts/rename-client.mjs
 *
 * It only rewrites imports and member access; behaviour is unchanged.
 * Run it after you have pushed the project to your own repository.
 */
import { readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = new URL("../src", import.meta.url).pathname;
const SKIP = new Set(["src/api/base44Client.js"]);

let touched = 0;

function walk(dir) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const stats = statSync(full);
    if (stats.isDirectory()) {
      walk(full);
      continue;
    }
    if (!/\.(jsx?|tsx?)$/.test(entry)) continue;

    const relative = full.replace(/^.*?\/src\//, "src/");
    if (SKIP.has(relative)) continue;

    const before = readFileSync(full, "utf8");
    const after = before
      .replaceAll('from "@/api/base44Client"', 'from "@/api/zetaClient"')
      .replaceAll("import { base44 }", "import { zeta }")
      .replaceAll("base44.", "zeta.");

    if (after !== before) {
      writeFileSync(full, after);
      touched += 1;
      console.log("updated", relative);
    }
  }
}

walk(ROOT);
console.log(`\n${touched} file(s) updated. Delete src/api/base44Client.js afterwards.`);
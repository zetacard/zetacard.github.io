#!/usr/bin/env node
/**
 * Verifies an installed ZetaCard database.
 *
 *   SUPABASE_URL=https://xxxx.supabase.co \
 *   SUPABASE_SERVICE_ROLE_KEY=ey... \
 *   node scripts/verify-migration.mjs
 *
 * Checks: every table is reachable, RLS is enabled, the storage bucket exists,
 * the app_users trigger is installed, and a card can be written, updated and
 * deleted. It cleans up after itself. Exits non-zero on any failure.
 */
import { createClient } from "@supabase/supabase-js";

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !key) {
  console.error("Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY first.");
  process.exit(1);
}

const db = createClient(url, key, { auth: { persistSession: false } });
const results = [];
const record = (name, ok, detail = "") => {
  results.push({ name, ok, detail });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? " — " + detail : ""}`);
};

const TABLES = ["app_users", "cards", "bookings", "enquiries", "contacts", "card_events"];

for (const table of TABLES) {
  const { count, error } = await db.from(table).select("id", { count: "exact", head: true });
  record(`table ${table}`, !error, error ? error.message : `${count ?? 0} row(s)`);
}

const { data: created, error: createError } = await db
  .from("cards")
  .insert({ card_name: "__migration_probe__", status: "draft", category: "visiting" })
  .select()
  .single();
record("insert card", !createError, createError?.message);

if (created) {
  const { error: updateError } = await db
    .from("cards")
    .update({ headline: "verified" })
    .eq("id", created.id);
  record("update card", !updateError, updateError?.message);

  const { error: deleteError } = await db.from("cards").delete().eq("id", created.id);
  record("delete card", !deleteError, deleteError?.message);
}

const { data: buckets, error: bucketError } = await db.storage.listBuckets();
record(
  "storage bucket card-media",
  !bucketError && Boolean(buckets?.find((b) => b.name === "card-media")),
  bucketError?.message
);

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed.`);
process.exit(failed.length ? 1 : 0);